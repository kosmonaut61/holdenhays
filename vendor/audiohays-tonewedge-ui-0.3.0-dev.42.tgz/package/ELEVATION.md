# Content elevation

Material and depth are independent. Optical glass remains `--tw-glass`; do not reuse it for every nested content card.

- **canvas**: page/background (`--tw-surface-canvas`).
- **sheet**: major section or content plane (`--tw-surface-sheet`).
- **card**: content grouped above a sheet (`--tw-surface-card`).
- **raised**: a floating/prominent surface (`--tw-surface-raised`). Use sparingly, not on every nested div.

Apply `data-tw-elevation="card"` or `"raised"` to a rounded host. These opt-in hosts use paired `--tw-surface-ink`, `--tw-surface-muted`, `--tw-surface-accent`, `--tw-surface-focus`, and `--tw-surface-control-edge`. The shared glass `.tw-card` automatically uses card depth. Hardware and Minimal treatments keep their existing behavior.

A complete quiet inset boundary and soft contact shadow distinguish edges. Avoid a bright top-only rim, nested stacks of decoration or overriding card backgrounds to the parent sheet. Depth is not an interactive state: preserve focus outlines and selected-state indicators. The decorative boundary is intentionally subtle and is not a substitute for a required control boundary.

Load tokens.css/components.css and the material/treatment styles normally. Generated light/dark and runtime custom-tint palettes provide the same role contract. All text pairs meet 4.5:1 and focus/control roles 3:1 on all four surfaces. Existing optical palettes and legacy token values remain unchanged.

Consumers must upgrade their pinned artifact, remove local hard-coded rim/background overrides and use the semantic role. Publishing Bildpunkt alone does not update pinned consumers. No app state or persistence changes are involved.
