# Bildpunkt 0.3.0-dev.15

## Requested changes
- Cards now describes content/status containers; Lists & pickers groups repeated/selectable items; Glass describes optional surface material.
- General-purpose content, project-file and workspace examples appear first. Tonewedge remains the primary application example, explicitly labeled, with its original controls, data and APIs retained.
- Content cards can remove and remount their optional glass without changing their content or layout.
- Catalog metadata owns grouping, visible labels and search aliases. All 17 section IDs and 30 story anchors remain supported, including prior search names and API queries.
- Usage examples now show the correct APIs for every story. Guitar-list selection preserves item identity and keyboard focus, allowing immediate Escape to return to its section header.

## Verification
- 185 aggregate package/unit/build checks and 2 site/MCP checks pass.
- Final integrated matrix passes all 12 Chrome/WebKit × 1440/390/320px × catalog/standalone contexts, with 5,567 assertions and zero failures. All six standalone runs made zero ancillary requests.
- All 17 section IDs, 30 story anchors, 66 retained control IDs, 60 deep-link forms and 23 discovery terms pass. Correct usage imports, generic and Tonewedge callbacks, Back/Forward, optional-glass removal/remount and guitar selection/focus/Escape are covered.
- All 8,714 source/build hashes stayed unchanged during final QA. Compared with dev.14, 8,683 protected files are byte-identical and seven differ only in release-version metadata. No shared styles, assets or palette roles changed.
- Desktop/mobile production smoke passes locally and is repeated after publication, including retained tabs, carousel, image toggles, cast controls, radial menu and dialog interactions.
- Actual default-state panel screenshots and compressed detailed results are recorded in `qa/dev15/`.

## Known issue
The optional refracted glass content card has pale text over bright texture in dark mode. The exact dev.14 build has the same rendering; this release introduces no contrast regression. A separately verified material/text correction follows rather than changing the frozen taxonomy release.

## Scope
The existing Bildpunkt catalog and private package artifact are updated. No npm release, Tonewedge/Pi upgrade, physical touchscreen test or Logic AU validation is included. Shared styles, assets, color roles and unrelated component behavior are preserved from dev.14.
