# Bildpunkt 0.3.0-dev.6 validation

Typography-only local candidate. No push/deployment, Tonewedge/Pi change, palette change, artwork redraw or control behavior change.

## Findings and implementation

Live dev.5 rendered Courier New in metadata and labels, and browser-default monospace in nested usage code. The shared pedal print also selected UI monospace; other shared supporting text selected a different system sans. Dev.6 consistently uses the existing Redaction 50 and Arial/Helvetica sans roles from `tokens/glass.json`.

Redaction's unavailable-font fallback is the same sans. The old mono CSS/JSON names remain compatible sans aliases. Scoped pre/code/kbd/samp styling and tabular numerals prevent browser defaults from reintroducing a third family. All original font/artwork bytes, approved button colors, geometry, controls and native mappings are unchanged. Native C++ exports contain no typography and remain unchanged.

## Verification and evidence

Passed: 89 package checks, 2 site checks and 52 Chromium/WebKit browser flows (40 retained regressions plus 12 typography catalog/standalone combinations). The font audit covered 5,550 visible text/form observations and 660 code/keyboard samples with zero unexpected fonts. Per-suite results are recorded in `qa/dev6/summary.json`. Typography coverage examines computed fonts for all stories, forms, opened nested usage code, pedal print and code/kbd/samp probes. Both catalog and standalone are tested in Chromium and WebKit at desktop, mobile and 800×480. Package checks include two focused typography invariants and all retained regression tests.

Actual desktop/mobile before/after screenshots are under `qa/dev6/`; `live-before.jpg` records the inspected public baseline. See `TYPOGRAPHY.md` for the exact shared contract and explicit upgrade boundary.
