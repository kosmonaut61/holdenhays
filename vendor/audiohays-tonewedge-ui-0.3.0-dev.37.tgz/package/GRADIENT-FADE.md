# Bildpunkt gradient fade

`createGradientFade` is an independent, static background overlay. It holds a surface color through a start stop, then fades that overlay to transparent at an end stop. It can reveal a frosted material, an image or any host background. It never fades text or controls and uses no blur, mask or canvas.

## JavaScript API

Load `effects.css`. When composing the full Bildpunkt stack, use `tokens.css`, `components.css`, `glass.css`, `treatments.css`, then `effects.css`.

```js
import { createGradientFade } from '@audiohays/tonewedge-ui/effects';

const fade = createGradientFade(header, {
  direction: 90,
  start: '35%',
  end: '70%',
  color: null,
  opacity: 1,
  enabled: true,
});

fade.update({ start: 360, end: 500 }); // numbers are CSS pixels
fade.update({ enabled: false });
fade.destroy();
```

The controller exposes `update(patch)`, a copied `state`, and idempotent `destroy()`. Controls are independent:

- `direction`: finite degrees, normalized into a single 360-degree turn, default `90` (left to right in CSS gradient coordinates).
- `start`: where the full overlay color ends; default `'35%'`.
- `end`: where it becomes transparent; default `'70%'`.
- Stops accept nonnegative numbers from 0 to 16,384 in CSS pixels, nonnegative strings with `px` or `%`, or a CSS variable such as `'var(--title-end, 35%)'`. Percentages are relative to the gradient line. Choose increasing stops for a gradual fade; the host owns their relationship and responsive measurement.
- `color`: `null` to inherit `--tw-glass`, or a six/eight-digit hex color. Default `null`; the CSS fallback is warm paper. Eight-digit hex preserves color alpha independently of `opacity`.
- `opacity`: 0–1, default 1; values outside that range clamp.
- `enabled`: boolean, default `true`.

`GRADIENT_FADE_DEFAULTS` and the pure `normalizeGradientFade(patch, previous?)` helper are also exported. Malformed values leave the previous setting unchanged. State is appearance-only: no title text, typography, audio parameters or application model enters this API. `pixelSize`, palette, tint and grain belong to the [frosted material](FROSTED-SURFACE.md), not the fade.

## Foreground content and CSS-only use

The controller adds one decorative `span.tw-gradient-fade` and the host class `tw-fade-host`. It preserves existing children, classes and host styles, and rejects a duplicate fade on the same host. Destroy removes its span and restores class ownership. It can be mounted again after teardown.

The host must establish a size. Opt foreground content into the shared wrapper, or apply the equivalent `position:relative; z-index:1` to a host-owned wrapper. Arbitrary children are never repositioned or reparented.

```html
<header class="tw-fade-host">
  <span class="tw-gradient-fade" aria-hidden="true"
    style="--tw-fade-direction:90deg; --tw-fade-start:35%; --tw-fade-end:70%; --tw-fade-color:#e7e5d7f7; --tw-fade-opacity:1"></span>
  <div class="tw-surface-content">
    <h1>Existing title</h1>
    <button type="button">Existing control</button>
  </div>
</header>
```

CSS-only hosts may set those `--tw-fade-*` properties directly and use `hidden` to disable their span. JavaScript owns properties on its generated span; use `update` for that instance rather than overriding it from the host. No import from the glass module is required for the fade alone.

## Compose a title fade with frost

```js
import { createFrostedSurface } from '@audiohays/tonewedge-ui/glass';
import { createGradientFade } from '@audiohays/tonewedge-ui/effects';

const material = createFrostedSurface(header, {
  state: { palette: 'spectral', grain: 72 },
  pixelSize: 3,
  time: 7,
});
const fade = createGradientFade(header, {
  direction: 90,
  start: measuredTitleEndPx,
  end: measuredFadeEndPx,
  color: '#e7e5d7f7',
  opacity: 1,
});
```

The approved Tonewedge composition uses the explicit warm-paper alpha color above. The host measures the title end and fade end in CSS pixels relative to the header, then calls `fade.update({start, end})` when those measurements change. Measure again after relevant font/layout changes and resizing. The library does not inspect a title, choose a font size or prescribe fade distances.

Mounting order does not couple the components. `material.update({grain:40})` does not change fade stops; `fade.update({opacity:.8})` does not change the raster. Attach only the material to `createAppearance().attachMaterial`, never the fade. An inherited fade color follows semantic CSS tokens; an explicit color remains unchanged. Destroy each controller on host teardown, in either order.

## Accessibility

The overlay is `aria-hidden`, pointer-transparent and non-animated. Text and interactive content remain fully opaque above it, with their original semantics and focus behavior. Verify text contrast for the actual chosen background. Forced-colors mode and reduced-transparency preferences hide the decorative effect. Fade removal must not remove labels or carry meaningful state.
