# dev.37: Raised card surfaces

Request: increase content-card contrast against the warm light background in the HoldenHays portfolio, as a shared Bildpunkt fix.

The shared appearance derivation adds `cardSurface`, a 68% white lift from page paper in light mode. Spectral is #f8f7f3 against #e9e7d8. Optical glass/raster stock stays unchanged. In dark mode the new role is exactly the existing glass value. Glass-treatment `.tw-card` consumes the role; Minimal transparency, Hardware plates, readouts, dialogs and navigation sheets keep their existing semantics. Custom tint forwarding includes the new role. Ink and focus contrast derivation covers the new surface.

New regression coverage checks all named light/dark palettes, custom tints, body/muted text at 4.5:1, focus/control edges at 3:1, preserved Spectral optical values and unchanged dark stock. Consumer upgrades remain explicit, with no automatic runtime cascade. Host background overrides must be removed or mapped to the role.

Validation:

- Shared build and generated-output parity pass; `npm run check`: 328/328 tests pass.
- Catalog build and generated-output parity pass; `npm run check:site`: 2/2 tests pass.
- Spectral card/page contrast is 1.160:1. Body text is 13.915:1, muted text 7.047:1, focus 6.879:1 against the raised card.
- HoldenHays locally adopts the complete dev.37 package. The host removes top-level `--tw-glass !important` card overrides and derives summary gradients/legacy `--card` from the new role. ESLint, TypeScript and diff whitespace checks exit 0.
- Actual Safari verification passed for the static catalog Content card: Spectral light at desktop and 390×844, Spectral dark with no accidental white fill, and Monochrome light at 390×844. Optional glass toggles independently; mobile card header stacks its status without overflow. Portfolio Next dev and production build attempted registry.npmjs.org and were denied by execution network policy; no successful portfolio production build or actual-portfolio routing/focus verification is claimed.
- Direct remote-main verification (`git ls-remote origin`) was denied for github.com. No push, merge, registry publication or deployment has been attempted. Recheck current remote main before releasing this local candidate.

