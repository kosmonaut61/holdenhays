# Bildpunkt 0.3.0-dev.19

## Repair

Custom-tint shared buttons now shade their label area and hover in a contrast-safe direction while retaining the original Cast/Steel corner artwork. The same CSS-only behavior covers primary, neutral, signal, dark and selected carousel roles. Direct tint hosts retain their paired button label, inherited modes work, and named theme boundaries reset the added effects.

No appearance/controller API, semantic palette, material renderer, control state, geometry or named preset is changed. Disabled states keep their existing monochrome treatment.

## Verification

- 208 package/unit/build checks and 2 site/MCP checks pass.
- The shared/material action suite requires legacy caps and opt-in Cast/Steel/Glass controls to pass together, using actual screenshot pixels and unchanged semantic pairs.
- Independent verification covers named-theme exact raster comparisons, custom/stress tints, both modes and all treatments, real hover/focus/active states, CSS-only/nested/direct-host scopes, attribute changes, native semantics and visible corner texture.
- Desktop/mobile catalog smoke includes white/cyan tint controls and all retained materials/navigation/dialog/image-toggle examples. The same smoke runs after public promotion.

Exact final counts, scoped source hashes, limits and evidence are in `qa/dev19/README.md`. The reproducible comparison uses frozen dev.18 CSS as its before state.

## Scope and limits

The existing Bildpunkt site and private package build are updated. No npm publication, host application migration, physical Pi/touchscreen or screen-reader session is claimed. A historical browser-buttons harness still targets a removed catalog selector; current focused and full-catalog checks provide the relevant coverage. Custom caller colors outside the shared semantic roles require their own contrast checks.
