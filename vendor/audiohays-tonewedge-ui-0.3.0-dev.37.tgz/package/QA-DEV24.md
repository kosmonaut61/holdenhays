# Bildpunkt 0.3.0-dev.24

## One configurable physical knob

The catalog now presents the selected radial-brushed knob with its fluted rim
and projected indicator. Its settings cover label, units, range, step, size,
disabled state, cap tint, tint strength and indicator color. Old knob-study links
open this single story. Invalid ranges show a useful validation message while
leaving the last valid range intact.

The new `createKnob` factory defaults to that radial face. Color is an optional
layer over the original cap, preserving the sprite, metal lip and flutes. The
original finish and cream indicator remain the default. Caller-selected colors
are not silently altered; callers must keep the marker visible against the cap.

Existing `createRange({kind:'rotary'})` defaults, face IDs, assets and renderers
remain available for pinned consumers. This removes alternate catalog examples,
not public APIs or source assets. Housing and native input now scale together
with a minimum 44px hit target. Native, fieldset and ARIA-disabled knobs cannot
change value or activate their generated Reset action.

## Focus example

Both duration knobs now use the selected radial face. Reset uses the existing
quiet secondary-button treatment and keeps its native disabled state and 48px
minimum target. The previously white disabled button was shared monochrome
styling, not an app-specific override. Its text measured 14.04:1; disabled controls
are exempt from the WCAG text/non-text contrast minima. This change addresses
visual fit without changing palette tokens or all disabled controls.

## Verification

All 259 package tests and 2 site tests pass. Final browser, compatibility and
contrast evidence is recorded in `qa/dev24/README.md` and
`qa/dev24/release-results.json`. Chrome and WebKit checks cover native interactions,
configuration updates, adoption/cleanup, disabled states, responsive catalog and
standalone examples, Focus flow and all named light/dark appearances.

Automated browser checks are not physical-device or manual screen-reader
certification. Arbitrary custom marker colors are not claimed to meet contrast
requirements. The pre-existing WebKit catalog native-select height limitation
remains outside this change. No npm publication or installation into another
application is performed by this release.
