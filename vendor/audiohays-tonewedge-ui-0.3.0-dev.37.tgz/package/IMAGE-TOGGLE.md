# Image toggle

Load `tokens.css` and `components.css`. Image toggles work with Bildpunkt palettes, light/dark mode and material treatments. No pedal-specific identity is required.

```js
import { createImageToggle } from '@audiohays/tonewedge-ui/image-toggle';

const lamp = createImageToggle(host, {
  src: './images/desk-lamp.png',
  label: 'Desk lamp',
  pressed: false,
  disabled: false,
  pixelated: false,
  onChange: (on, event) => setLampPower(on)
});
lamp.setPressed(true); // Silent, no host callback.
lamp.setImage('./images/other-lamp.png');
lamp.update({ label: 'Reading lamp', disabled: true });
lamp.destroy();
```

- `src` is an existing image URL, resolved relative to the host document. PNG transparency creates a silhouette-shaped halo; JPEG, SVG, WebP and other normal browser images also work. Empty/unsupported executable URLs are rejected. No file picker, upload, canvas processing, storage, polling or audio operation is added. URL fetching is normal browser image loading, so use sources the host is already permitted to display. The host owns object URLs and revokes them when it is finished with them. The halo uses the image alpha and the same code-authored 2px square-cluster texture as tabs. Two offset copies avoid horizontal striping around curved artwork; it is not a rectangular backdrop or round halftone dots. Cross-origin images remain visible; their alpha-mask halo needs an image server/CSP that permits CSS masks.
- `label` is a required nonblank, meaningful accessible name and a visible caption. Keep it stable across on/off states for assistive technology. The image is decorative (`alt=""`) because the button already has a name. Broken images do not remove the caption, status or button target.
- `pressed` means **on**. Off mutes/desaturates the picture without disabling it; On eases it up 3px over 160ms and shows the tab-colored dither glow. Its body follows the original image silhouette underneath the art, with a compact 5px blur softly spreading outward. The tab texture is applied after the blur, so its square clusters stay crisp as their opacity fades. The palette gradient shares the tab indicator, accent-fill and signal roles. The separate 3px grounding shadow retains the original ink at 18% in light mode and uses neutral black at 36% in dark mode; nested light scopes reset it correctly. The image mask is never enlarged into a hard outline. The visible On/Off status and `aria-pressed` communicate state without relying on color.
- `disabled` means **unavailable**, independently of on/off. It uses native `disabled`, monochrome art, no raised/glowing effect, and an Unavailable caption. The saved pressed state is retained. Disabled fieldsets and host-applied `aria-disabled` also block activation. Native Enter/Space/click/touch behavior stays intact; there is no keydown toggle that could double-fire.
- `pixelated` defaults to `false` so arbitrary photography/illustration is not forced into pixel rendering. Set `true` for pixel-art sources. Art fits the square surface without cropping or stretching. Use `--tw-image-toggle-width` to adjust the complete control (default 192px, max 100% of its container). Native targets are at least 44px in both axes.
- `controlled:true` proposes `onChange(!pressed,event)` and waits for `setPressed`/`update` before repainting. This lets a host reject an action, await readiness, or synchronize a real device. Programmatic updates never emit callbacks. Rapid clicks in controlled mode continue proposing the inverse of the last confirmed state.
- `update({src,label,pressed,disabled,controlled,pixelated,onChange})` validates its patch before changing state. `setPressed`, `setDisabled`, and `setImage` are silent shortcuts. Getters are `pressed` and `disabled`; `element`/`root` expose the generated native button and `image`/`surface` expose its artwork. Remount replaces only this component's previous mount. `destroy()` is safe to repeat and never removes unrelated host content; calls after disposal do nothing.
- Reduced motion removes the transition and lift while retaining On/Off and the static halo. Hosts can also use `data-tw-motion="off"`. Forced colors use system-colored outlines/borders and disable decorative glow, so selection and focus remain separate signals.

## Adopt existing markup

```js
import { bindImageToggle } from '@audiohays/tonewedge-ui/image-toggle';

const toggle = bindImageToggle(existingButton, {
  image: existingImage,
  surface: artContainer,
  label: 'Desk lamp',
  pressed: engine.lampOn,
  controlled: true,
  onChange: requested => engine.requestLamp(requested)
});
```

`surface` defaults to the image's parent and must contain it. It can be inside the button, or contain the button when an existing product needs a smaller switch region. The binder adds image presentation and native toggle state without changing sibling controls or content. Supply/update `src` through the controller when changing art so its halo stays synchronized. It retains host listeners, honors prevented clicks, and restores only presentation attributes it still owns on destroy. The surrounding host owns any status text and application meaning. Do not nest interactive elements in a native button.

## Pedal compatibility

`createPedalCard` and `createFootswitch` now compose this same binder. Existing import paths, default states, all 37 finish IDs, tinting, printed codes, labels, callbacks, `enabled`/`setEnabled`, controlled-card readiness guards and `setPedal` remain available. The footswitch hit regions remain the original regions; the whole pedal does not become a new unrelated action. Pedal Edit remains separate and usable when bypass is unavailable. `createFootswitch` additionally accepts `disabled`, exposes `element`/`switchButton`, and provides `setDisabled`. There are no DSP, engine, routing or persistence changes.

The catalog's Image toggles card uses the existing pedal and **amplifier** assets as two arbitrary image examples, plus an explicitly unavailable amplifier. Its Pedal family example retains the specialized finish and editing controls. No new external art was downloaded.

## Verification

- `node --test tests/image-toggle.test.mjs tests/interaction-controls.test.mjs`
- `node tests/browser-image-toggle.mjs`: source-served Chromium/WebKit desktop/mobile behavior, palette/material modes, native keyboard/form behavior, controlled rejection, disabled fieldsets, source changes, remount/disposal, forced colors and reduced motion. `PLAYWRIGHT_PATH`, `BILDPUNKT_ENGINE`, `BILDPUNKT_WEBKIT_EXECUTABLE`, and `BILDPUNKT_QA_DIR` reuse the repository's installed-tool conventions. No generated distribution or site files are required.

- `node tests/browser-image-toggle-glow.mjs`: actual before/after browser close-ups, original-size alpha geometry, curved/transparent-hole examples, and screenshot-pixel checks for soft outward falloff with crisp dither gaps. See `QA-IMAGE-GLOW.md` for evidence and local artifact paths.
