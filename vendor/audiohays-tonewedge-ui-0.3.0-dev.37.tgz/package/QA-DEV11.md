# Bildpunkt 0.3.0-dev.11

## Requested changes
- Fixed Industrial/Minimal's mixed foreground/background roles. Original dropdown and heading measured about 1.08:1 and 1.11:1; all normal light/dark appearance roles are now paired.
- Added System, Light and Dark modes, live system preference updates and a saved mode choice. Palette and treatment remain independent. Closed/disabled controls use mode-aware monochrome.
- Refined the shared native switch with a quiet inset track, clean thumb, 44px target and reduced-motion behavior.
- Added three interactive tab directions and three carousel indicator directions. They are opt-in studies; existing defaults are unchanged.
- Matched Motion scenes to the selected material palette. The selected header shares its scene at 18% speed on the existing canvas. A visible pause control stops both; inactive, disabled, offscreen and reduced-motion headers do not schedule animation. Disclosure chevron removed, ARIA retained.
- Applied free MIT Pixelarticons to the radial menu, 17 generic module entries, search and directional controls. Retained six meaningful domain-specific module paths and custom icon/image APIs. The full icon catalog remains lazy.

## Verification
- 141 unit/package/build checks and 2 independent site/MCP checks pass.
- Chrome and WebKit at 1440px, 390px and 320px: 288 appearance states, 288 option states, 192 switch states and 42,144 contrast measurements, zero findings. Includes native control/focus contrast, mode persistence, system changes, real dark closed surfaces, disabled monochrome, keyboard, swipe and overflow.
- Six retained catalog navigation cases: 17 sections and 29 examples, history/search/state retention, keyboard, dialogs, reduced motion, forced colors and standalone.
- Four scene/header browser cases: exact theme pixels, six scenes, grayscale mono, pause, dormant closed/offscreen rendering, reduced motion and page lifecycle.
- Three stack-motion cases: physical overlap, eased geometry, interrupted reversal and reduced motion.
- Four final icon integration cases: selected static UI imports only at startup, lazy full catalog, search/paging/style, local MIT notice and zero-request standalone.
- Actual reviewed output is shown in `qa/dev11/Bildpunkt-design-review.png`; detailed per-suite results are under `qa/dev11/`.

## Scope
This updates the existing Bildpunkt site and private package artifact. It does not publish an npm release or update Tonewedge/Pi consumers. Real Pi hardware and Logic AU integration were not tested. Tab and carousel defaults await the user's choice.
