# Bildpunkt 0.3.0-dev.1 validation

This is the local, unpushed shared-system candidate. It is separate from the frozen dev.0 publication. No Pi/AU installation, deployment, audio integration, or automatic cross-application upgrade was performed.

## Scope

- The 21-story searchable catalog imports the same generated controls, material renderer, appearance module, spacing exports and catalog definitions as package consumers.
- Treatments (`minimal`, `glass`, `hardware`) are independent of eight semantic palettes, optional six-digit tint and original card-corner texture. The minimal/monochrome preset is only a convenience.
- Semantic layout roles resolve from one spacing scale into CSS, numeric JS and C++17. Shared control/assembly layout uses the aliases. Five intentional artwork/optical exceptions remain documented in SPACING.md.
- Existing controls, visualizer/material lifecycle and host callbacks retain their API. Product layouts, audio/state, guitar/pedal finishes and host-side upgrade decisions remain outside this package.

## Reproduction

`npm run check` verifies generated output and the package/native tests. `npm test --prefix site` checks the read-only catalog/MCP service. The packed-consumer test uses npm in offline mode end to end, including pack/install.

Browser tests use a normal Playwright installation with Chrome and WebKit installed. Run `node tests/browser-catalog.mjs`, `node tests/browser-glass.mjs`, `node site/tests/browser-site.mjs` and `node tests/browser-visualizer.mjs`. Each script starts its own localhost server. Optional `PLAYWRIGHT_PATH` and `BILDPUNKT_WEBKIT_EXECUTABLE` point to existing installations; no machine-specific path is embedded in the tests. The catalog and material runners write JSON plus ignored screenshots under qa; the retained-control runner writes its JSON under qa/dev1.

## Results

All final checks passed: 37 package/native tests, 2 site tests, and 24 browser flows (four suites × two engines × three viewports). See the JSON records in qa/dev1 for exact viewport results. Unit results include the packed consumer and a C++17 compilation of numeric spacing exports. Catalog checks cover search/category navigation, browser history, per-story visibility, independent treatment/palette/tint state, semantic spacing changes on actual shared components, monochrome dither, optional source corners, keyboard/pointer controls, no horizontal overflow and no external requests. Material checks cover optical controls, scenes, native rotary input, motion preferences, preserved host content, configurable pane layout, back-forward lifecycle, teardown/remount and offline standalone behavior.

The offline standalone was exercised in Chromium and WebKit with no dependent network requests. Desktop/mobile/800×480 screenshots were inspected locally for minimal monochrome and spectral glass. Images remain local QA scratch and are not required to consume the package.

## Remaining target checks

The installed desktop Chromium and WebKit engines are proxies, not the actual Pi Chromium or Logic AU host WebKit. Device performance, real audio/control integration, exact host accessibility behavior and final layout fit must be checked by each application at its chosen adoption boundary. The generic catalog does not certify that every existing host control imports Bildpunkt. Consumers must explicitly pin/vendor the new build and run their own upgrade checks.
