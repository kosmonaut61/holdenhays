# Themed card states · 0.3.0-dev.32

Built from dev31 (`ec7aa0b`) in an isolated worktree. This correction belongs to
shared `createSectionCard`, not a Tonewedge-only skin. It retains the selected
theme's surface, fade, label and caption for active, inactive and disabled cards.
Only inactive/disabled optical dither becomes monochrome. An enabled active card
has a subtle one-pixel inset edge, without changing its box or focus outline.

## Behavior and compatibility

- Removing the card's forced monochrome theme preserves host-owned theme data.
  Requested material palette/tint is retained while inactive and restored when
  active. Authored palette tables, dither renderer, pigments and assets are intact.
- Native disabled, disabled fieldsets, ARIA-disabled and inert ancestry stop
  motion and neutralize the field. A single shared document observer follows
  changes/reparenting and disconnects after the last card is destroyed. Native
  first-legend exceptions remain enabled. No callback is emitted by updates.
- The catalog gives every sheet its current appearance instead of recoloring
  closed wrappers. Ordinary disabled controls keep their existing monochrome
  roles. Content-card, image-toggle, button and other component APIs are unchanged.
- Default geometry, density opt-ins, disclosure indicators and navigation gestures
  remain. The active edge is separate from the 3px keyboard focus outline.
- Consumers need the complete dev32 package. Hosts with their own closed-wrapper
  monochrome appearance override must remove that override, as the catalog does.

## Verification

- Node 22.22.0: package build/freshness and all 308 package tests pass. Site build,
  freshness and both MCP tests pass. A packed dependency imports successfully.
- The new `browser-card-states.mjs` passes 6,256 assertions in installed Chrome
  and matched WebKit, at 1280×800, 800×480, 390×844 and 320×640. Each context covers
  eight palettes, both modes, three treatments and an explicit custom tint:
  768 theme/state combinations across all contexts. Checks compare the exact
  backgrounds/inks/fades, inspect actual raster pixels, verify the active edge
  and stable geometry, and exercise keyboard, disabled/fieldset/ARIA/inert state,
  motion restoration, first-legend behavior, reduced motion and disposal.
  Chromium additionally verifies forced-colors behavior.
- Theme regression passes both engines at 1440, 390 and 320px, including every
  palette/treatment, stored host values, search, tinted surfaces and inactive
  grayscale raster. Its old Theme link selector was narrowed to the Theme link
  because Examples now shares that utility class.
- Light/dark, desktop, landscape and narrow screenshots were visually reviewed.
  All runtime changes are byte-identical in the package, standalone attachment
  and independent site. A new explicit dev32 byte fixture protects the four
  intentional shared-file changes without rewriting older release evidence.

- The full retained catalog navigation regression passes Chrome and WebKit at
  1440×1000, 390×844 and 800×480. All 30 examples remain reachable; native
  keyboard, repeated open/close, stored values, search, Back/Forward, Escape,
  dialogs and the offline standalone export pass without application errors.
- Compact navigation passes 713 assertions across both engines at 800×480,
  1280×800, 390×844 and 320×640, retaining card density, disclosure, dial geometry,
  44px targets, keyboard/touch and interrupted/reduced-motion transitions.

Retained navigation results are in `qa/dev32/navigation/` and compact results
in `qa/dev32/compact/`. The new state matrix and source fingerprints are in
`qa/dev32/card-state-results.json`.

## Reproduce and limits

Run both builds, `npm run check`, `npm run check:site`, then
`node tests/browser-card-states.mjs`, `node tests/browser-theme-sections.mjs`,
`node tests/browser-section-navigation.mjs` and
`node tests/browser-compact-navigation.mjs`. Select existing browser tooling
with `PLAYWRIGHT_PATH` and `BILDPUNKT_WEBKIT_EXECUTABLE` where needed.

This release verifies existing light-DOM consumers. Shadow-root ancestor
availability observation is not provided by the document observer; those hosts
must mirror availability through `card.update`. Physical Pi touch/performance,
audio and Logic AU hosting are separate consumer verification steps. This does
not automatically upgrade deployed consumers or publish an npm registry release.
