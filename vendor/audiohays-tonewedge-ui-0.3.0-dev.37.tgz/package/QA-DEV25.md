# Bildpunkt 0.3.0-dev.25

## Additive rotary lifecycle

Shared rotary controls now offer optional `onGesture` observation, a configurable
wheel commit delay, and opt-in Escape cancellation. `createRange` and `createKnob`
pass these options through. The host still owns audio, persistence, live-update
cadence, editing/HUD state and asynchronous completion.

Unconfigured controls retain dev24 value and event behavior, including reentrant
wheel/reset/blur and temporary-disabled edge cases. Opted-in sessions have explicit
begin/move/fine/end/cancel phases, source-aware overlap, controlled-value ordering,
cleanup after callback failures, and silent disposal. Hosts track active sources
and their own async generation; no single editing boolean should be cleared by
an unrelated source's terminal event. See `ROTARY-LIFECYCLE.md` for the contract.

This release changes no source artwork, styles or semantic palette values. The
selected radial knob and Focus presentation remain unchanged. Existing consumers
are not automatically migrated to the new lifecycle.

## Verification

All 287 package tests and 2 site tests pass. Component verification includes native
and Chrome/WebKit tests for lifecycle, error cleanup, overlapping sources, timers,
factory updates, disabled states and exact unconfigured compatibility.

Final independent browser checks, deterministic baseline traces and frozen input
hashes are recorded in `qa/dev25/README.md` and `qa/dev25/release-results.json`.
The existing catalog and three mini-app interaction flows are checked separately
before publication. Intentional callback errors in exception tests are recorded
separately from unexpected browser errors.

Browser automation is not physical iOS/Pi hardware or audio-engine validation.
Host commit queues, network failures and asynchronous app behavior require their
own integration tests. No npm publication or consumer installation is performed
by this release.
