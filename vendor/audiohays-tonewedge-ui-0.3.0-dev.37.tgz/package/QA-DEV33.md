# Expanded section outline · 0.3.0-dev.33

Corrects the shared section-stack active edge introduced in dev32. An open
sheet now owns one inset one-pixel outline around its full header and details.
The header no longer draws a second edge across the seam. No application or
consumer pin is changed.

## Scope

- The only runtime source change is `src/section-cards.css`.
- The full-sheet overlay follows the existing paired theme ink and radius,
  does not change layout, and cannot intercept pointer input.
- Standalone section cards and active examples nested inside a detail panel
  retain their own edges. A nested example cannot activate the parent sheet.
- Closed and unavailable headers have no active sheet edge. Keyboard focus,
  material colors, dither, typography, disclosure state and motion are unchanged.
- The next overlapping sheet remains above the preceding sheet's edge.
- Package, attachment and independent-site outputs contain identical CSS.
  An explicit dev33 hash fixture protects the sole intentional runtime change
  without rewriting the dev32 or earlier release evidence.

## Verification

- Node 22: both builds and freshness checks pass, all 309 package tests pass,
  and both site/MCP tests pass.
- New `tests/browser-card-outline.mjs`: 1,628 assertions pass across Chrome and
  WebKit, at 1280×800, 800×480, 390×844 and 320×640. Each viewport covers all eight
  palettes, both light/dark modes and all three treatments (384 combinations).
- Checks cover exact full-sheet dimensions, no header seam, closed/open states,
  keyboard focus, growing detail content, retained values, native disabling and
  re-enabling, nested active examples, interrupted repeated expansion, reduced
  motion, Chromium forced colors, overflow and application errors.
- Light/dark screenshots were visually reviewed. The full shared catalog
  navigation regression also checks all retained examples, controls, keyboard,
  search, Back/Forward, dialogs, focus restoration and the offline standalone.

Run `npm run build`, `npm run build:site`, `npm run check`, `npm run check:site`,
then `node tests/browser-card-outline.mjs` and
`node tests/browser-section-navigation.mjs`. Existing browser tooling can be
selected with `PLAYWRIGHT_PATH` and `BILDPUNKT_WEBKIT_EXECUTABLE`.

This is desktop-browser validation, not physical Pi touch or Logic AU host
validation. Consumers require a separate explicit upgrade of the complete
package. This change does not update Tonewedge, Pi or an npm registry package.
