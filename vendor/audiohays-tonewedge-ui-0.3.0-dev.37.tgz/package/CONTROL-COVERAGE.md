# Current shared-control ownership · 0.3.0-dev.3

Native factories in controls.mjs create or adopt real buttons, text/textarea/color/select fields, checkbox/radio/toggle choices, rotary/fader ranges and reset actions. The shared package owns presentation, accessible control semantics, native event handling, pointer/keyboard/wheel gestures and disposal. Host callbacks retain application/audio decisions, persistent values and product data. Programmatic updates are silent.

Interaction controllers own tabs, menus, native dialogs, carousel gestures, fullscreen focus/inert/close behavior and pan scrolling. Navigation accepts host-defined destinations with silent state mirroring; pedal cards accept controlled enabled/disabled state. Existing assembly renderers remain shared. Use the controllers, not just ownership markers: markers support an audit but do not constitute adoption.

Tonewedge's integration is verified separately in its staged application. Host-owned layout, audio bridge, parameter mapping, model loading, recall and product artwork are intentional boundaries, not substitute control implementations. Actual Pi/AU and physical-device checks remain separate from desktop browser proxies.

See CONTROLS.md, INTERACTION-CONTROLS.md and UPDATE-WORKFLOW.md. The earlier extraction inventory follows for provenance and source boundaries.

---

# Bildpunkt control coverage — 0.3.0-dev.0 candidate

The current Guitar Workshop at `https://audiohays.com/guitar/` is the visual authority. This candidate is a reusable subset, not a claim of full control parity. `ASSET-TERMS.md` records the reviewed Sprite Fusion Output terms, source lineage, and remaining third-party input-rights limits; `src/assets/PROVENANCE.md` preserves the original material notices.

| Family | Candidate | Current Workshop status |
| --- | --- | --- |
| Redaction display type, case/plate/glass wear | CSS and original assets, playground | Current appearance |
| Cast cap button states | 4 sprite states, native buttons/tabs | Current |
| Steel cap button states | 4 assets, switchable `[data-tw-cap="steel"]` skin on buttons and tabs | Source study |
| Detailed parameter rotary | 12 exact metadata entries, native range and SVG pointer, selector | 14° radial is current default |
| Earlier knob faces | 7 source-backed moving indicators via `renderLegacyKnob` and `bindRotary`; original angled sprite shown as fixed-marker reference | Retained earlier/angled source, not current Workshop defaults |
| Horizontal and vertical faders | Native ranges with cast/steel thumb selector | Retained source study, not loaded in current page |
| Previous/next rocker | Native 44px buttons on shared cast cap | Current |
| Text input, select, toggle, tabs, card | CSS primitives and live specimens | Current families, simplified layouts |
| Six visualizers | Host-supplied data, explicit lifecycle | Reusable from Pi study |
| Detented navigation dial, destination icons | `createNavigationDial`, six destinations, source icon art, keyboard/pointer/cancel | Current |
| Footswitch and status LED | `createFootswitch`, original pedal art, native button and readout | Current |
| Pedal finish family | Exact 37 finish IDs/colors/printed codes, selective enamel tint, `createPedalCard` with host Edit/bypass callbacks | Current board family |
| Module directory | 23 retained entries, route-aware disabled state, `createModuleDirectory` | Retained Pi catalog, host routes decide availability |
| Effect picker, guitar list, asset/capture card | `createEffectPicker`, `createGuitarList`, `createAssetCard` with host data/callbacks and update/destroy | Current Workshop assembly shapes |
| Image/palette choice tiles | Native radio fieldsets with Workshop amp/pedal art and finish swatches | Current family, isolated specimen |
| Glass readout/meter, color/textarea fields | CSS primitives and native form controls | Current family, isolated specimen |
| Dialog/menu/disclosure | Native dialog and details/summary with case/plate treatment | Current family, isolated specimen |
| Preset carousel | Native previous/next buttons and reusable card surface | Retained source family |
| Original `knob-05-original.png` | Fixed-image reference only; baked pointer cannot move without double marking | Earlier study, not a moving source control |

`src/knobs.mjs` preserves each detailed face's center, radius and background size. Earlier projected and logical tick faces use their own source indicator geometry. Business rules, routing, storage, file IO, audio state and model prerequisites remain host-owned. Browser tests verify actual computed materials, keyboard operation and no horizontal overflow; they do not prove physical Pi or Logic host behavior.

Legacy projection provenance: `live-lab-source/angled-controls.mjs` in the frozen Tonewedge Pi lab defines `projectedMarker`, `indicatorPixels`, and `frontIndicatorPixels`. The clean angled face uses center `(30.5,17.5)`, radii `(20,12.5)`, 24 samples and a −135°…135° sweep. The short face transforms each y to `round(8 + .875 * sourceY)`; flatter then applies `round(10 + (shortY - 10) * 21 / 25)`. The straight face uses center `(31,31)` and radii 9…22. `live-lab-source/app.mjs` supplies the earlier logical tick `(round(16+11*sin(angle)), round(16−11*cos(angle)))`; `material-study.css` supplies bakelite's separate light/shadow colors. These are implemented in `src/knobs.mjs` and `src/components.css`, without the detailed 14° radial geometry substituted.
