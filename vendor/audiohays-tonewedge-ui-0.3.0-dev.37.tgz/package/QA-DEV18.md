# Bildpunkt 0.3.0-dev.18

## Requested changes
- A reusable material property system adds opt-in Cast, Steel and Glass decoration to existing surfaces and controls.
- Cast exposes grain and relief. Steel exposes brushing, direction and sheen. Glass exposes finish, refraction, grain, optical mix, flow speed and pane geometry.
- The Materials catalog uses shared tabs and native property controls to style a general-purpose project card and a working Save button. All 17 existing section IDs and 30 original story anchors remain; one new Materials story brings the total to 31.
- Existing palette roles, component layout, native semantics and lower-level Glass/Frost APIs remain independent. No existing host is automatically migrated.

## Verification
- 205 package/unit/build checks and 2 site/MCP checks pass. Package dry-run includes the new JS/CSS entry points and material documentation.
- Final Chrome/WebKit checks include 961 material/property checks, 1,256 supplementary integration checks and 280 action-contrast checks, all passing. Catalog tests cover all retained routes, property controls at 390px and 320px, and standalone use without external requests.
- Actual rendered action text stays at least 4.687:1 across the tested named palettes, custom tints, property extrema and interactive states. The supplementary normal-text minimum is 4.5005:1.
- Native form semantics, child/focus identity, disabled fieldset exceptions, inherited themes, cleanup and observer quiescence are verified. Desktop/mobile smoke passes and is repeated after publication.
- Exact evidence scope and source hashes are recorded in `qa/dev18/README.md` and its accompanying results.

## Scope
The existing Bildpunkt site and private package artifact are updated. No npm release, host application upgrade, physical Pi/touchscreen or Logic AU validation is included. Consumers explicitly attach a material and retain ownership of content, event handlers, disabled state and action semantics. Custom foreground/background pairs remain the consumer's responsibility; the standard appearance API supplies paired colors.
