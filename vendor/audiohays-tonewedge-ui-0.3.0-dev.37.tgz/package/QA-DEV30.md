# Swipeable shared tabs · 0.3.0-dev.30

## Scope

Built on dev29 commit `026cc35fee5bc4e4aa7edb8356f158e8fac774bc`.
The complete Spectral Cream retirement and saved-preference migration remain.
Horizontal tablists now keep one scrollable row instead of wrapping. Touch and
trackpad scrolling remain native; deliberate mouse drags reveal choices without
changing selection. Clicks, taps and keyboard activation retain their callbacks.
Keyboard focus, controlled selection, resizing and reopening a hidden list reveal
the relevant tab without scrolling the page. Manual activation, disabled items,
RTL, disposal and remounts retain their existing semantics.

The pixel dither, palette roles, inset baseline and 44px targets remain. The
baseline spans the entire scrolling row and keyboard focus stays inside the
clipped viewport. Vertical lists and numbered carousel indicators keep their
existing layout. Catalog and selected navigation-study overrides defer to the
shared row behavior. No palette, renderer, artwork or product-state change.

## Verification

- Both builds and freshness checks pass; 302 package tests and 2 site/MCP
  tests pass with Node 22.22.0.
- 234 focused browser assertions pass in installed Chrome and matched WebKit
  at 1440, 390 and 320px. Coverage includes the actual Materials example and
  selected navigation study, one-row geometry, no page overflow, unchanged
  dither, horizontal wheel input, two-way mouse drag, ordinary clicks after
  dragging, disabled skipping, automatic/manual keyboard activation, silent
  controlled selection, resizing, RTL, hidden-to-visible lists, remount and
  double disposal. The exact tested file hashes are recorded.
- Native Chromium touch input verifies vertical page panning from a tab
  (>20px page movement), horizontal tab scrolling without page movement or
  selection, and an intentional tap after horizontal scrolling.
- 7,822 existing tab/dialog geometry assertions pass across 288 palette,
  treatment and light/dark states in both engines and all three widths.
  Dither, baseline alignment, 44px targets, label clearance, reduced motion,
  forced colors, native dialog focus and dismissal remain covered.
- The unchanged retirement UI suite passes 38 suites and 192 appearance
  states on the combined build: both catalog entrypoints, all stories, three
  gallery apps, responsive layouts and real persisted preference migration.
  No unexpected browser exceptions.
- All original palette, raster, visualizer, state and retirement assertions
  remain. Sixteen dev28 exact-file pins remain unchanged. Only the two
  intentionally changed files, `components.css` and `interaction-controls.mjs`,
  are repinned to explicit dev30 hashes in a separate fixture. The historical
  dev28 fixture was not edited and no byte-check coverage was dropped.

Mobile tab screenshots were visually reviewed. They remain local, not committed
or uploaded. Compressed raw evidence is in `qa/dev30/results.json.gz`.

## Touch verification limits

Manually injecting a horizontal swipe, tap and then vertical pan into Chromium
intermittently leaves the page stationary. The same behavior was reproduced
using the unchanged dev29 controller with ordinary native horizontal overflow,
including with horizontal overscroll containment removed. No pointer or touch
event was prevented; viewport scale was 1 and the tablist had no vertical
overflow. Browser-native scroll gestures after a scroll reset passed in all
36 diagnostic cases. This isolates a native/synthetic chained-input limitation,
not proof that the entire physical touch sequence has been verified.

The release test asserts each pan direction from a fresh page, with the original
>20px vertical-scroll assertion, and tests horizontal swipe followed by tap
separately. Full traces, scrollable ancestor geometry, touch-action values and
old-controller controls remain in the evidence. There is no retry-to-pass in
the release test. Physical iPhone/iPad and chained native-touch behavior are
not claimed as verified; WebKit automated checks cover geometry, mouse and
keyboard behavior.

## Reproduce

Use Node 22 and set `PLAYWRIGHT_PATH` to a compatible Playwright module. On a
host with a separately installed matched WebKit build, set
`BILDPUNKT_WEBKIT_EXECUTABLE` as required. Then run:

```sh
npm run build && npm run build:site
npm run check && npm run check:site
BILDPUNKT_QA_DIR=qa/dev30/overflow node tests/browser-tab-overflow.mjs
BILDPUNKT_QA_DIR=qa/dev30/geometry node tests/browser-tab-dialog-geometry.mjs
node qa/dev30/run-retirement.mjs
```

`qa/dev30/probe-touch-sequence.mjs` reproduces the diagnostic controls. Supply
`BILDPUNKT_TOUCH_BASELINE` as the frozen dev29 checkout; use
`BILDPUNKT_TOUCH_NATIVE_CONTROL=1` for its ordinary-overflow control and
`BILDPUNKT_TOUCH_NO_CONTAIN=1` for the containment experiment.

This candidate does not promote a Pi/Logic host, edit canonical main, push or
publish. Release promotion is a separate coordinated step.
