# Retire Spectral Cream · 0.3.0-dev.29

## Scope

Based on exact dev28 commit 8a6ec29571520606076ce0f59dc8877c132aba99.
Spectral Cream is removed from the shared selectable palette list, catalog
settings and swatches, examples, and standalone comparison. Saved or incoming
Cream appearance state resolves to regular Spectral. Mode, treatment, tint,
corner texture and product state retain their existing behavior.

Regular Spectral's green/teal dark stock and all other palette colors are
unchanged. Raw token, material, native and CSS-only Cream data remain available
for older low-level consumers. Use APPEARANCE_PALETTES for menus and normalize
stored appearance state; do not treat raw map keys as selectable metadata.

## Verification

- Package and site builds/freshness checks pass; 300 package tests and 2
  site/MCP tests pass with Node 22.22.0.
- 18 shared token/renderer/control/style files match dev28 byte-for-byte.
  128 semantic/material state cases and 224 visualizer cases match exactly.
- Actual installed Chrome 156.0.8078.80 and matched WebKit 26.5 (Playwright
  1.62.1 / WebKit build 2336): 38 UI suites and 192 appearance matrix states
  pass, including both catalog entrypoints, every story, three working apps,
  320/393/1440px layouts, keyboard use, system mode and repeated selections.
- Real persisted Cream preferences migrate in the examples, preserving mode
  and unrelated storage. 108 host migration checks preserve treatment,
  dither, tint and mode through initialization, persistence and repeated
  updates. Corrupt preferences still fall back safely.
- 96 before/after rendered-style states across every remaining palette,
  light/dark/system and custom tint are exactly identical to dev28.
- 2,593 control checks and 1,680 painted control samples pass, minimum 4.69:1.
  Another 108 checkbox/radio palette/mode/treatment states pass native,
  disabled, keyboard, focus, reduced-motion and 390px layout checks.
- All 6,912 material samples across the eight remaining palettes match dev28
  exactly. Zero regressions. The broader matrix includes 135 inherited
  below-4.5:1 extreme-material samples; their ratios are unchanged. All 432
  regular Spectral dark samples pass, minimum 4.99:1.
- Six retained-interaction runs cover Chrome/WebKit at 1280×800, 390×844 and
  800×480, 17 groups/30 examples, controls, navigation history, bfcache,
  keyboard and reduced motion. No browser exceptions or external requests.

Mobile selector, Switches and calculator captures were visually reviewed in
both engines. Screenshots remain local; none are committed or uploaded.
Reproduction scripts and compressed raw evidence are in qa/dev29/.

This candidate does not migrate physical Pi, Logic AU or other consumer hosts,
edit canonical main, push, stage or publish. Those are separate release steps.
