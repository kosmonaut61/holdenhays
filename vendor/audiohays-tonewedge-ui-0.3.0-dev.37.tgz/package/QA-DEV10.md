# Bildpunkt 0.3.0-dev.10

## Requested changes

- A visible Theme workbench controls the selected component section. Closed sheets and disabled controls use the existing monochrome palette; open sheets receive the selected palette, treatment, optional tint and color overrides.
- Seventeen focused sections replace six broad buckets. Buttons, switches, faders and knobs have separate cards. Multi-example explorers use the shared native tabs, including Arrow/Home/End navigation. All 27 earlier examples remain mounted, plus the new Icons example.
- Existing 28–30px overlap, contact depth, 560ms eased layout motion, reversal continuity, native focus and reduced motion are preserved.
- All 1,036 free MIT Pixelarticons 2.4.2 are bundled from official commit c9ecc2da61afde85dbe539025e3d931c6152ad75. Unmodified SVGs, individual ES modules, original license and hash provenance are included. No Pro artwork, icon font, React runtime or CDN is used.
- Icons inherit currentColor, are decorative by default, and require a label for meaningful standalone imagery. The icon browser loads its names and first 48 definitions only when opened, then supports search, style filters, paging and copyable imports/SVG. Standalone HTML embeds the same definitions and license for offline use.

## Verification

- `npm run check`: 112 tests pass, including package install/import, exact approved palette/artwork invariants, section state restoration and icon source hashes.
- `npm run check:site`: generated-site parity plus both read-only MCP/security tests pass.
- `node scripts/generate-pixelarticons.mjs --check`: all 1,036 SVGs and adapters match pinned provenance.
- Integrated navigation: Chromium and WebKit, desktop 1440×1000, mobile 390×844 and compact 800×480. Every example, keyboard/focus, search, unique IDs, history, menus/dialogs, forced colors and standalone are exercised.
- Theme presentation: Chromium and WebKit, 1440×1000, 390×844 and 320×740; all eight palettes across three treatments, tint, exact grayscale closed raster, disabled monochrome, state retention and filtered tabs.
- Stack motion: desktop, phone and narrow phone; real frame samples verify ease-out, overlap on every frame, immediate reversal continuity, rapid cross-card selection and reduced motion.
- Integrated icons: Chromium and WebKit, desktop/phone; lazy loading, 48/96 paging, filter/style, accessible selection, preserved state, license access and complete offline standalone.
- Retained catalog and retained controls: three Chrome viewports each. Typography: three viewports across catalog and standalone. The approved Redaction 50 and Arial families remain the only computed families.
- Separate shared-component tests: disabled palette across 76 appearance combinations in each engine; icon lifecycle/race/teardown at desktop and phone in each engine; native control regression in both engines.

Generated browser JSON is in `qa/dev10/` and `qa/icons/`. Screenshots are local review outputs, not public deployment assets. No physical Raspberry Pi or Logic AU host was tested. This is a development version; there is no npm registry release or automatic consumer upgrade.
