# Working examples

The gallery at `/examples/` contains three small applications built from the same
Bildpunkt modules and tokens as the component catalog. They are reference
compositions, not new library components or a separate design system.

- **Calculator**: arithmetic, keyboard entry and reusable calculation history.
- **Focus**: configurable work/break sessions, pause/resume and session history.
- **Fieldnotes**: a small project board with editable tasks and local persistence.

Each application mounts once. The gallery presents an inert, accessibility-hidden
live preview; opening an example moves that same application into the active
workspace. Switching examples preserves its state. Back and Forward use ordinary
hash routes. Theme and mode are applied by the shared appearance controller.

Application source lives in `playground/examples/`. The build copies it to the
existing static site and rewrites imports to the same generated library modules.
Load the shared styles before the namespaced example layout styles. The example
styles do not replace control artwork or edit named palettes.

Each mount returns `destroy()` and `setActive(boolean)`. Application state is
owned by the app; shared native controls own their interactions and presentation.
A timer's elapsed time is based on timestamps, not repaint ticks. Fieldnotes data
is limited to this browser. No examples contact a backend or require an account.

These are small frontend examples, not production accounting, time tracking or
project-management services. They can be evaluated in place and adapted by
copying the application source alongside a pinned Bildpunkt build.

Palette selectors use the shared `APPEARANCE_PALETTES` list. From dev.29, saved
Spectral Cream preferences migrate to Spectral while preserving the saved
color mode. Gallery app data is untouched. See [Appearance](APPEARANCE.md).

The standalone [compact navigation specimen](playground/examples/compact-navigation.html)
shows opt-in section disclosure, comfortable/compact/responsive density, and
persistent radial labels. It is a host integration reference, not another
application in the three-app gallery, and does not process audio or save settings.
