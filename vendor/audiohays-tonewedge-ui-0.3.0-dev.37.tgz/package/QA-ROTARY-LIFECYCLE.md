# Rotary lifecycle source QA

Date: 2026-11-07. Compatibility baseline: Bildpunkt 0.3.0-dev.24,
`0dd67c562205604d11065e6c2011cc72430c0f4f`. This API changes no artwork, styles
or semantic palette tokens. It does not migrate or deploy a consumer application.

## Component checks

- `npm run build && npm run build:site && npm run check`: all 287 source/native tests
  passed after regenerating outputs.
- `npm run check:site`: 2 tests passed.
- `node --test tests/rotary-lifecycle.test.mjs tests/controls.test.mjs`: focused
  gesture/factory tests (46) passed, including exact no-option compatibility edge
  cases, invalid-option atomicity, exceptions, independent sources and timers.
- `tests/browser-rotary-lifecycle.mjs`: 41 checks each passed in Chrome
  156.0.8078.80 and WebKit 26.5. Each engine intentionally reports 11 injected
  callback exceptions; all are expected and listed separately. Zero unexpected
  page errors.
- `git diff --check`: passed.

## Behavioral coverage

Native browser keyboard, repeat, Home/End, keyboard clamp/no-motion end, pointer
capture, no-motion release, drag, 480 ms hold fine, dynamic Shift fine, normal
wheel, 250 ms wheel bursts, actual blur/capture loss, dispatched pointercancel,
Escape default/opt-in, retained and rollback cancellation, disabled native/ARIA/
fieldset checks, controlled handlers registered before and after binding,
createKnob/createRange pass-through, callback replacement, destroy/remount,
source-aware overlapping pointer/keyboard/wheel editing, clamp activity,
reentrant termination, disposal and disable within callbacks/input, callback
exceptions at begin/move/fine/hold and all-source blur/Escape exceptions.

Deterministic tests additionally cover original in-flight no-option wheel changes
after input disables/destroys a binding, wheel reentrancy from input/change/reset,
transient pointer disable/re-enable across input/keydown/hold, exact payloads,
rollback event ordering, callback failures releasing capture, and preservation of
pending wheel work after invalid factory updates.

Independent review found and helped resolve three classes before this report:
nonterminal hook exceptions leaving wheel work active, a thrown terminal hook
preventing other active sources from cancelling on blur/Escape, and over-eager
lifecycle guards changing no-option reentrant/disabled behavior. Dedicated
regressions cover the fixes. A seeded 5,000-sequence independent default trace
probe produced zero differences from the frozen original after the fixes.

## Reproduce

```sh
npm run build
npm run build:site
npm run check
npm run check:site
node --test tests/rotary-lifecycle.test.mjs tests/controls.test.mjs
PLAYWRIGHT_PATH=/Users/kosmo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright \
BILDPUNKT_WEBKIT_EXECUTABLE=/Users/kosmo/Library/Caches/ms-playwright/webkit-2336/pw_run.sh \
node tests/browser-rotary-lifecycle.mjs
```

The browser runner starts and closes a local random-port server. It reads source
modules, does not change the canonical preview server, and captures no screenshots.
Set `BILDPUNKT_QA_DIR` to a local directory to retain its JSON result.

## Limits

- Chrome/WebKit automation on Mac does not prove physical iOS/touchscreen/Pi
  hardware behavior. Pointercancel is dispatched; native capture loss and blur
  are exercised with actual captured mouse gestures.
- The new lifecycle is not yet a migrated Tonewedge host controller. The host
  retains its current controller until separate integration tests pass.
- Host audio, queue/commit versioning, network failures, asynchronous completion,
  and Workshop saves remain host responsibilities and are not tested here.
- No visual change is intended or made; this behavioral QA does not claim a new
  visual/accessibility audit of artwork or app layout.
- Final release verification is recorded in `QA-DEV25.md` and `qa/dev25/README.md`.
  Component checks alone do not establish host integration or deployment status.
