# Navigation defaults and directions

The selected defaults are **B: Pixel underline** for tabs and **C: Numbered steps** for carousel indicators. They now use the shared components throughout the catalog, including story navigation, Tone tabs, interaction tabs and the preset carousel. The four other live specimens remain available for comparison. Trying any specimen changes only its own content; it does not save a preference, change the host theme or navigate the application.

The catalog story is **Navigation → Compare styles** (`#component/navigation-options`).

## Tabs

| Option | Direction | Tradeoff |
| --- | --- | --- |
| A | Inset rail | One joined control with a clear selected cap. Strong grouping, slightly more visual weight. |
| B | Pixel underline · selected | Open labels above a crisp, stepped underline. Palette-colored 2px dither fades toward the label; a muted continuous rule joins the list underneath. |
| C | Soft pills | Separate rounded choices. Easy to scan, with more visible spacing between items. |

The default `tw-tab` skin owns the underline and a static 12px-high dither mask. The mask determines square placement, increasing density and a transparent-to-opaque rise; the active palette supplies the color. The upper half stays at or below 14% mask opacity. Its faint upper pixels reach behind the lower edge of the label, with the text always painted above them on the ordinary glass ink role. Selection uses a short eased opacity change, with no continuous animation.

The normal single-line target is 44px tall while its visible hover cap is 32px. Transparent 4px top and 8px bottom borders retain the full click/touch area; they do not add empty visual chrome. The 2px selected underline and 12px dither sit inside the cap. Horizontal `tw-tabs` lists share one 1px rule using glass ink at 18% opacity. It meets the cap’s lower edge, 8px inside the target, instead of following the outer hit-area edge. When tabs wrap it follows the last row only, never crossing a label. Long labels can wrap inside their 44px-minimum targets. Vertical lists keep each selected underline without a shared horizontal rule. Carousel indicators and the alternate rail/pill studies do not inherit this baseline. Forced colors place the rule at the full target edge in a system color and keep the existing selected and focus outlines.

Each example has the same Mix, Tone and Space panels. MIDI demonstrates the neutral disabled state and is skipped by keyboard navigation.

## Carousel indicators

| Option | Direction | Tradeoff |
| --- | --- | --- |
| A | Short tracks | Short horizontal segments establish a quiet progress rhythm. Best for a small set. |
| B | Pixel markers | Hollow squares become a larger solid square when selected. Smallest visual footprint. |
| C | Numbered steps · selected | Explicit positions on the actual shared cast-button face, including its edge texture and semantic colors. |

All three show the same presets. Every marker and arrow has a minimum 44 × 44px target; the visible mark can be smaller. Previous and next stop at the ends. There is no autoplay.

## Mounting the gallery

Load the existing token, component, control and interaction styles, then `navigation-options.css`. Appearance/treatment styles can be included as usual. The gallery inherits the host's semantic palette, light/dark mode and typography.

```js
import { mountNavigationOptions } from './navigation-options.mjs';

const gallery = mountNavigationOptions(document.querySelector('#navigation-options-demo'));
// The returned element is already appended to the host.
gallery.element;

// Removes only the owned gallery and its event handlers.
gallery.destroy();
```

The API returns `{ element, destroy }`. Destroy is idempotent. Remounting on the same host disposes the prior gallery while preserving unrelated host children and attributes. Multiple galleries have independent state and unique tab/panel IDs. `TAB_OPTIONS` and `CAROUSEL_INDICATOR_OPTIONS` export frozen option metadata; each chosen option has `selected:true` and a visible Selected label.

This remains a gallery module. Products use `createTabs` for the selected underline and `createCarouselIndicators` plus `bindCarousel` for numbered slide selection. All three are available from `@audiohays/tonewedge-ui/interaction-controls`. See [INTERACTION-CONTROLS.md](INTERACTION-CONTROLS.md) for the API. Numbered controls carry `tw-button`, so `button-edge-cast.svg`, face shading, edge, focus, disabled and press behavior come from the same primitive as every cast button. There is no gallery-specific replacement texture.

## Behavior and accessibility

- Uses the existing `createTabs` controller for automatic activation, a single tab stop per list, Left/Right wrapping, Home/End and disabled-item skipping.
- Uses the existing `bindCarousel` controller for drag/swipe, pointer cancellation and keyboard preview navigation. Marker events are outside the swipe viewport, so one arrow key never advances twice.
- Every tab has an associated, labelled panel. Inactive carousel slides are hidden from assistive technology and inert. Position changes are announced politely.
- Retains the existing typography: Redaction 50 for shared tabs/buttons and specimen headings; the gallery uses its existing sans label overrides. No new font or palette is introduced.
- Selected states use geometry as well as color. Focus rings remain visible; forced colors retain a selected outline. Disabled controls use the shared neutral roles at full opacity.
- Reduced motion removes the short slide, color and dither-selection transitions. Narrow containers reduce padding and move arrows below the indicators rather than shrinking hit targets.

## Verification

`node --test tests/navigation-options.test.mjs` covers selected metadata, shared cast-face inheritance, dither geometry, real catalog consumers, independent selections, unique IDs and ARIA relationships, keyboard/disabled behavior, swipe cancellation, boundaries, remount/disposal, detached hosts and CSS theme/motion contracts.

Real-browser verification additionally checks all six options with keyboard, clicks and drag gestures, light/dark mode, 44px targets without overlap, reduced motion, and page overflow at desktop and narrow mobile sizes.

`node tests/browser-tab-dialog-geometry.mjs` (after `npm run build`, with `PLAYWRIGHT_PATH` and optional `BILDPUNKT_WEBKIT_EXECUTABLE`) checks the compact cap and transparent target hit testing, wrapped labels, baseline exclusions, native dialog lifecycle and semantic edge across both engines at 1440, 390 and 320px. It writes local screenshots/results to `BILDPUNKT_QA_DIR` or `qa/tab-dialog-geometry`.


## Persistent radial labels

`createNavigationDial(host, {visibleLabels:true, items, initial, onSelect})`
adds persistent destination labels to the existing tactile radial navigation.
It is exported from `@audiohays/tonewedge-ui/navigation`. The default
`visibleLabels:false` retains the existing 180 × 193px icon-only footprint,
caption, art, callback semantics and gestures. Items without icons retain their
existing text fallback and do not receive a duplicate label.

The labeled footprint is 264 × 206px. The printed annulus stays 180px, the
central dial stays 76px, destinations retain separate 44 × 44px native targets,
and labels use the existing UI font at 12px. Do not shrink the entire control to
fit a smaller area: allocate this footprint or keep the default variant.
Side labels sit outside the central dial; polar labels sit below their icons.
The redundant selected caption becomes visually hidden but keeps its polite
live announcement. Committed labels also get an underline; preview keeps the
existing dither and marker without falsely changing the current destination.

Use two to six clearly named destinations for the intended layout. Short names
such as Tone, Effects, Tuner and Settings fit without clipping. Side labels wrap
up to two lines; polar labels use one line. Longer labels are visually clipped
with the complete name retained in the native title and accessible name. The
host should choose concise labels and test its own item count and translations.
The library does not invent routes, hide irrelevant actions or rename host data.

```js
const navigation = createNavigationDial(host, {
  items: destinations, initial: 'tuner', visibleLabels: true,
  onSelect: id => openWorkspace(id),
});
navigation.update({visibleLabels: false}); // silent, preserves selection/preview
navigation.update({visibleLabels: true, activeId: 'settings'});
navigation.destroy(); // releases owned nodes/listeners, restores host attributes
```

Arrow keys and Home/End preview; Enter/Space commits; Escape and pointer
cancellation restore the committed destination. Drag/release, touch and direct
button activation use the same handlers in both variants. The option must be a
boolean and invalid construction/update fails before changing label layout.
See the [compact navigation example](playground/examples/compact-navigation.html)
and `tests/browser-compact-navigation.mjs` for real-engine geometry, hit testing,
keyboard, pointer, touch, interruption and lifecycle coverage.
