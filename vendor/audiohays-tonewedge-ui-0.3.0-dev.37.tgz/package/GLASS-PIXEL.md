# Bildpunkt Glass Pixel · 0.3.0-dev.0

Local candidate only. This package is not published and does not install anything on the Pi or in Logic. Existing physical control, navigation, assembly and visualizer APIs remain compatible.

## Choose a material, not a layout

Glass is optional decoration, separate from Cards (content containers) and Lists & pickers (collections). Add it behind your own content without changing labels, actions or application data. Tonewedge is one consumer, not an API requirement.

- `createFrostedSurface(host)`: pane-free ordered-dither texture. See [FROSTED-SURFACE.md](FROSTED-SURFACE.md).
- `createGlassPlate(host)`: refracted overlay behind an existing card, header or readout. The name “plate” describes the material layer, not a content-card component.
- `createGlassField(canvas)`: direct canvas rendering with a host-supplied layout. The workbench's panes are a demonstration.
- `createGradientFade(host)`: a separate contrast layer; it does not create glass or fade foreground text.

For content layout use `.tw-card` or `createAssetCard`. For a card-shaped navigation button use `createSectionCard`. Both can compose material without transferring ownership of content or routing.

## Materials, not a screenshot skin

The approved Glass Pixel material becomes a package module and a shared opt-in stylesheet. The same renderer powers the Bildpunkt workbench, reusable preset/readout plates and the Tonewedge candidate. Warm paper and opaque control decks keep text legible. Redaction 50 provides display character; sans-serif labels and body text stay practical. Original knobs, footswitches and cast/steel button sprites remain real controls.

The single source field uses a deterministic 4×4 ordered Bayer dither with exact eight-color tables. Spectral, Cobalt Glass (`cobalt`) and Mono retain their protected tables; the five older named themes have independent authored multicolor tables. Glass samples the field at nearest integer coordinates through a curved displacement profile. There is no blur, random overlay grain, DOM screenshot capture, image-generation dependency or per-frame allocation of pixel buffers. Resolution caps at 360×180 logical pixels; device pixel ratio does not multiply cost. Multiple app plates should normally stay paused.

## Install in a host

Pin the reviewed local artifact or vendor `dist/` with its assets. Load `tokens.css`, `components.css` and `glass.css`, in that order.

```html
<section data-tw-material="glass" data-tw-glass-palette="spectral">
  <header id="preset">
    <div class="tw-glass-plate__content">Existing controls and labels</div>
  </header>
  <div class="tw-glass-panel">Opaque parameter controls</div>
</section>
```

```js
import { createGlassPlate, setGlassPalette } from '@audiohays/tonewedge-ui/glass';
const plate = createGlassPlate(document.querySelector('#preset'), {
  palette: 'spectral', material: 'frosted', mix: 80,
  // Optional. Normalized boxes, not device-specific pixel coordinates.
  layout: { header: { x: .015, y: .025, w: .96, h: .91, r: .09 } },
});
setGlassPalette(document.documentElement, 'cobalt'); // CSS semantics only
plate.update({ palette: 'cobalt' });                 // this raster's palette
plate.setPlaying(true);                             // opt-in, preference-aware
plate.destroy();                                   // preserves all host content
```

`createGlassPlate(host, options)` prepends one decorative, pointer-transparent, `aria-hidden` canvas. It never replaces, reparents or clones the host's content or controls. Repeated mounting on the same host throws before adding another canvas. Constructor failure rolls back the layer. Idempotent `destroy()` removes only that layer and restores the original class/palette attribute. The returned controller exposes `update`, `render`, `setPlaying`, `state`, `playing`, `layout`, `stats`, and `destroy`.

`options.state` accepts a partial material state. For convenience, state keys can be passed at the top level instead. Initial state is spectral / Dither Flow / frosted / 62 refraction / 48 grain / 36 drift / 68 mix. `options.layout` accepts named normalized boxes or a function of aspect ratio. `x`, `y`, `w`, `h` and `r` are normalized values. Keep text in HTML, not the canvas. Use `.tw-glass-plate__content` for an opaque readable inset.

`createGlassField(canvas, options)` exposes the approved three-pane composition directly. It accepts the same optional layout plus `time` and `onFrame({width,height,cost,average,max,frames,time})`. A field with `state:{panes:false}` is suitable for a decorative background. CSS dimensions remain the host's responsibility. A header plate defaults to one nearly full-width lens, not the workbench's three-pane layout.

Other exports are `GLASS_PALETTES` (RGB triplet tables), `createGlassRaster`, `normalizeGlassState`, `glassLogicalSize`, `glassPaneLayout` and `setGlassPalette`. `glass-tokens.json` and `glass-tokens.mjs` carry the material design tokens. New raw material names are `industrial`, `cobaltLegacy`, `ember`, `pine` and `plum`; appearance controllers map user-facing older Cobalt to `cobaltLegacy` and Cobalt Glass to the unchanged `cobalt` table. Explicit custom tints still override the table with the original single-hue ramp. `tokens.css` includes namespaced `--tw-glass-*` color and type tokens. The canonical legacy palette table retains its original five palettes and adds `spectral` and `cobaltGlass`, including native C++ output.

## Readable content in light and dark modes

The standalone raster defaults to light mode, preserving the exact original Spectral, Cobalt and Mono pixels. Appearance attachment now supplies resolved light/dark mode: dark selects authored night pigments and smoked pane stock while keeping the scene and optical settings. Even a dark material has luminous pixels, so it is not itself a semantic background for pale text. Mounting glass alone therefore does not guarantee text contrast. This applies to every raw `createGlassPlate` consumer, including cards and readouts; it is not a card-specific palette bug.

Use the existing opaque `.tw-glass-plate__content` inset for guaranteed surface/ink pairing, or compose the independent `createGradientFade` effect. The catalog's content card and readout hold a semantic backing across their entire content area, since both can have text throughout the width:

```html
<article id="card" class="tw-card">
  <header class="tw-card__header tw-surface-content">
    <strong>Weekend project</strong><span class="tw-chip">Ready</span>
  </header>
  <div class="tw-card__body tw-surface-content"><p>Plans, notes and next steps.</p></div>
</article>
```

```js
import { createGlassPlate } from '@audiohays/tonewedge-ui/glass';
import { createGradientFade } from '@audiohays/tonewedge-ui/effects';
// Load effects.css after the normal material/treatment stylesheets.
const plate = createGlassPlate(card, { material: 'frosted', mix: 100 });
const backing = createGradientFade(card, {
  start: '100%', end: '100%', opacity: .88,
  // color:null inherits --tw-glass, paired with the current semantic ink.
});
const detach = appearance.attachMaterial(plate);
// When removing the optional material or finally unmounting:
detach();
backing.destroy();
plate.destroy();
```

`.tw-surface-content` only establishes foreground stacking; it does not add padding, fonts, event handlers or a second layout. Existing content nodes retain identity and focus. A readout can add that class directly to its label, value and native meter, preserving its grid. The backing stays independent of material state, mode and tint updates. Do not attach it as a material.

The `.88` opacity is the catalog's tested composition for its normal ink, heading and status roles, not a universal contrast guarantee for arbitrary text, images or custom CSS. Verify rendered pixels for your foreground, or use a fully opaque backing. A title-only fade may taper after a measured title; a full content card must protect its body too. Keep any final `pagehide` teardown conditional on `!event.persisted` so browser back/forward caching retains both layers.

## Behavior and accessibility

- Material controls are visual state only. No microphone, network audio, model loader or bridge is imported by this package.
- Motion is paused by default and capped at 24 fps. It suspends when the document is hidden, the canvas leaves the viewport or reduced motion is enabled. A persisted pagehide/pageshow suspends/resumes without destroying the controller. Final teardown disconnects observers and listeners.
- Clear, frosted and opaque transmit 84%, 27% and 0% of the refracted source before the wet/dry mix. To request a fully solid pane, use `material:'opaque', mix:100`. The workbench's Solid mode does this without changing the stored mix control value.
- `.tw-glass-panel` is opaque. `.tw-glass-plate__content` keeps important text readable. `[data-tw-glass-solid=true]` and reduced-transparency preferences hide decorative plate canvases. Forced colors replaces materials with system colors. Hosts own labels, focus order and meaningful state.
- Physical ranges retain Arrow, Page Up/Down, Home/End, drag, fine adjustment, wheel and cancel behavior. The shared rotary binder now applies native min/max/step defaults when an attribute is omitted, preventing a zero-step drag from corrupting the range.
- Neither glass palette switching nor legacy palette selection changes guitar finish IDs, model bindings, preset state or any audio parameter.

## Validation

Run `npm run build`, `npm run build:site`, `npm run check`, and `npm run check:site`. Browser suites are `site/tests/browser-site.mjs` (retained controls) and `tests/browser-glass.mjs` (new material and integration lifecycle). Set `PLAYWRIGHT_PATH` to an existing Playwright install if it is not on the normal Node path. `BILDPUNKT_WEBKIT_EXECUTABLE` optionally selects an already-installed compatible WebKit runner. No download or package installation is required by these scripts.

The generated standalone preview embeds CSS, fonts, static images and JavaScript, including the material modules. The browser suite requires zero dependent file requests for it.

The implementation is derived from the user's approved Glass-Pixel-UI-Kit reference (Spectral and Cobalt studies), with the original repository controls retained. Asset rights remain governed by ASSET-TERMS.md and the included font license. Host-device performance still needs a real Pi and Logic WebKit smoke test before release.
