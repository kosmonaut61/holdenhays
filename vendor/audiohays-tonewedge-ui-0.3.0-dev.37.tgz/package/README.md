# Bildpunkt

A general-purpose, framework-free library of controls, content layouts and pixel materials. Tonewedge is the primary application example, alongside the Logic Audio Unit's bundled WebKit editor and the Audio Hays website. The package keeps its existing `@audiohays/tonewedge-ui` identifier for compatibility. It is intentionally private until publication decisions are made.

## Choose by purpose

- **Cards** group content, status and actions. Use `.tw-card` for a content container or `createAssetCard` for a resource/status shell. Neither owns storage, selection or application state.
- **Lists & pickers** present a collection. `createModuleDirectory` accepts your own destinations, labels and routes. Tonewedge's module catalog, effect picker and guitar list remain clearly labeled application examples; their existing APIs and defaults are retained.
- **Choices** use native radio tiles when one value must be selected from a group.
- **Materials** add optional decoration to an existing card, surface or button. `createMaterial(host, {kind:"cast" | "steel" | "glass"})` exposes properties for each kind without taking over layout or application state. See [MATERIALS.md](MATERIALS.md). Advanced glass APIs remain available: `createFrostedSurface` gives a pane-free texture, `createGlassPlate` adds a refracted overlay, and `createGlassField` paints a host canvas. These do not define a card or list layout. The gradient fade is a separate layer.
- **Section navigation** lives under Navigation: `createSectionCard` is a button that opens host-owned details, not the `.tw-card` content container.

The catalog's Cards example lets you remove its glass without changing its content. Lists & pickers starts with a neutral workspace directory, and the asset-card example starts with project files. Tonewedge variants remain available in labeled disclosures and examples. Catalog grouping and story labels come from `src/catalog.mjs`; all existing story and group IDs remain unchanged. The Materials section adds a shared Cast/Steel/Glass study before the retained advanced glass examples.

## Current candidate · 0.3.0-dev.34

Dev.34 reduces Flow scene work by preparing row/column warps once per frame and reusing linear-sized scratch storage. Exact dither pixels, palettes, speed and audio-response inputs are preserved. Other scenes and dev33 expanded-sheet outlines remain unchanged. See [verification](QA-DEV34.md).

## Expanded section outlines · 0.3.0-dev.33

Dev.33 extends the active section outline around the complete expanded sheet, including its detail body, rather than stopping at the header. Standalone card edges, theme surfaces, focus rings, collapsed states and all dev32 behavior are retained. See [Section cards](SECTION-CARDS.md) and [verification](QA-DEV33.md).

## Earlier catalog foundation · 0.3.0-dev.9

The catalog now opens as six expandable glass-pixel cards, with live examples inside each card and optional settings, documentation and Appearance. See [QA-DEV8.md](QA-DEV8.md).

The shared system includes real native-control factories and composite interaction controllers, the approved Glass Pixel blue/paper/signal-lime button roles with explicit 16px Redaction typography, lightly textured cast/steel edges and rounded corners, safe existing-element adoption, silent controlled updates and reusable reset/fader/rotary behavior. See [CONTROLS.md](CONTROLS.md), [INTERACTION-CONTROLS.md](INTERACTION-CONTROLS.md), [IMAGE-TOGGLE.md](IMAGE-TOGGLE.md), [BUTTONS.md](BUTTONS.md) and [UPDATE-WORKFLOW.md](UPDATE-WORKFLOW.md). The catalog uses the exported constructors in live native/composite stories. Tonewedge keeps application/audio data and explicitly upgrades the full package; no library process silently updates an application.

## Frost and fade · 0.3.0-dev.2

The reusable [frosted surface](FROSTED-SURFACE.md) and independent [gradient-fade effect](GRADIENT-FADE.md) extract the approved Tonewedge title treatment into shared APIs. They can be used together or separately; host title measurement, layout, audio and state remain outside the library. The catalog demonstrates both as real editable stories. See [QA-DEV2.md](QA-DEV2.md) for validation.

## Living catalog foundation · 0.3.0-dev.1

The dev.1 foundation adds a browsable, searchable catalog backed by this same versioned package, independent `minimal` / `glass` / `hardware` treatments, neutral monochrome and single-color tint, optional original dithered card corners, and semantic spacing shared by CSS, JS and native C++. The prior Glass Pixel dev.0 build remains a separate frozen release.

See [APPEARANCE.md](APPEARANCE.md) for the appearance API, [SPACING.md](SPACING.md) for shared layout tokens, and [GLASS-PIXEL.md](GLASS-PIXEL.md) for material rendering and lifecycle. Physical controls and host state APIs remain compatible. Applications explicitly pin or vendor a tested version; editing Bildpunkt does not automatically upgrade them. This candidate does not claim that all existing Tonewedge controls already consume the library. No deployment or device installation is part of this work.

## Source and outputs

Edit `tokens/source.json` for shared semantic colors, spacing and sizing. Run `npm run build` to regenerate `dist/tokens.css`, `dist/tokens.mjs`, `dist/tokens.json`, and `dist/native/tokens.hpp`. The original five palettes are transcribed from the Pi UI lab's `themes.css`. `src/components.css` provides the Workshop's material-backed buttons, pixel-underline tabs, cards, fields, toggles, rotary, fader and rocker primitives. Tabs use the selected palette-colored rising-dither underline; `createCarouselIndicators` from `./interaction-controls` provides the selected numbered steps on the same cast-button face. The alternate navigation studies remain in the catalog; see `NAVIGATION-OPTIONS.md`. `src/knobs.mjs` exports all twelve detailed Workshop knob geometries and a pure SVG pointer path generator; `renderDetailedKnob` paints a face supplied by the host. Use a native range input for value, keyboard and touch semantics. `src/index.mjs` provides theme/color helpers. The build copies CSS, JS, font, original surface/cap/knob assets and provenance to the package and static site attachment.

Palette names and semantic color keys use lower camel case (`blueHour`, not `blue-hour`) so the generated C++ names are valid. C++ keywords are rejected; the historical `case` token becomes `caseColor` in the native header, so `caseColor` cannot also be a source key. Generation fails before writing output when names are unsupported or collide.

The glass-compatible `spectral` and `cobaltGlass` palettes and strict-neutral `monochrome` palette are additive. `tokens/glass.json` holds the shared glass material and typography tokens. Dev.6 uses only Redaction 50 and the existing Arial/Helvetica sans across the shared library, catalog and examples; the legacy mono role is a sans alias. See [TYPOGRAPHY.md](TYPOGRAPHY.md).

Dev.29 retires Spectral Cream from all selection surfaces. Build palette menus from `APPEARANCE_PALETTES`, not raw token-map keys. Saved `spectralCream` appearance preferences normalize to regular Spectral without changing mode, treatment, tint or texture; raw compatibility data stays available. See [Appearance migration](APPEARANCE.md#selectable-palettes-and-retired-preferences).

Dev.30 keeps horizontal tabs in one swipeable row. Touch and trackpad scrolling are native; mouse dragging reveals tabs without selecting them. Keyboard and controlled selection keep the relevant choice visible. See [Interaction controls](INTERACTION-CONTROLS.md#tabs) and [dev.30 verification](QA-DEV30.md).

The package does **not** own product state, audio parameters, NAM assets, or Pi-specific layout geometry. Retained Tonewedge pedal finishes, artwork and module metadata support labeled application examples; they are not requirements of the general-purpose primitives. App-specific integration and data remain with each product. The material primitives and twelve detailed knob faces are reusable; they do not replace full device layouts or the Logic rig editor. The active Workshop default is `detail-14-radial`. The horizontal and vertical faders are retained source study variants rather than controls mounted by the current Workshop page. See `src/assets/PROVENANCE.md` and `src/assets/OFL.txt` before distributing any assets.

## Use

After publishing to a chosen private or public registry, pin a tested version such as `@audiohays/tonewedge-ui@0.3.0-dev.9`. For local review, use `npm pack` and install the resulting `.tgz` in an isolated consumer. Neither Logic nor the Pi should auto-update to a new major version.

In a browser app:

```html
<link rel="stylesheet" href="/vendor/tonewedge/tokens.css">
<link rel="stylesheet" href="/vendor/tonewedge/components.css">
<div class="tw-scope" data-tw-theme="industrial">
  <button class="tw-button tw-button--accent">Save preset</button>
</div>
```

The static Pi UI can vendor the two CSS files at a known package version and set `data-tw-theme` on its document root. The Logic AU build can copy the same files into its WebKit bundle. Native views may consume `dist/native/tokens.hpp` at build time; its colors are `0xRRGGBB` and it makes no assumptions about a rendering framework. For CSS already using legacy names such as `--case`, a small app-local mapping can point to `--tw-case`; migrate component by component. Do not replace app-specific layout CSS wholesale.

`examples/pi-theme-adapter.css` is a non-invasive legacy variable bridge. `examples/logic-webkit.html` shows a local-only AU bundle. Both are examples, not installed product changes. The current package targets browsers/WebKit with CSS custom properties, CSS Grid, `clip-path`, and modern ES modules; the exact Logic host WebKit and Pi Chromium versions still need a target-device smoke test before integration.

For an upgrade, pin a new exact version in each consumer, vendor its generated files, compare the interface at 800×480 and 1280×720 on Pi and 920×650 in Logic, then release that app. Rollback restores the prior version's vendored files; no live CDN is involved in Pi/Logic rendering. A separately versioned stylesheet URL can be offered to other web apps after publication.

## Playground and site attachment

Run `npm run build && npm run preview`, then open `http://localhost:8765/playground/`. `site-attachment/design-system/` is a self-contained static route ready to copy into the Audio Hays site as `/design-system/`. It has 25 browsable stories, search and category filters, per-component import examples, shared palette swatches, independent treatments and tint, interactive spacing, semantic color pickers, reset, and JSON export. Browser changes affect preview only. The export is a proposal, not a write to canonical tokens.

`site-attachment/design-system/standalone.html` embeds the same CSS and script in one file for offline review without a local server. The normal route keeps files separate for caching and future versioning.

## Publication decisions

Confirm public package name/scope and source repository ownership, license, whether source and/or CSS can be public, registry/CDN target, and release/approval policy. A public demo should be reviewed for branding and accessibility before deployment. No publishing or product integration is performed by this repository.

## Bildpunkt visualizers (0.2.0-dev.2 local branch)

Bildpunkt is the name of the shared pixel UI kit. The package identifier remains `@audiohays/tonewedge-ui` for existing consumers. This branch adds the six original Pi dither scenes as an optional, host-neutral Canvas module. It is not part of the immutable v0.1.0 release. The package has no audio, model, network, or bridge dependency; the host passes a normalized level.

The same development branch exposes twelve current Workshop detailed knob geometries, seven earlier moving knob faces, and one baked-marker reference through `./knobs`. `renderDetailedKnob` and `renderLegacyKnob` paint source-authored faces and indicators; pair either with a native range and `bindRotary` for pointer, touch, wheel and keyboard input. `./image-toggle` exposes `createImageToggle` and `bindImageToggle` for arbitrary host-owned images, with muted off, raised on, and separate disabled states. Pedal controls compose this same primitive. `./pedals` exposes the exact 37 Workshop finish assignments and a host-controlled `createPedalCard`. `./assemblies` exports `createModuleDirectory`, `createEffectPicker`, `createGuitarList` and `createAssetCard`; they accept host data and callbacks, and return update/destroy methods. The retained Pi module metadata is in `./module-catalog`. See `CONTROL-COVERAGE.md` for the exact source/behavior boundaries.

```js
import { BildpunktVisualizer, SCENES } from '@audiohays/tonewedge-ui/visualizer';
const visual = new BildpunktVisualizer(canvas, { scene: 'flow', fps: 24 });
visual.setEnergy(0.35); // host-supplied level, 0..1
visual.start();
visual.setOptions({ scene: 'orbit', tint: '#ef6a25' });
// When the view is removed:
visual.destroy();
```

`TonewedgeVisualizer` is an alias for compatibility with the Pi prototype. `SCENES` lists six visual scenes plus `off`; `createSceneRenderer(width, height, scene, tint)` is the pure pixel renderer for non-DOM consumers. The class offers `setEnergy(value, { immediate })`, `setVisual({ scene, tint })`, `setOptions({ scene, tint, fps, minPixel })`, `start()`, `stop()`, `render(time)`, and `destroy()`. It caps FPS at 30 and raster size at roughly 224×150, pauses when hidden or offscreen, respects reduced-motion preferences, and releases observers/listeners on destroy. The host owns audio input, level calculation, canvas accessibility text, and any idle-takeover behavior. The playground supplies a manual energy slider and descriptive canvas label.

The renderer is extracted from the original Tonewedge Pi UI lab at `live-lab-source/{field,visual-scenes,visualizer}.mjs`; no p5.js, Afterglow PNG assets, or native audio paths are included. The separate legacy Afterglow implementation depends on locally bundled p5.js under LGPL-2.1 and is intentionally outside this module. Before publishing the source or stylesheet under an open license, confirm rights and the license for the original Tonewedge code and name. The current repository remains private.

## Section cards and catalog navigation

The catalog has a permanent Theme area and seventeen expandable component sections. Cards, Lists & pickers, Choices and Glass are separate by purpose; section-card navigation remains under Navigation. Open a section to try live components, use its example tabs, and disclose settings or import code when needed. Search includes each story's related APIs and labeled Tonewedge examples. Back/Forward restores the selected story, and existing anchors remain stable.

Shared `createSectionCard` composes a native button, frosted material and independent fade; applications retain routing and state. Load tokens.css and components.css, then glass.css, controls.css, interaction-controls.css and effects.css, followed by treatments.css and finally section-cards.css. See [SECTION-CARDS.md](SECTION-CARDS.md).
