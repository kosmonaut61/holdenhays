# Bildpunkt 0.3.0-dev.16

## Requested correction
The optional glass content card and readout now place semantic foreground content above the existing independent fade backing. The surface follows light/dark and the selected theme while preserving subtle raw glass texture. The material remains optional and separate from layout, content and data. Catalog and package documentation show the reusable composition.

No palette roles, raw renderer, shared styles, typography, navigation geometry or API contracts are changed.

## Verification
- 187 aggregate package/unit/build checks and 2 site/MCP checks pass.
- Independent final matrix passes six Chrome/WebKit contexts at 1440, 390 and 320px: 1,839 assertions, 196 component measurements and zero failures. All eight palettes and a custom tint are covered in both modes at desktop; representative Spectral/Pine/custom tint cases cover narrow catalog and standalone views.
- Contrast is measured from the actual composited background beneath text, including canvas texture, backing, status fill and optional corner artwork. Final minima: heading 4.40:1 (large-text threshold 3:1), body 8.75:1, status 5.51:1, readout label 4.59:1 and readout value 8.75:1.
- Repeated optional-material off/remount, edited content, meter state, retained node identity/focus, raw-pixel mode invariance and final teardown pass. Chrome actual BFCache retains state at all tested widths. WebKit returns through a clean reload; its synthetic persisted lifecycle also passes.
- Forced colors passes in both installed engines. Reduced transparency is observed active and passes in Chrome. Narrow standalone views make zero ancillary requests.
- All 8,714 source/build hashes remain unchanged during final QA. Against dev.15, 8,687 protected files match exactly and seven differ only in version metadata. Shared CSS, palettes, raw renderer and unrelated component implementations are unchanged.
- Desktop/mobile production smoke passes locally and is repeated after publication. Actual before/after component screenshots and detailed compressed evidence are in `qa/dev16/`.

## Scope
This updates the existing Bildpunkt site and private package artifact. No npm release, Tonewedge/Pi upgrade, physical touchscreen or Logic AU validation is included.
