# Bildpunkt 0.3.0-dev.4 validation

Local candidate for the cleaner shared buttons and Redaction 50 wordmark. No push, deployment, Tonewedge edit or device installation was performed.

## Visual changes

- The shared button, tab and compatibility glass-button primitive now uses clean cast/steel faces with softly stepped 8px corners and sparse 1px edge texture. The previous/next rocker shares the new rest cap.
- The old doubled dark rims and separate offset backplate are removed from default actions. Labels use contrasting dark ink on light faces and light ink on the dark variant. Original cast/steel PNGs, knobs, faders and pedal art are retained unchanged.
- The catalog wordmark uses Redaction 50. The development-release label correction is retained. Package, material/catalog metadata, site package and all generated output identify dev.4.
- Default, hover, pressed, selected, disabled and keyboard focus remain distinct. Keyboard focus has a light/dark ring; the explicit previous skin no longer clips it. Monochrome previous-dark contrast is 13.05:1. All ten new cap faces have at least 7:1 normal enabled label contrast.
- High-contrast mode uses system colors and hides decorative cap layers. Cast, steel and previous labels, focus and selected outlines were visually inspected in Chrome and WebKit.

## Verification

- 86 package/unit/native tests and 2 independent site/MCP tests pass, including build/output parity and offline packed-consumer imports.
- 40 browser flows pass: six each for the button matrix, catalog, materials, frost/fade, visualizers and retained controls; two each for native factories and composite interactions. Desktop/mobile/800×480 in Chromium and WebKit where applicable. Offline standalone checks pass without dependent requests.
- New button checks exercise 216 palette/treatment/skin/variant combinations per browser viewport, outside tw-scope, plus native disabled handling, keyboard focus, source asset parity and forced-color decoration suppression.
- Before/after screenshots at actual 1× size were inspected at desktop and mobile. No horizontal overflow, page errors or unexpected external requests were observed in completed flows.
- Original raster/fade behavior, paused defaults, keyboard/pointer controls, controlled updates and teardown remain covered by existing regression suites.

Final run counts and machine-readable results are under qa/dev4. Screenshot PNGs are local ignored QA artifacts: before-buttons-desktop.png, before-buttons-mobile.png, after-buttons-desktop.png, after-buttons-mobile.png, after-page-mobile.png and after-steel-desktop.png. Final repeated button checks also write into qa/dev4/buttons.

## Upgrade boundary

No JavaScript control API, event contract or audio mapping changed. Applications must explicitly upgrade the complete reviewed generated package, including the ten new SVG assets, to receive this appearance. A CSS-only copy without its assets is incomplete. Tonewedge, Pi and Logic were not changed or certified by this package-only pass.
