# dev36: shared cool Plum

Holden requested replacing the brownish accent across all Plum themes, not a Tonewedge-only tint. This revision replaces gold/brown semantic interaction ramps with violet/lavender in both light and dark mode, and copper/gold material pigments with lavender/periwinkle. No other palettes or appearance-state shapes change. All treatments and scene renderers receive the same canonical tables.

- 325 library tests pass, including new exact Plum targets and existing contrast matrix (normal/sheened/hover labels 4.5:1, text 4.5:1, focus/edges 3:1).
- 2 site/MCP tests and generated-site parity pass.
- Chrome and WebKit palette editor checks pass: saved mode, editable fill/label, reset, palette switching, tint bypass/reversion, no JS errors.
- Light/dark buttons screenshots visually reviewed; cool purple controls and pigments, no copper/gold.
- Historical snapshot fixtures remain unchanged. Earlier tests explicitly exempt the authored Plum revision; new dev36 source hashes and target-role tests pin it.
- Source remains private under existing local-release workflow. Consumer upgrade requires complete distribution pin and target verification; no public npm publish is implied.
