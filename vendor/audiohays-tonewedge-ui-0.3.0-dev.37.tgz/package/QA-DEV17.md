# Bildpunkt 0.3.0-dev.17

## Requested changes
- Industrial, older Cobalt, Ember, Pine and Plum now have authored multicolor decorative material palettes. Their semantic paper/action colors are unchanged. Spectral, Cobalt Glass and Monochrome retain exact material palettes; explicit custom tints retain their previous rendering path.
- Shared image-toggle glow starts from the original filled silhouette, blurs outward and then receives the crisp pixel mask. This removes the expanded hard edge while preserving subtle themed dither, native state semantics and accessible controls.
- The prior release's readable card/readout backing remains intact.

## Verification
- 193 aggregate package/unit/build checks and 2 site/MCP checks pass.
- Final combined browser evidence passes four Chrome/WebKit catalog/standalone contexts: 1,898 assertions, 216 actual component measurements and 96 sampled material states. All eight palettes and custom tint are covered on desktop, with representative narrow-screen palettes and treatments.
- The supplementary material fixture passes 598 assertions, including 36 exact same-coordinate protected swatch/header/card comparisons. Contract tests retain 80 UI-color cases and 324 protected/custom-tint raster frames.
- Image-toggle checks pass 192 palette/mode/treatment cases across desktop/narrow Chrome/WebKit, covering CORS/failed-mask fallback, arbitrary alpha geometry, native keyboard/forms, disabled scopes, reduced effects and retained pedal compatibility.
- Both glow probes show smoothly decaying exterior intensity with crisp zero-valued dither gaps. The final catalog matrix measures normal text at least 5.51:1 and card/readout text at least 8.75:1 over actual composited texture.
- All 8,714 source/build hashes stayed unchanged. Semantic/action/paper roles, CSS outside the glow selectors and unrelated implementations remain unchanged.
- A WebKit focus-driver assumption was corrected after proving identical traversal in dev.16 and dev.17; affected contexts were rerun successfully. Original evidence and exact provenance remain in `qa/dev17/README.md` and `release-results.json`.
- Desktop/mobile production smoke passes locally and is repeated after publication. Actual before/after review boards and compressed measurements are in `qa/dev17/`.

## Scope
The existing Bildpunkt site and private package artifact are updated. No npm release, Tonewedge/Pi upgrade or physical hardware validation is included. Image assets themselves are unchanged; a denied cross-origin CSS mask hides only the decorative glow.
