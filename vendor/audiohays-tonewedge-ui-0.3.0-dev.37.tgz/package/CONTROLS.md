# Native controls

Bildpunkt owns the presentation, accessibility affordances and generic interaction
of these controls. Applications own audio, persistence, routing, presets and reset
meaning. Factories do not write an engine or infer application state.

```js
import {
  createButton, createInput, createSelect, createToggle, createRadio,
  createColorInput, createTextarea, createRange, createResetAction
} from '@audiohays/tonewedge-ui/controls';
// Import tokens.css, components.css, then controls.css.
```

## Shared contract

Factories accept one options object. Omit `element` to create a real native
control, or pass an existing native element to adopt it in place. `document` is
optional when there is a global Document; an adopted element's ownerDocument
always takes precedence. Adoption never clones or reparents the input and never
replaces host listeners or on-event properties.

The return value has `element`, `root`, `update(patch)` and `destroy()`.
`element` is always the native button/input/select/textarea. New labeled inputs
return a label wrapper as `root`; new ranges return a div with an associated
label. The host appends a new root. Adopted roots normally equal the element;
range `container` and choice-label `container` make root point to that existing
container without moving anything. Re-adopting the same element through the same
factory returns its mounted controller and updates only supplied options. Destroy
is idempotent and permits a fresh subsequent mount.

Common options:

- `id`, `className`, `disabled`, `value`, `name`, `title`, `required`, `readOnly`,
  `placeholder`, `min`, `max`, `step`, `checked`, `indeterminate`, `multiple`,
  `rows`, `cols`, `size`, `minLength`, `maxLength`, `autocomplete`, `accept`.
- `label` names the control. New labeled inputs get a visible associated label;
  adopted controls receive aria-label only when explicitly supplied. Existing
  labels, aria-describedby and aria-valuetext remain untouched when omitted.
- `text` sets plain textContent. Omit it when adopting buttons containing icons,
  numbers or other host content. `className` adds classes rather than replacing
  host or shared classes.
- `attrs` sets native attributes, including aria-*, data-quantum, form, hidden,
  and validation attributes. Null/false removes an attribute; true sets an empty
  boolean attribute. Event-handler attributes, HTML injection, style and class
  attributes are rejected. Use callbacks and className instead.
- `onInput`, `onChange`, `onClick`, `onFocus`, `onBlur`, `onKeyDown` receive the
  original native Event with `this` set to the native element. Replacing a callback
  with update replaces only that factory callback, not existing host listeners.

Construction, update, refresh and destroy dispatch no input/change/click events.
Native events bubble normally. Teardown removes package-owned listeners, artwork,
classes and presentation attributes, restoring the pre-adoption presentation when
it has not been changed subsequently by the host. It never restores an old value,
checked state, option list or application-supplied attribute. Newly created roots
are removed on destroy; adopted elements and host handlers remain.

The marker `data-bildpunkt-control` identifies `button`, `input`, `select`,
`toggle` or `range`. This is an inspection aid alongside actual shared styling,
gesture binding and accessibility, not a substitute for them.

## Disabled palette

Disabled controls always use Bildpunkt's existing monochrome palette, independent
of the surrounding palette or tint. This applies to native `:disabled` state
(including disabled fieldsets), ARIA-disabled shared actions, and the visible
labels, choices and artwork that belong to those controls. The enabled first
legend of a disabled fieldset keeps its active theme.

Semantic surfaces use the actual monochrome color roles. Baked-in sprite colors
are grayscaled without changing asset pixels, control values or geometry.
Disabled surfaces remain opaque so a colored parent does not tint them or weaken
label contrast. Re-enabling restores the inherited theme immediately. Native
rotary and choice overlays stay invisible except in forced-colors mode, where
system colors and real native controls take precedence.

ARIA-disabled styling does not suppress events by itself. Use native `disabled`
where available, and retain the host's activation guards for ARIA-only controls.
Nested theme roots reset artwork filters and approved button roles, so a colored
control group can live inside a monochrome shell without being grayscaled.

## Buttons, inputs, selects and toggles

`createButton` creates/adopts a native button and uses the shared tw-button skin.
A new button defaults to type=button; an adopted submit/reset button keeps its type.

`createInput` handles real inputs and textareas. `createTextarea` and
`createColorInput` are aliases. It routes checkbox/radio and range inputs through
the corresponding specialized factory. File inputs retain native restrictions:
only the browser/user can choose a nonempty file value.

`createSelect({options:[{value, label, disabled, selected}], value})` creates safe
native option elements. Omit options during adoption to preserve an existing list.
Replacing the option list does not emit change; a still-present current single
selection is retained unless value is supplied. A hidden preset select stays
hidden. No custom popup replaces native select keyboard behavior.

`createToggle` handles a checkbox, radio or button. `createRadio` is an alias.
Checkboxes/radios retain their real form state and native keyboard activation.
Button toggles are controlled by default: the host's click handler updates state,
and update({pressed:true}) sets aria-pressed silently. This avoids double toggling
an adopted button with an existing onclick. Explicit controlled:false enables a
small standalone aria-pressed toggle; it does not dispatch synthetic change.

Factory checkboxes and radios keep their 44 × 44px native target around a 20px
paper/glass cap. The cap shares the cast button's edge grain (or the inherited
steel texture), with a pixel check, a distinct mixed-state bar, and a round radio
mark. Engaged caps consume `--tw-button-primary`, `--tw-button-primary-edge` and
`--tw-button-on-primary`; neutral caps use the glass/control-edge roles. Labels
retain the existing UI font. Disabled caps stay opaque monochrome with a dashed
edge, including inherited fieldset state. Keyboard focus, label activation and
form values remain native. Forced colors restores native artwork; reduced motion
removes the short hover change. An empty radio group remains visually unselected.

The native switch presentation (`.tw-toggle input`) keeps its 56 × 44px target,
28px inset track and 20px rounded thumb. Track and thumb use the actual shared
`button-edge-cast.svg` for restrained 1px edge dither; the thumb also shares the
cast button's soft face lighting. Texture inherits `--tw-button-texture`, while
on/off colors retain the switch's contrasting semantic roles in every palette
and mode. Disabled switches keep their texture in monochrome at full opacity.
Forced colors removes decoration, and reduced motion removes the short slide.
This switch geometry is separate from the factory checkbox/radio cap.

For an existing labeled image, tint or palette radio, supply its containing label:

```js
createRadio({element: radio, container: label, choice: 'image'});
// choice: 'image' | 'swatch' | 'text'
```

The package owns the entire label hit area, checked/focus/disabled presentation,
image fit and swatch text treatment. Keep grouping, names, content and wrapper
layout in the host. Image size uses --tw-choice-image-size (default 64px); swatch
color uses --tw-choice-color, with existing child --finish supported. The label
must contain the input; it is never rebuilt. Native radio groups still share name.

## Configurable physical knob

`createKnob(options)` from the controls export is the recommended general-purpose
rotary control. It uses the radial-brushed face shown in the catalog, preserving
its source sprite, fluted rim and projected indicator geometry. It accepts every
rotary `createRange` option, including adoption of an existing native range.

```js
import { createKnob } from '@audiohays/tonewedge-ui/controls';
const amount = createKnob({
  label: 'Amount', min: 0, max: 100, step: 1, value: 56, knobSize: 80,
  capTint: '#428e89', indicatorColor: '#ffffff', tintStrength: 0.5,
  onInput: event => setAmount(Number(event.target.value))
});
host.append(amount.root);
amount.update({value: 72}); // silent host mirror
amount.update({capTint: null, indicatorColor: null}); // original finish
amount.destroy();
```

Load `tokens.css`, `components.css` and `controls.css`; use the normal appearance
styles/controller when applying app palettes and light/dark modes.

- `capTint`: optional six-digit hex color, or `null` for original artwork. It
  tints only the radial cap interior, leaving the metal lip and flutes unchanged.
- `tintStrength`: number from 0 to 1, default 0.5. The overlay mixes up to 55%
  color so even full strength retains source shading. No replacement image or
  motion is introduced. This parameter has no effect when cap tint is off.
- `indicatorColor`: optional six-digit hex color, or `null` for the original cream
  marker. The cream default stays legible against the physical dark cap in every
  palette. For custom colors, choose a marker that stays visible against the cap;
  the numeric readout remains available. Custom colors are never silently changed.
  Label/readout/focus colors inherit the host's appearance.
- `knobSize`: existing numeric pixel or CSS size option. Housing, native hit
  target, sprite and indicator scale together, with a minimum 44px housing.
- `label`, `min`, `max`, `step`, `value`, `disabled` and the native input API remain
  host-owned. Native/fieldset disabled and `aria-disabled="true"` block rotary input. Use `attrs: {'aria-valuetext': '…'}` for domain-specific units.

`createKnob` defaults to `detail-14-radial`; `createRange({kind:'rotary'})` keeps its
older `detail-14-dither` default. Existing face IDs, aliases, assets, exports and
legacy renderers are retained for consumer compatibility. Alternate face studies
are no longer presented as catalog choices. Old knob-face links open the single
knob story. This is catalog consolidation, not physical removal of those assets.
Cap tint applies only to the selected radial face. Indicator colors are supported
by the detailed faces; legacy faces retain their source indicator styling.
Invalid color/strength updates throw before changing native values or state.

## Ranges

```js
const knob = createRange({
  element: existingInput,
  face: existingKnobHousing,
  container: existingControlCell,
  kind: 'rotary',
  variant: 'detail-14-dither',
  cancelBehavior: 'retain',
  emitChange: false,
  onReset: event => hostReset()
});
knob.update({value: hostValue}); // silent repaint
knob.refresh();                 // after direct input.value writes by the host
```

Range options:

- `kind`: fader (default) or rotary. An adopted rotary requires its existing
  `face`. The face can already contain the input; nothing is reparented. A new
  rotary constructs its face and native overlay. Replacing face requires destroy
  followed by a new mount.
- `variant`: source-supported detailed or moving legacy knob key. Default is
  detail-14-dither. Aliases: angled → knob-05-clean, foreshortened → knob-05-short,
  flatter → knob-05-flatter, front → knob-straight-01. Shared source renderers
  draw the artwork and indicator, using ownerDocument rather than a global DOM.
- `knobSize`: CSS size string or pixel number for the complete rotary housing.
  The responsive --tw-knob-size variable is also supported (80px default). Source
  art and projected marker scale together: ordinary art is 80% of the housing;
  brushed/dither art retains its source 70% height. Use 120px housing for 96px
  ordinary art or 80px housing for compact 64px art.
- `orientation`: horizontal (default) or vertical. `faderLength` sets the shared
  --tw-fader-length variable; default is 136px. Use '100%' inside an explicitly
  sized compact host slot. Native track length follows the input; minimum height
  is zero. Shared thumb art/geometry stays package-owned.
- `cancelBehavior`: rollback (shared rotary compatibility default) or retain.
  Retain is required for hosts that have already sent live audio changes and must
  not silently undo them on pointercancel/lost capture. Destroy is always silent.
- `emitChange`: true by default. Wheel and completed rotary drags dispatch a
  bubbling change after input. False preserves hosts with legacy input-only
  gesture handling. Native fader pointer/keyboard events are never suppressed.
- `onGesture`: optional host-neutral rotary lifecycle callback. It reports
  begin/move/fine/end/cancel for pointer, wheel and native keyboard observation.
- `wheelCommitDelayMs`: optional nonnegative rotary wheel quiet interval (default
  0 preserves per-event change). Use 250 for immediate inputs and one burst end.
- `cancelOnEscape`: optional rotary Escape cancellation (default false).
  See [ROTARY-LIFECYCLE.md](ROTARY-LIFECYCLE.md) for payloads, event ordering,
  simultaneous sources, controlled handlers, disable and silent teardown.
- `onReset`: host callback used by triple-tap and Delete/Backspace while focused.
  No factory decides what a reset means or changes a value on the host's behalf.
- `resetButton`: a supplied button, true to request a new button, or false to omit
  it. New ranges with onReset get a button by default; adopted ranges require an
  explicit request. Place new adopted reset buttons with resetContainer/container,
  or use createResetAction separately. `resetLabel` names the reset action.

Rotaries use the shared bindRotary implementation: drag upward/right, Shift fine
drag, long-press fine mode, wheel increments and triple-tap reset. Faders preserve
native pointer dragging and add quantum-aware wheel increments, Shift-fine wheel
and triple-tap reset. For step='any', faders add Arrow/Home/End keys using
`data-quantum`; an existing host key handler that calls preventDefault wins.
Quantization follows data-quantum, then a positive step, then 1. Input IDs, limits,
step='any', quantum and formatted aria-valuetext/describedby are not rewritten.

Host value handlers should be installed before adoption. The factory's bubbling
input/change listeners then repaint the value after synchronous host clamping.
Asynchronous/direct host writes should call refresh or update. There is no global
MutationObserver or automatic document-wide decoration.

## Reset action

```js
const reset = createResetAction({
  element: partTitle, // optional legacy triple-click target
  label: 'Reset current module',
  onReset: event => hostResetPart()
});
header.append(reset.root);
```

The native button supplies ordinary Enter/Space activation. The optional title
keeps its prior listeners and gains triple-click binding; it does not become a
pretend button. Supply `button` to adopt an existing native button, or `container`
to append a new button immediately. Disabled state prevents package reset
callbacks. Re-adopting the same title/button is idempotent. This helper does not
replace host reset decisions or reset unsupported controls.

## Verification and boundaries

`node --test tests/controls.test.mjs` covers native node preservation, silent
lifecycles, cleanup/remount, hidden select options, controlled toggle callbacks,
quantum wheel/keys, rotary cancellation, source-face restoration and injected
Document rendering. The deterministic DOM harness is not a substitute for real
browser pointer, form, screen-reader or visual QA. Consumers must test their
actual compact layout and repeated rack/dialog replacement flows.

`node tests/browser-controls.mjs` is the reproducible source-served Chromium and
WebKit smoke test. It checks native drag/keyboard/choice interactions, retained
rotary cancellation, hidden selects, disabled fieldsets, compact 100px faders and
silent lifecycle. It writes progress/results JSON to qa/dev3/controls by default
(or BILDPUNKT_QA_DIR); screenshot files are ignored. PLAYWRIGHT_PATH and
BILDPUNKT_WEBKIT_EXECUTABLE may point to existing local tooling; no machine paths
are hard-coded. BILDPUNKT_ENGINE selects one engine when investigating a failure.

CSS is scoped to factory classes, uses semantic colors/spacing, preserves hidden
controls, and consumes existing tw-button/fader artwork. It never writes host
layout tokens, audio state or persistence. No HTML strings, eval, generated code
or host identifiers are needed to construct these controls.
