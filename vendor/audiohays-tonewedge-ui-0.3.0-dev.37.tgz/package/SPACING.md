# Shared spacing

`tokens/source.json` is the single source for layout spacing. The additive scale is 4, 8, 12, 16, 24, 32 and 48px, exposed as `--tw-space-1/2/3/4/6/8/12`. Existing keys and their defaults are unchanged. `spacingRoles` maps semantic names to scale keys, not duplicate pixel values. Run `npm run build` after editing the source. Do not edit generated files.

## Roles and consumption

| CSS suffix after `--tw-space-` | Default | Shared use |
| --- | --- | --- |
| `control-padding-block` / `control-padding-inline` | 8 / 16px | Buttons, tabs, inputs and disclosure summaries |
| `control-padding-compact` | 4px | Chips and color input insets |
| `component-padding` / `component-padding-compact` | 16 / 8px | Cards, readouts, dialogs, choices and assembly cards |
| `label-gap` | 4px | Labels, status rows and short text stacks |
| `control-gap` | 8px | Buttons, tabs, toggles and action rows |
| `component-gap` | 12px | Field grids, entries, assembly grids and content margins |
| `section-gap` | 24px | Module directory sections |
| `page-gutter` / `page-gutter-compact` / `page-gutter-wide` | 24 / 12 / 32px | Host page layouts; compact gutter also bounds dialogs |

Shared `components.css` really consumes these aliases, including module directories, guitar lists, effect pickers and asset cards. Prior incidental 6/7/9/10/14/18px layout values are normalized to the roles. This is an intentional layout change, not just a token inventory. Import `tokens.css` before component/treatment CSS.

The variables are independent of palettes. Changing `data-tw-theme` does not reset layout. A host can adjust a semantic role on a scope without touching colors or control geometry:

```css
.my-editor {
  --tw-space-component-padding: var(--tw-space-3);
  --tw-space-component-gap: var(--tw-space-2);
  padding: var(--tw-space-page-gutter);
}
@media (max-width: 600px) {
  .my-editor { --tw-space-page-gutter: var(--tw-space-page-gutter-compact); }
}
```

No automatic global density or breakpoint is imposed. Compact/wide gutters are explicit choices. To change the base scale globally, edit the source and rebuild, or override the primitive on `:root`. CSS custom-property references resolve where declared: a descendant-only primitive override will not rebind an inherited semantic alias. Override the semantic role on that descendant instead, as above.

## JS and native

```js
import { tokens, spacingPixels, spacingRolesPixels } from '@audiohays/tonewedge-ui/tokens';
spacingPixels['4'];                    // 16, number of pixels
spacingRolesPixels.componentPadding;   // 16
// tokens.spacingRoles.componentPadding is the scale reference "4".
```

Generated `glassTokens.spacing` preserves its numeric-array API but is now derived from this same scale. It is not a separate Glass Pixel spacing source. The JSON export retains the source scale and role mappings. The numeric JS exports are generated snapshots; use computed styles when reading a host's CSS override.

```cpp
#include <tonewedge/tokens.hpp> // use the include path chosen by the host build
int padding = tonewedge::ui::spacing::componentPadding;
int sectionGap = tonewedge::ui::spacing::sectionGap;
int largeSpace = tonewedge::ui::spacing::step12; // 48px
```

Scale values must be positive integer pixel strings up to 4096px; keys are positive integer strings up to 4096. Role values must name an existing scale key. Required shared roles cannot be deleted. Additional lower-camel-case roles are allowed; C++ keywords and generated-name collisions are rejected. Native constants use the same resolved values as JS and CSS. The host owns any device-pixel conversion.

## Deliberate boundaries

Spacing is not a scale factor for pixel artwork. Sprite slices/bevels, borders, knob and fader geometry, fixed navigation/footswitch hit regions, touch minimums and overlay coordinates stay unchanged. Five literal layout exceptions preserve artwork/optical calibration: the knob-study 7px inset, pedal-card 0/6/4px frame, module icon 2px optical alignment, and the horizontal/vertical fader-thumb −12px offsets. These are tested explicitly.

The seven previous palettes retain their names and values. The additional `monochrome` palette uses neutral equal-RGB grays and the same semantic keys. Palette and appearance remain separate choices.

This package update does not mean that every Tonewedge, Pi or Logic host control already imports Bildpunkt. Hosts must vendor/pin the candidate, migrate their own layout declarations deliberately, and verify target viewport sizes. Keep product-specific layouts and artwork calibration local. `node --test tests/spacing.test.mjs` checks generation, actual shared CSS references, changed-value propagation, source errors, preserved geometry and C++17 consumption. Browser/target-device layout QA is still required for each host integration.
