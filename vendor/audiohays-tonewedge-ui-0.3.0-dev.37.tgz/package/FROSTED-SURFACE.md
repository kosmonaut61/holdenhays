# Bildpunkt frosted surface

`createFrostedSurface` is a reusable decorative material, separate from the [gradient fade effect](GRADIENT-FADE.md). It uses the shared deterministic Bayer-dither glass raster without the floating lens composition. It is not a backdrop blur, screenshot capture or a product header component.

Use this under a card, header or other host content. Cards own content structure; lists own repeated items; this surface owns only the decorative material. Tonewedge is one application of that composition.

## Mount a material

Load `tokens.css`, `components.css`, `glass.css`, then `treatments.css` when using appearance treatments. Add `effects.css` last if composing a fade. The host owns its dimensions, typography and content layout.

```html
<header id="surface">
  <div class="tw-surface-content">
    <h1>Existing title</h1>
    <button type="button">Existing control</button>
  </div>
</header>
```

```js
import { createFrostedSurface } from '@audiohays/tonewedge-ui/glass';

const surface = document.querySelector('#surface');
const material = createFrostedSurface(surface, {
  state: { palette: 'spectral', tint: null, grain: 72 },
  pixelSize: 3,
  time: 7,
});

material.update({ palette: 'monochrome', tint: '#3157bd', grain: 55 });
material.render(11);          // deterministic scene time, in seconds
material.setPlaying(true);   // optional, preference-aware animation
material.setPlaying(false);
```

`state` accepts the glass field's visual controls; top-level state keys are also accepted when `state` is omitted. Defaults are `palette:'spectral'`, `tint:null`, `grain:72`, `scene:'dither-flow'`, `material:'frosted'`, `refraction:62`, `drift:36`, `mix:68`, and `panes:false`. Tint is `null` or a six-digit hex color; palettes are `spectral`, `cobalt` and `monochrome`. Grain, refraction, drift and mix are clamped to 0–100. Palette/tint color the raster; they do not recolor product artwork or change product state.

The pane-free default uses `layout:{}`. Refraction, pane material and wet/dry mix are glass-lens controls and do not change a pane-free field. Use `createGlassPlate` or an explicit glass field layout for lens effects. See [GLASS-PIXEL.md](GLASS-PIXEL.md) for the underlying renderer.

## Pixel scale and controller

- `pixelSize:3` requests one logical raster pixel per three CSS pixels. It does not multiply by device pixel ratio. Raster dimensions are bounded to 512 each and 65,536 pixels total; large surfaces may use a coarser effective scale to stay within that budget.
- Existing `createGlassField` and `createGlassPlate` callers can opt into `pixelSize`. Omitting it on those APIs retains their adaptive raster sizing. The frosted-surface preset defaults to 3.
- `time` defaults to 7 and fixes the initial scene. `onFrame({width,height,cost,average,max,frames,time})` reports render metrics, with costs in milliseconds.
- The controller exposes `update(patch)`, `render(time?)`, `setPlaying(boolean)`, `state`, `playing`, `layout`, `stats` and idempotent `destroy()`. State is visual only. A state read returns a copy. Pixel size and layout are mount options, not state-update controls.
- Mounting adds one `aria-hidden` canvas and owned surface classes. It never clones, reparents or replaces existing children. One glass material per host is allowed; a failed mount rolls back its layer. Destroy removes only the material layer and restores original owned classes and palette attributes. A destroyed host can be mounted again.

## Compose with appearance and fade

```js
import { createAppearance } from '@audiohays/tonewedge-ui/appearance';
import { createGradientFade } from '@audiohays/tonewedge-ui/effects';

const appearance = createAppearance(surface, {
  state: { palette: 'spectral', treatment: 'glass' },
});
const detach = appearance.attachMaterial(material);
const fade = createGradientFade(surface, { start: '35%', end: '70%' });

// On host teardown:
detach();
appearance.destroy();
fade.destroy();
material.destroy(); // existing title and controls remain intact
```

Only the material goes into `attachMaterial`. The fade has its own controls and lifecycle; it does not receive glass state. Fade `color:null` follows the host's semantic `--tw-glass` color, while an explicit fade color stays fixed. Mount or destroy the two in either order.

Place meaningful foreground content in an explicit `.tw-surface-content` wrapper, or give the host's own content wrapper `position:relative; z-index:1`. The library does not reposition arbitrary children. Keep title measurements, fade distances, font sizing, navigation, audio and product layout in the host application.

## Accessibility and motion

The canvas is decorative and pointer-transparent. Keep labels and controls in normal HTML and verify their contrast on the chosen material. Animation starts paused, is capped at 24 fps, and suspends for hidden documents, off-screen surfaces and reduced-motion preferences. Persisted page navigation suspends/resumes rendering; explicit teardown stops scheduling and disconnects listeners and observers.

Reduced-transparency preferences and `data-tw-glass-solid="true"` hide the decorative canvas. Forced-colors mode uses system surface/text colors. Do not use the material or its colors as the only indication of meaningful state.

## Optional shared source

`setSourceRenderer(factory | null)` can supply an existing scene without introducing a second canvas. The factory receives logical width and height and returns `paint(rgba, time, materialState)`. The shared frost optics, pixel scaling, visibility and reduced-motion lifecycle still apply. Passing `null` restores the original source raster.
