# Bildpunkt 0.3.0-dev.5 validation

Local candidate grounded in the approved Glass Pixel prototype. No push/deployment, Tonewedge edit or Pi installation was performed by this task.

## Evidence and appearance

The actual approved prototype was inspected in Spectral and Cobalt, alongside Signal Atlas and the published dev.4. Source values and their origin are recorded in qa/dev5/reference-values.json. The new shared blue primary (#293dc2), lime signal (#d7fa48), off-white neutral (#eeeddf), labels and edges match the prototype's base values exactly. Existing exact eight-color field ramps are unchanged.

The candidate keeps the cleaner rounded geometry and selective pixel detail, with a shallow edge instead of the prototype's stacked backplate. It does not simply recolor the catalog demo: the generated package, native factories, tabs, compatibility actions and rocker use semantic material roles. The new signal modifier is opt-in, and the catalog demo uses a real native toggle without product/audio behavior.

Normal desktop/mobile/800×480 screenshots were inspected. The blue/lime/paper comparison is direct; reference and candidate screenshots are under qa/dev5. Cast/steel texture remains independent of color, and all source PNGs and existing runtime/control implementations remain unchanged.

## Checks

Passed: 87 package checks, 2 site checks and 40 Chromium/WebKit browser flows. The button matrix covered 288 combinations per viewport/engine, 1,728 total. Machine-readable results are in qa/dev5/summary.json. Coverage includes package/output parity, offline consumer imports, source-color fidelity, 288 palette/treatment/skin/variant cases per browser viewport, actual tint contrast, keyboard focus, disabled and forced-color behavior, native on/off semantics, catalog navigation, controls, materials, frost/fade and visualizer regressions. Browser tests use installed Chromium and WebKit with no external requests.

## Upgrade boundary

Additive CSS roles: tw-button--signal and tw-glass-button--signal. Additive semantic color exports: glassTokens.button and --tw-button-* properties in tokens.css. Existing control APIs and audio contracts are unchanged. Consumers must explicitly upgrade CSS, tokens and both new edge texture SVGs together; no application updates automatically.
