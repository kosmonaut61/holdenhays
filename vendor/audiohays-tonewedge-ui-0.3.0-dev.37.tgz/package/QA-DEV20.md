# Bildpunkt 0.3.0-dev.20

## Working examples

The new `/examples/` gallery demonstrates three genuinely functional frontend
applications built from the public Bildpunkt controls, materials and tokens.

- Calculator: standard left-to-right arithmetic, contextual percentage, keyboard
  entry, error recovery and reusable session history.
- Focus: configurable work/rest sessions, timestamp-based pause/resume, hidden
  page catch-up and completed-session history for the current visit.
- Fieldnotes: editable task board/list, search and category filters, completion,
  local persistence and confirmed reset.

The gallery previews are inert and accessibility-hidden. Opening an app moves its
existing instance into the active workspace, preserving state across app routes.
Theme/mode controls affect the actual shared components in every preview and app.
The component catalog links to the gallery; the examples link back to the
components used in their recipes.

## Verification

Final checks and evidence are recorded in `qa/dev20/README.md` and
`qa/dev20/release-results.json`. Verification covers real interactions, keyboard
and dialog focus, narrow layouts, dark/light appearances, timer deadlines, safe
storage, shared-component composition and unchanged library/palette sources.
The existing desktop/mobile component-catalog smoke is also rerun.

## Scope and limits

These frontend examples do not require an account or backend. Fieldnotes data is
stored only in the current browser; calculator and Focus state are visit-only.
No npm publication, Tonewedge migration, real device/touchscreen session or full
screen-reader validation is claimed. A live deployment is verified separately
from local tests before being reported complete.
