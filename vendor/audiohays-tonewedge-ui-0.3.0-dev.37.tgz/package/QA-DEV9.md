# Bildpunkt 0.3.0-dev.9: overlapping glass deck

Replaces the flat, positively spaced card list with physical overlapping sheets. The next sheet covers the preceding foot by 30px on desktop and 28px on phones. Labels and drawn chevrons remain in the exposed strip. Shared semantic shadows and an inset light edge add contact depth; approved palette tokens, raster algorithms, authored assets, Redaction 50 and Arial are preserved.

`createSectionStack` is exported with `createSectionCard` and included in the standalone bundle. The controller animates real layout heights over 560ms with a deliberate ease-out; following sheets move with the expanding sheet. New panel content enters over 420ms. Rapid reversal starts from the displayed height. Resize and live reduced-motion changes settle to the correct intrinsic layout. The host retains routing, focus, panel visibility and demo data. No perpetual animation is added.

## Verification

- 101 package/unit/parity checks and 2 site/MCP checks pass.
- Chrome and WebKit navigation pass at 1440×1000, 390×844 and 800×480. Every one of the 27 real examples remains reachable. Coverage includes search/empty/clear, browser history, state persistence, native keyboard activation, nested dialogs, appearance, offline standalone, no overflow, reduced motion and forced colors.
- Dedicated live motion checks pass at 1440×1000, 390×844 and 320×740. They sample actual animation frames, verify continuous attached overlap, ease-out progress, title hit targets, rotating non-text chevrons, interrupted reversal, fast cross-card selection, filtered-first geometry and reduced motion. The measured immediate height jump on reversal is zero at all three sizes.
- Retained catalog, site and two-family typography cases are recorded in `qa/dev9/`.
- Screenshots were visually inspected on the Mac, including collapsed and open phone/desktop views. A short H.264 phone-sized recording is retained locally to show the actual movement.

## Tooling and limits

Installed Playwright 1.62.1 and WebKit 2336 are the matched verification toolchain. An initial attempt with an older installed Playwright reached all Chrome assertions but stalled during teardown, and could not drive WebKit correctly. Those runners were stopped and the matched local toolchain was used. A fetch of the matching npm package was blocked and not retried; an existing matching installation was found instead. No physical iPhone, Pi or Logic AU verification was performed. Existing consumers require explicit upgrades.
