# Bildpunkt 0.3.0-dev.14

## Requested changes
- Generalized image toggles accept host-owned image URLs, with muted interactive Off, eased raised On and a silhouette-shaped pixel-dither glow. Unavailable remains a distinct disabled state. Existing pedal and footswitch APIs remain supported.
- Revised action-fill accents for Industrial, legacy Cobalt, Ember, Pine and Plum. Spectral, Cobalt Glass and Monochrome retain their palette colors. Pine uses the selected quieter green-gray paper with evergreen actions and a bright yellow-green signal.
- Added shared cast texture and pixel marks to native checkbox/radio controls, including mixed and disabled states.
- Compacted the visible tab treatment and brought the connecting baseline closer, retaining 44px targets and readable fading dither.
- Added a subtle edge to shared dialog sheets so they separate from the dimmed backdrop without changing native modality or the existing card header.

## Verification
- 180 aggregate package/unit/build checks and 2 independent site/MCP checks pass.
- Final integrated matrix: Chrome and WebKit, 1440/390/320px, real catalog and standalone. All 12 contexts, 288 combined appearance states and 52,719 assertions pass with zero failures. All six standalone runs made zero ancillary requests. The same 6,539 source/build file hashes were retained throughout.
- Supplemental final suites pass 192 image-toggle cases, 96 checkbox/radio cases and 560 optional-role inheritance cases, including minimal-CSS imports and nested protected themes.
- Lowest measured contrasts: cast labels 4.676:1, check marks 4.742:1, check boundaries 4.654:1, tab text 5.106:1, selected lines 3.711:1, switch thumb/track 3.151:1, focus 4.883:1 and dialog title over actual texture 7.124:1. Protected palette roles compare exactly with the prior release.
- Native keyboard/form behavior, controlled updates, fieldset/ARIA disabled states, retained pedal Edit/hit regions, alpha-mask rejection, reduced motion, compact/wrapped tabs and native modal focus/Escape/submission all pass. Forced-colors emulation was observed active and passed in both installed engines.
- Desktop/mobile production-smoke script passes locally and is repeated after publication. Actual-component review images and compact reports with gzip details are in `qa/dev14/`.
- Three retained stack-motion cases pass at 1440, 390 and 320px, including physical overlap, live easing, interruption continuity and reduced motion.
- The old disabled-palette browser suite has an obsolete fixed-color expectation and is not included in passing counts. Final mode-aware disabled behavior is covered directly by the integrated and supplemental suites.

## Scope
This updates the existing Bildpunkt site and private package artifact. It does not publish an npm release or upgrade Tonewedge/Pi consumers. Physical touchscreen hardware, Pi hardware and Logic AU integration are outside this release.

Image alpha masks depend on browser image/CORS policy. A cross-origin image whose server rejects CSS masking still displays and toggles normally; the decorative halo disappears safely, while status, lift and accessible pressed state remain. No image uploads, canvas readback or persistence are introduced.
