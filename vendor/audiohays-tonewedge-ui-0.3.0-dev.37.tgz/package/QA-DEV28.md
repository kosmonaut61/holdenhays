# Spectral Cream readability · 0.3.0-dev.28

## Scope

Based on dev27 (5f689d8e820cfb44aa870b7211dbca1f38ecfa73). Only authored
Spectral Cream dark supporting ink is lifted, from #c8c9c5 to #e2e3db. Catalog
search placeholder and closed neutral-card captions promote existing ink
roles only while authored Cream dark is selected. Cool neutral-gray surfaces,
primary cream ink, pigments, accents, font choices and interaction state are
unchanged. Light, custom tint and all other palette colors are preserved.

## Verified

- Package build and freshness checks; 295 package tests passed.
- Site build and freshness checks; 2 site tests passed.
- Chrome and matched WebKit: 34 UI suites, 216 appearance states, no failures
  or browser exceptions. Includes all shared stories, catalog/standalone,
  three gallery apps, 320/393/1440px layouts, keyboard and repeated controls.
- 60 exact before/after scope checks for every named palette and
  light/dark/system modes, plus Cream tint. System-dark receives the lift.
- 48 painted catalog text samples covering screenshot contexts, dither/plain,
  light/dark and both engines. Small supporting text improves 6.26 → 8.05:1,
  search/closed captions 6.90 → 9.95:1; primary toggle label stays 9.17:1.
- 524 painted gallery samples: all ≥4.5:1; no decreases; light samples match
  baseline exactly. Dark minimum 6.60:1, light minimum 5.08:1. Muted focus
  labels improve 5.61 → 7.22:1; muted board summary is approximately 6.99:1.
- 2,593 control checks and 1,680 painted control samples pass; minimum 4.69:1.
- 1,728 candidate material samples against exact dev27: zero regressions.
  All 432 Cream-dark samples pass (minimum 5.38:1 at extreme material edges;
  muted minimum 6.26:1). Thirty-two inherited light-material limitations match
  the exact baseline; this is not a claim that every material setting is AAA.

The original mobile screenshot and final Chrome/WebKit mobile Switches,
gallery and material captures were visually reviewed. The original text
pairs already passed AA; this refinement improves comfortable readability
and the visual weight of the inactive pixel-font tab without changing fonts.
Ratios compare intended ink against actual composited backgrounds and account
for opacity/alpha in new page probes, rather than interpreting antialiased
edge pixels as the foreground color.

Reproduction, probe scripts and compressed raw results: qa/dev28/. Screenshots
remain local under /tmp/bildpunkt-dev28; none were uploaded or committed.
Physical consumer hosts and migrations are outside this candidate. No
canonical edits, shared staging, push or deployment performed here.
