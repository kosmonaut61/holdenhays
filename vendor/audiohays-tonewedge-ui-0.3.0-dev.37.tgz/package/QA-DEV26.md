# Bildpunkt 0.3.0-dev.26

## Spectral Cream, an explicit alternative

Spectral Cream adds warm cream-grey night surfaces while retaining Spectral's
bright blue, lime accents and multicolor pixel pigments. Its light palette and
artwork are exactly Spectral light. The current teal Spectral remains available;
defaults and existing selections are unchanged.

The Theme area offers an explicit side-by-side comparison and trial buttons.
Catalog and gallery selectors share exported `APPEARANCE_PALETTES` metadata, also
available in `catalog.appearance.palettes`. The existing appearance palette API
accepts `spectralCream`; hosts do not need new color constants or state fields.

## Verification

Package and site tests, Chrome/WebKit appearance, material, responsive and gallery
checks are recorded in `qa/dev26`. Baseline checks protect all existing semantic
colors, raw material maps, raster output, palette order and default state.
The new selector exclusion preserves existing CSS specificity.

A broader stress audit also records inherited light-mode contrast limitations,
including muted Spectral text on maximum-sheen/brushing Steel at approximately
3.99:1. These observations match dev25; this additive release does not alter the
protected light palette. New Cream dark contrast is assessed independently.

Browser verification does not replace physical device or consumer integration
checks. No consumer update, default change or npm publication is performed.
