# Bildpunkt 0.3.0-dev.3 validation

Local shared-controls candidate. No push, deployment, device installation or host audio change is performed by this repository.

## Passed

- 84 package/unit/native tests, including offline packed-consumer imports, C++17 spacing, source/output/version parity, silent control updates and lifecycle regressions.
- 2 read-only site/MCP tests. The new site --check verifies all expected generated public bytes without writing.
- 34 browser flows: catalog, material, frost/fade, retained controls and visualizer suites across Chromium/WebKit at desktop/mobile/800×480 (30), plus real native-control and composite-interaction checks in both engines (4).
- Offline standalone checks in Chromium and WebKit, without dependent requests.
- Exact approved frost raster bytes and gradient screenshot pixels remain unchanged.
- Original Signal Atlas cast artwork/geometry, explicit 16px Redaction across treatments and outside tw-scope on an 8px parent (including reset), cast/steel/previous skins, 44px targets and quiet glass/minimal surfaces were checked in the catalog. Desktop/mobile screenshots were inspected locally.

Browser result records are under qa/dev3. Run npm run check and npm run check:site, then tests/browser-catalog.mjs, browser-glass.mjs, browser-surfaces.mjs, browser-visualizer.mjs, browser-controls.mjs, browser-interaction-controls.mjs and site/tests/browser-site.mjs with a normal Playwright installation (Chrome and WebKit). Optional environment overrides select an existing installation; scripts have no embedded machine paths. Screenshot files remain ignored local QA artifacts.

## Ownership and behavior

The catalog demonstrates actual native factories and interaction controllers imported from the generated package. Adopted native elements retain identity, existing listeners and native event bubbling. Construction/programmatic updates do not synthesize input/change. Tonewedge can choose retain-on-cancel and input-only rotary behavior explicitly rather than changing its live engine semantics. Faders retain native drag/keyboard, configurable quantum and compact geometry. Menus/dialogs/fullscreen own accessible focus behavior, including WebKit click focus and immediate dialog reopen. Composite action buttons use the shared button primitive, not only an ownership marker.

## Consumer verification boundary

Tonewedge's worker separately verifies every control is managed, real host parameter/recall/bypass mappings, dynamic views, explicit hash-pinned upgrades and the disposable 32→24px gutter / 16→17px button propagation proof. That application evidence belongs to its own staged candidate; package tests alone do not certify it. Host-owned layout, product/art data, audio bridge and callbacks remain intentional responsibilities. Physical Pi controls/performance and Logic AU WebKit still need real target checks.

Old frozen production staging is separate and was not modified. Do not reuse an older stage manifest for this release without reviewing its version/file coverage.
