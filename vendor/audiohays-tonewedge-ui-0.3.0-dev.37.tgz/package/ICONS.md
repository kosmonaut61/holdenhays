# Pixelarticons in Bildpunkt

Bildpunkt vendors all **1,036 free Pixelarticons 2.4.2 icons**, as original SVGs and small framework-free ES-module definitions. The source is [halfmage/pixelarticons](https://github.com/halfmage/pixelarticons/tree/c9ecc2da61afde85dbe539025e3d931c6152ad75/svg), pinned at commit `c9ecc2da61afde85dbe539025e3d931c6152ad75`. Only the public free set is included. No paid Pro assets, upgrade/license-key code, React dependency, or icon font is bundled.

**MIT, Copyright (c) 2019 Gerrit Halfmann.** Preserve `assets/pixelarticons/LICENSE.txt` with copies and distributions. `assets/pixelarticons/provenance.json` records the upstream version, commit, source count, original byte size and aggregate SHA-256. Brand marks remain subject to their owners' trademark rights; the MIT artwork license does not grant brand endorsement.

## Use one icon

```js
import heart from '@audiohays/tonewedge-ui/icons/heart.mjs';
import { createIcon } from '@audiohays/tonewedge-ui/icons';

// The native button supplies the action name; its icon is decorative.
const button = document.createElement('button');
button.setAttribute('aria-label', 'Save favorite');
button.append(createIcon(heart));

// An icon that conveys information on its own needs a label.
const favorite = createIcon(heart, { label: 'Favorite', size: 48 });
```

Static per-icon imports let a bundler include only the selected artwork. Importing `icons.mjs` does not load a registry, other icon modules, CSS, or font. `createIcon` returns a normal SVG element; remove it with normal DOM APIs. It accepts an injected `document` for iframe/tests, numeric `size` (24 by default), `label`, `decorative`, and `className`. `iconMarkup(definition, options)` produces the same escaped markup without a DOM.

Every icon uses `viewBox="0 0 24 24"`, `fill="currentColor"`, and `focusable="false"`. It inherits the surrounding text/palette color, including disabled colors, monochrome and forced colors. Decorative icons use `aria-hidden="true"`; labeled icons use `role="img"` and `aria-label`. Explicit `decorative:false` requires a nonempty label. Prefer 24, 48 or 72 pixel sizes for the original grid. Load `icons.css` for shared alignment and catalog styling; an individual icon does not need it for color or dimensions.

For dynamic names in native browser modules:

```js
import { loadIcon, createIcon } from './icons.mjs';
const icon = await loadIcon('heart');
host.append(createIcon(icon, { label: 'Favorite' }));
```

`loadIcon` loads only `./icons/<name>.mjs`, relative to `icons.mjs`. Invalid names and missing files reject. `baseURL` may supply an alternate local directory URL; a host can instead provide `loadDefinition(name)` returning a definition or module. The API never contacts an external service by default. Raw source SVGs are in `assets/pixelarticons/svg/`; an `<img>` does not inherit its page's currentColor, so use inline SVG for palette-aware UI.

## Optional icon browser

```html
<link rel="stylesheet" href="./icons.css">
<div id="icon-browser"></div>
```

```js
import { createIconCatalog } from './icon-catalog.mjs';
const browser = createIconCatalog(document.querySelector('#icon-browser'));
await browser.ready;
browser.setQuery('arrow'); // silent host-controlled update
browser.setStyle('sharp'); // all, base, sharp, glyph or solid
await browser.whenReady();
browser.destroy();
```

Mount only when the Icons story opens. The catalog imports its names manifest then, loads only the first 48 icon definitions, and adds pages on request. Searching and style filtering reset the page; the module cache reuses already loaded art. It uses Bildpunkt's shared native control factories and semantic colors, with visible names, keyboard focus and pressed states. Select an icon for a 48px preview and per-icon import or SVG snippet. If browser clipboard permission is unavailable, Copy selects the textarea for manual copying.

Required styles are `tokens.css`, `components.css`, `controls.css`, the chosen treatment styles, then `icons.css`. The catalog imports `controls.mjs` and its existing dependencies. Optional `pageSize` is clamped to 12–120, default 48. `onSelect(name, definition)` fires on user activation only. The controller returns `element`, `ready`, `state`, `setQuery`, `setStyle`, `whenReady` and `destroy`. Destroy removes only its own subtree, detaches controls, and prevents stale async loads from rendering. Retry is offered for missing local modules; empty search results are announced.

For a self-contained offline page, inject both names and artwork:

```js
const browser = createIconCatalog(host, {
  names: Object.keys(embeddedDefinitions),
  loadDefinition: name => embeddedDefinitions[name]
});
```

`embeddedDefinitions` is a host build artifact mapping names to `{name, paths:[{d, opacity?}]}`. With both options supplied the browser performs no dynamic imports or requests. Do not place this full artwork map in ordinary pages; retain per-icon modules and the lazy catalog there.

## Source checks and packaging

`node scripts/generate-pixelarticons.mjs --check` verifies all original SVG bytes against pinned provenance and compares all generated per-icon modules and the manifest. Omit `--check` to regenerate these adapters offline. The generator preserves the two source paths that use opacity and rejects unrecognized SVG content. There are no downloaded runtime scripts.

Copy `icons.mjs`, `icon-catalog.mjs`, `icon-manifest.mjs`, `icons.css`, `icons/*.mjs` and `assets/pixelarticons/**` into distribution/site outputs. Keep the original MIT license in every distributed bundle. Per-icon modules also carry the copyright and a relative license path. The package exposes the optional browser separately; no root-package import needs the complete set.

## Shared UI usage

The radial menu, generic module-directory entries, search and directional controls use static per-icon imports. These chosen icons load with their controls; the 1,036-name browser and the remaining artwork stay lazy until the icon catalog opens. SVGs inherit `currentColor`, are decorative inside labeled buttons, and do not reduce their touch targets. Custom domain artwork for tuner, metronome, amp and pedal categories remains where the free library has no clearer equivalent. The standalone build embeds the same selected definitions and requires no requests.
