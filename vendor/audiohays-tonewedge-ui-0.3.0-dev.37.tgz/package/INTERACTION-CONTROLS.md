# Bildpunkt interaction controls

Framework-free controllers for tabs, native dialogs, menus, carousels, fullscreen visuals and deliberate pan scrolling. Product state, audio commands, preset order, artwork, text and rendering remain in the host. Import from `@audiohays/tonewedge-ui/interaction-controls` and load the package's `components.css`, `controls.css` and `interaction-controls.css` alongside tokens and the selected treatment. The native-control module supplies ordinary buttons, fields, selects, toggles and ranges.

Composite action buttons use the actual shared `tw-button`/`tw-control-button` presentation, while the composite owns their interactions. Existing native controllers are not replaced or destroyed by composite adoption. Tabs use the shared `tw-tab` pixel underline with palette-colored dither fading toward the label and a muted continuous baseline beneath horizontal lists. Numbered carousel indicators use the same cast `tw-button` primitive as action buttons. Controllers use `addEventListener`, retain adopted DOM nodes and IDs, and do not remove host listeners or reparent content. They expose `element`, `update()` and idempotent `destroy()`. Rebinding the same controller kind to the same element disposes its previous bindings. Disposal restores attributes/classes installed by the controller without overwriting later host attribute changes. Host values and content remain intact. Generated tab buttons and navigation/pedal children are removed on disposal; pre-existing children stay.

Construction and controlled updates do not dispatch `input`/`change`, select callbacks, or audio writes. Real user events bubble normally. Deliberate pan gestures suppress the following accidental click, as described below. Do not leave an old host keyboard/pointer implementation installed alongside the corresponding shared controller. Native click/form/state callbacks that still belong to the product can remain.

## Tabs

```js
const tabs = createTabs({
  element: existingTablist,
  buttons: [driveButton, eqButton, roomButton],
  items: [{id:'drive'}, {id:'eq'}, {id:'room'}],
  activeId: 'drive',
  panelIds: 'rack',
  onSelect(id, event) { chooseView(id); }
});
tabs.update({activeId:'eq'}); // Silent controlled synchronization.
tabs.setValue('room');
tabs.destroy();
```

- `element` is optional when creating a new tablist. `items` can supply `{id, label, element, panelId, disabled}`; absent item elements are created and appended. `buttons` adopts an existing list without moving it. Without `items`, IDs are inferred from `data-tab-id`, button value, existing ID, then index.
- `panelIds` accepts one shared panel ID, an ID array, or an object keyed by item ID. Tabs receive `role`, `aria-selected`, `aria-controls`, stable IDs and roving `tabindex`; panels receive `role=tabpanel` and `aria-labelledby`.
- Horizontal Left/Right or vertical Up/Down (`orientation:'vertical'`) wrap, skipping disabled/hidden tabs. Home/End select endpoints. Default `activation:'automatic'` selects on arrow navigation. `activation:'manual'` moves focus only; native button Enter/Space activates through click.
- Horizontal tabs stay in one row and overflow within the list instead of wrapping. Swipe on touchscreens, scroll horizontally with a trackpad, or drag with a mouse. Dragging only reveals choices; it never selects a tab or changes a panel. Ordinary clicks and taps still select. Keyboard focus, active-ID changes, and resize keep the relevant tab visible without moving the page. Native touch scrolling preserves vertical page gestures; mouse drags suppress only their accidental click. No extra wrapper or host button replacement is needed. The shared pixel underline, baseline, 44px targets, reduced-motion behavior and palette roles stay intact. Vertical lists and numbered carousel indicators retain their existing layout.
- Panel visibility is host-owned by default. Set `managePanels:true` to apply `hidden` for distinct tab panels. A shared panel is labelled by the selected tab.
- Return values include `buttons` and `value`. `setValue(id)` and `update({activeId})` are silent; `null` clears selection while leaving one keyboard entry point. `update({onSelect})` replaces the callback. Item structure is fixed until remount.

### Numbered carousel indicators

`createCarouselIndicators(options)` has the same options, return shape and lifecycle as `createTabs`. It shares that controller implementation, including manual activation, disabled-item skipping and silent controlled updates. It adds `tw-carousel-indicators` to the tablist and `tw-carousel-step tw-button tw-control tw-control-button` to each native button. It does not add `tw-tab`, so the numbered cast face cannot accidentally inherit the underline texture.

```js
import { createCarouselIndicators } from '@audiohays/tonewedge-ui/interaction-controls';

const indicators = createCarouselIndicators({
  element: slideTablist,
  items: [{id:'clean', panelId:'slide-clean'}, {id:'echo', panelId:'slide-echo'}],
  activeId: 'clean',
  onSelect(id) { showSlide(id); }
});
indicators.buttons.forEach((button, index) => {
  button.setAttribute('aria-label', `Slide ${index + 1} of 2`);
});
indicators.setValue('echo'); // Silent mirror after swipe or previous/next.
```

Generated buttons default to `01`, `02`, and so on. `items[].label` can override the visible label; adopted button content is preserved. Give the list and each slide a meaningful accessible name. Keep the indicator list outside the swipe viewport to avoid two controllers responding to the same arrow key. Selected steps use the existing primary button roles plus a text underline, so selection does not depend on color alone. The shared cast edge asset and surface shading are unchanged. All targets are at least 44px; wider lists can wrap without shrinking them.

## Native dialogs

```js
const dialog = createDialog({
  element: existingDialog,
  trigger: openButton,
  closeButtons: [cancelButton, closeButton],
  initialFocus: () => firstField,
  returnFocus: () => menuButton,
  onOpen(event) { startPreview(); },
  onClose(returnValue, event) { stopPreview(); },
  onCancel(event) { /* preventDefault() here only if closing must be blocked. */ }
});
dialog.open(); // Alias: showModal().
dialog.close('saved');
```

The element must be a native `<dialog>`. `showModal()` supplies real browser focus containment, modal backdrop and background inertness. The controller does not intercept form submission: validation, submit events, host `preventDefault()`, and `method="dialog"` / submitter return values work natively. Escape emits native `cancel`; cancel handlers can prevent closing. All native `close` listeners still run.

`open()` and `close(value)` invoke lifecycle callbacks for explicitly requested opening/closing. `update({open:true|false, returnValue?})` synchronizes the native state without invoking package `onOpen`/`onClose`. Native `close` events still happen when a dialog is closed, including by an update, because suppressing them would break host cleanup. `update` also accepts callback replacements. `isOpen` reads the native state. Return focus chooses a supplied target/function, the visible connected opener, then the trigger. Safari pointer openings track the actual trigger even when clicking a button does not focus it. A stale queued close event never steals focus from a reopened dialog or invokes package cleanup against the newer open state; existing native close listeners still receive it. Destruction only unbinds; it does not close a host-owned open dialog.

### Card-material dialog header

Pass an existing semantic `<header>` inside the native dialog to opt into the same frosted sheet and title fade as section cards. Load `glass.css` and `effects.css` as well as the interaction styles. The heading remains a real heading, not a clickable section-card button; its ID and the dialog’s `aria-labelledby` stay host-owned.

```html
<dialog id="save-dialog" aria-labelledby="save-title">
  <header id="save-header"><h3 id="save-title">Save preset</h3></header>
  <form class="tw-dialog__body" method="dialog">
    <label class="tw-field"><span>Name</span><input class="tw-input" id="save-name"></label>
    <button class="tw-button" value="saved">Save</button>
  </form>
</dialog>
```

```js
const dialog = createDialog({
  element: document.querySelector('#save-dialog'),
  header: document.querySelector('#save-header'),
  trigger: openButton,
  initialFocus: document.querySelector('#save-name')
});
const detach = appearance.attachMaterial(dialog.material);
// On teardown: detach(); dialog.destroy();
```

`header`, `material` and `fade` are exposed on the dialog controller; they are `null` without the opt-in header. The material uses the existing `createFrostedSurface` 3px lattice, 72% grain and no inset panes. The separate `createGradientFade` uses the section-card 58%→100% horizontal paper fade. A 1px edge mixes 28% of the paired glass ink into the sheet color, separating the whole dialog from its dimmed backdrop in every palette and mode without another pane or heavy chrome. Forced colors use CanvasText for this edge. The sheet body continues the same glass paper and paired inks; the normal input/button surfaces and semantics remain unchanged. A compact viewport keeps the whole sheet within the viewport and allows its body to scroll.

The header is static by default. Hosts can update its material/fade independently without touching content or form values. If a host explicitly enables material playback, it runs only while the native dialog is open and visible; native form/Escape/host close, reduced motion, background visibility and teardown stop the loop. Rebinding disposes the previous decorative layers and observers. `destroy()` removes only owned layers/classes, keeps the heading/form/value nodes, and does not close a host-owned open dialog. The two catalog dialog examples use this exact composition and follow the shared Appearance controls.

## Menus

```js
const menu = createMenu({trigger: menuButton, element: existingMenu});
menu.open();
menu.close({focus:true});
menu.update(); // Refresh dynamically inserted items.
```

Existing `hidden` determines initial visibility. The controller assigns menu/item roles and `aria-controls`/`aria-expanded`, preserves original item click listeners, and manages ArrowUp/Down/Home/End, Escape, Tab dismissal, outside pointer dismissal and focus return. Trigger Up opens at the last item; Down opens at the first. Disabled/hidden items are skipped. A menu item that opens a dialog keeps focus in that dialog rather than having it stolen back.

`items` can be a list or getter; otherwise native buttons, links and menuitem-role elements are discovered dynamically. Optional `onSelect(id,event,item)` receives `data-value`, explicit `value`, then ID. Selection closes the menu after the host's native target listener. Optional `onOpen`/`onClose` are visibility lifecycle callbacks. `open({last,focus,silent})`, `close({focus,silent})`, `toggle()`, `isOpen` and silent `update({open})` are available. Opening through update does not move focus. Item content and handlers remain host-owned.

## Carousel

```js
const carousel = bindCarousel(carouselRegion, {
  track, previous: previousButton, next: nextButton,
  getIndex: () => activeIndex,
  onStep: step => recallAdjacentPreset(step),
  onBoundary: edge => recallBoundaryPreset(edge)
});
```

The host selects the actual preset, determines saved/unsaved ordering, and paints art/counts. Compose `createCarouselIndicators` for the selected numbered steps. `onStep` receives `-1`/`1`; `onBoundary` receives `'first'`/`'last'`. Left/Right and Home/End are package-owned; editable descendant controls keep their native keys. A focusable carousel uses the host's accessible name and instructions.

The preserved swipe decision is `abs(dx) >= 32` and `abs(dx) > abs(dy) * 1.25`, exposed as pure `swipeStep(dx,dy)`. Dragging previews the track with a clamped ±100px, 2px-quantized displacement. The selected index changes only on release. Cancellation, lost capture or Escape restore the host index without a callback. A second pointer is ignored. Child buttons/inputs do not start carousel drags. `update()` synchronizes track position and cancels an unfinished drag. Images, slide roles, meaningful labels, inactive-slide inertness and bounds remain host responsibilities. The catalog example clamps at each end, synchronizes the numbered indicator, and announces the current position without autoplay.

## Fullscreen visual overlay

```js
const overlay = bindFullscreenOverlay(existingOverlay, {
  initialFocus: exitButton,
  returnFocus: () => currentVisibleEntryButton,
  inertElements: [device],
  closeButtons: [exitButton],
  onOpen() { createAndStartVisualizer(); },
  onClose() { destroyVisualizer(); }
});
```

This is an in-page fullscreen surface, not the browser Fullscreen API. The package owns `hidden`, modal semantics, focus containment, Escape, close-button handling, and restoration of each background element's original `inert` state. Supplied accessible names and host content are retained. The host decides whether opening is allowed, coordinates idle timers, and starts/stops its renderer. `open()`/`close()` return whether state changed; `update({open})` is silent. `destroy()` restores inertness and focus and hides an active overlay without a lifecycle callback.

Close buttons receive `tw-fullscreen-overlay__close`: a transparent full-inset click/touch target with a visible inset keyboard-focus outline. Use one close button for a tap-anywhere visual. Enter/Space remain native button activation. Do not put unrelated actionable controls underneath that dismiss target. A supplied focus-return function should provide a current connected fallback when the originating view may have been removed.

## Pan scrolling

```js
const scrolling = installPanScrolling(document);
// Host layout uses data-pan="x" or data-pan="y" on scrollable regions.
scrolling.update(); // Optional explicit refresh after inserting regions.
scrolling.destroy();
```

The shared binder preserves the original 7px deliberate-drag threshold, CSS-scale adjustment, pointer-type metadata, scroll-snap suspension, pointer capture and decaying inertia. Text, range, color, select and editable fields are excluded; radio/checkbox taps still work. Ordinary taps remain native. After a real drag, clicks within that region are suppressed for 500ms to avoid activating a dragged item. Cancellation/lost capture restore snapping immediately; destroy cancels animation frames, releases capture, restores snap styles and removes its listeners. Extra pointers do not replace an active gesture.

`data-pan` remains host-owned. Dynamic region markers are refreshed by `MutationObserver` (when available) or explicit `update()`. Regions receive `data-bildpunkt-pan="x|y"` and a `pan-scroll` control marker only when they do not already have a more specific shared-control identity. Product layout still determines region dimensions, overflow and axis. No touch-debug URL logging remains.

## Navigation dial additions

`createNavigationDial(host,{items,initial,onSelect})` retains the six catalog defaults when `items` is omitted. Custom items accept `{id,label,icon}`; icon can be an image URL, SVG path-data string, or `{src}`/`{path}`. Existing `image`, `src`, and `path` fields also work. Custom relative images resolve against the host document, while default package art resolves against the module. IDs must be unique. Geometry is 180×193px: 44px orbit controls at a 68px radius and a 76px central dial. Any positive item count is supported.

The returned controller adds `element`, `buttons`, `knob`, silent `setValue(id)` and `update({value|activeId})`. Arrow/Home/End preview; Enter/Space commit. Escape/cancellation restore the committed destination. `select(id)` preserves its existing explicit callback-emitting behavior for compatibility. `value` and `preview` expose committed and preview IDs. Labels, destinations and callback effects remain host-owned.

The selected destination occupies an annular segment inside the dial's printed ring. A static, palette-colored 2px dither dissolves toward the inner rim and clears a 24px bed behind each icon; icon ink stays fully opaque in light and dark mode. The outer arc marks the committed page while the dither follows keyboard or drag preview. Keyboard focus outlines the complete segment in the semantic focus color, and the central dial keeps a round focus ring. Decorative sector SVGs are hidden from assistive technology and never expand the 44px pointer targets. They adapt to custom item counts and are removed with their buttons on teardown. Reduced motion removes the brief opacity easing; forced colors replace the dither with system-color selection and focus edges. Native/ARIA disabled destinations inherit the shared neutral palette without changing selection values.

## Image toggles

`createImageToggle` and `bindImageToggle` turn arbitrary host-owned image URLs into accessible toggles. See [IMAGE-TOGGLE.md](./IMAGE-TOGGLE.md) for the shared primitive, disabled/off distinction, lifecycle, controlled state, and pedal compatibility.

## Pedal card additions

`createPedalCard(host,{id,label,enabled,disabled,controlled,editLabel,toggleLabel,onToggle,onEdit})` returns `element`, `editButton`, `switchButton`, `setEnabled`, `setDisabled`, `setPedal`, `update`, and getters for `id`, `enabled` and `disabled`.

`disabled:true` disables the footswitch without blocking Edit. `controlled:true` makes a user click propose `onToggle(!enabled,id)` without changing paint until the host calls `setEnabled` or `update`. This preserves engine-readiness/rejection guards. The default remains uncontrolled for compatibility. Programmatic methods are silent. Default accessible labels are `Enable/Bypass ${label}` and `Edit ${label} controls`; `toggleLabel` may also be a function `(enabled,id,label) => string`. Identity and labels are supplied by the host, not inferred from the visual component.

## Verification

- `node --test tests/interaction-controls.test.mjs` covers state, controlled silence, retained nodes/listeners, keyboard navigation, disabled items, cancellation, remounts, disposal, pan inertia and custom navigation/pedal contracts.
- `node tests/browser-interaction-controls.mjs` uses installed Playwright (or `PLAYWRIGHT_PATH`) for real Chromium and WebKit native modal/form/focus, menu-to-dialog handoff, carousel/pan gestures, controlled pedals and repeated disposal. `BILDPUNKT_ENGINE` can select one engine. `BILDPUNKT_WEBKIT_EXECUTABLE` can select an existing supported WebKit executable.
- Browser focus/form behavior cannot be proven by a synthetic DOM alone. The browser suite is source-served and does not rebuild or deploy the product.
