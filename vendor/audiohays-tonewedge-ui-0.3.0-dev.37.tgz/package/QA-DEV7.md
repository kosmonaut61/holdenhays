# Bildpunkt 0.3.0-dev.7 review

Local card-navigation candidate. Publication is handled separately. No Tonewedge/Pi changes or service restarts.

All four supplied reference images were materialized on the Mac and visually inspected before implementation. Images 1 and 3 informed rounded labeled cards; image 2 informed active-card/detail behavior; image 4 identified the remaining hard More actions border. Their colors were not adopted.

The catalog now uses the actual shared section-card primitive: native shared button + shared static ordered-dither frost + separate shared gradient fade. Search, category filtering, appearance settings and existing real controls remain available. One selected card reveals one detail section; all-stories mode remains available explicitly. Keyboard arrows/Home/End browse cards, Enter/Space opens them, and browser Back/Forward restores selection. No routing service or external state is involved.

Hard card/dialog/disclosure/menu frames and inset/offset UI shadows were removed in shared source styles, including the hardware treatment. Physical knob/fader/button art, focused outlines and forced-color boundaries remain. The approved palette tokens, raster ramps, two-family typography and button geometry remain unchanged. The latest requested case cleanup changes the wordmark to “Bildpunkt” and uses natural/title case in catalog and shared status/pedal labels; genuine abbreviations, IDs and legal text remain intact.

Final counts, comparison screenshots and source invariants are recorded in qa/dev7/summary.json. See SECTION-CARDS.md for the reusable API and its explicit upgrade boundary.

## Final verification

Passed 99 package/unit/parity checks, 2 site/MCP checks and 58 Chrome/WebKit browser flows: 40 retained regressions, 12 typography catalog/standalone combinations and 6 new navigation combinations. Both browsers cover desktop, mobile and 800×480. All 26 stories pass the natural-case audit. Font coverage contains 5,926 visible text/form observations and 684 code/keyboard samples with zero unexpected families.

The Show all state uses separate `expanded` visibility rather than false collapsed announcements. Back/Forward moves keyboard focus out of newly hidden details. The phone navigation is a full-width single-column stack, Buttons is initially fully visible, and opening the borderless More actions disclosure leaves its neighboring button at 44px.

The final toolchain is Playwright 1.62.1 with its matching WebKit revision 2336 and installed Chrome. An earlier mismatched Playwright/WebKit combination stalled even when closing two blank tabs. The matching pair passes without product-side workarounds.

Shared palette/raster/typography/spacing token fixtures remain exact, excluding the development-version field. All authored assets and native token exports remain unchanged. New shared exports are `./section-cards` and `./section-cards.css`; load the latter after treatment/effect styles. Existing applications must deliberately upgrade their pinned library.
