# Bildpunkt 0.3.0-dev.35 robustness candidate

Based on dev.34, commit 8f4b08c. This is a locally tested candidate, not a published release.

## Implemented

- Scoped hidden protection prevents shared flex/grid skins from displaying hidden controls and panels. Class tokens separated by any HTML whitespace are supported. Unrelated host content is untouched, and the new rule excludes hidden="until-found".
- Native single-row select controls have an explicit minimum 44px height for Safari. Multiple selects and size > 1 listboxes retain native sizing.
- Asset-card status/content updates preserve the existing native action elements and keyboard focus. An explicit actions replacement creates new actions and invalidates callbacks on detached buttons.
- Nested tw-scope text inherits semantic ink rather than dark seam color, retaining readable dark-mode text.
- Card, glass, fade, and treatment positioning defaults have zero specificity, so application fixed/absolute/sticky positioning is not overridden simply by loading the kit later.

## Validation

- npm run build and npm run build:site passed.
- npm run check: 322 tests passed.
- npm run check:site: 2 tests passed, including the read-only MCP catalog.
- Exact source/generated/site parity checks passed. Palette and raster historical baselines remain intact. Only the six intentional component files are repinned in the dev35 fixture.
- Focus regression was observed failing before the fix and passes after it.
- Browser regression runner: tests/browser-asset-card-focus.mjs. Manual fixtures: tests/fixtures/robust-controls.html and tests/fixtures/treatment-boundaries.html.

## Release gates still open

No browser rendering or interaction checks were completed. Browser inventory was empty; native Safari and Chrome accessibility attachment both timed out. Source-contract CSS tests are not rendered-browser verification. Run desktop/phone Chromium and Safari/WebKit checks, including actual component use in each candidate consumer, before publication or promotion.

An approved read-only remote check subsequently verified main at dev33 commit 77eafd3. The connected GitHub plugin could not see this repository; no permission or publication settings were changed. No push, registry publication, website deployment, Pi installation or production consumer promotion was attempted.

Nested treatment leakage is deliberately not fixed in this candidate. See QA-TREATMENT-BOUNDARIES.md for the exact case and compatibility-safe follow-up. A broad treatment rewrite needs its own browser matrix.
