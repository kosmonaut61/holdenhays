# Opt-in compact navigation · 0.3.0-dev.31

Built from dev30 commit `57fb9f0d4ab3df128f6203d2bb0ce96d1ff8af89` in an isolated
worktree. This release adds optional section-card disclosure indicators,
comfortable/compact/compact-landscape density, and persistent radial labels.
The existing catalog does not automatically opt in. Rounded overlapping sheets,
dither, palettes, tactile dial, callbacks, host ownership and default gestures
remain. No renderer or motion-budget changes are included.

## API and geometry

- `createSectionCard({disclosureIndicator:true})` shows the existing decorative
  chevron for linked panels. Default false retains the hidden linked marker.
  Outward-arrow cards remain unchanged. Updates are silent and validated.
- Cards accept `density:'comfortable'|'compact'|'compact-landscape'`.
  Comfortable is the existing default. Compact uses a 76px minimum header,
  22px title/radius, 10px caption, 4px text gap, and 12px by 16px padding.
  Compact-landscape applies only in landscape viewports at most 600px tall.
- `createSectionStack({element,density})` applies density to its own deck,
  including a 16px overlap and 22px radius when compact. `setDensity()` settles
  active motion before updating; disposal restores the original attribute.
- `createNavigationDial(host,{visibleLabels:true})` uses a 264×206px footprint
  with 12px labels. The 180px annulus, 76px dial and 44px destination targets remain
  unscaled. Defaults retain 180×193px. `update({visibleLabels})` is silent and
  preserves selection/preview. Full names remain in ARIA/title. Long labels
  are clipped to one polar line or two side lines; hosts should use short names.

## Verification

- Node 22.22.0: both builds/freshness checks, 307 package tests and 2 site/MCP tests
  pass. Version consistency now covers the package, glass/catalog metadata,
  site package/lock and displayed footer. Runtime parity includes the new
  navigation and section-card files in all three generated destinations.
- The focused browser contract passes 713 assertions in installed Chromium and matched WebKit
  at 800×480, 1280×800, 390×844 and 320×640. It covers the actual four Tonewedge
  destinations (Tone, Effects, Tuner, Settings), built-in six destinations,
  real 44px hit tests, nonoverlapping label/knob geometry, 12px type, default
  opt-out geometry, touch, mouse, keyboard preview/commit/cancel, repeated
  card activation, retained host state, density resize, transition interruption,
  reduced motion, light/dark modes, forced colors and disposal/remount.
- The existing swipeable-tab browser regression passes 234 assertions across
  both engines at 1440, 390 and 320px. No tab source or behavior was changed.
- Historical dev28 and dev30 byte fixtures remain unchanged. One new explicit
  dev31 fixture pins components.css and the three changed navigation/card
  source outputs. All other historical retained-byte protections still apply.

Raw focused-browser evidence and tested hashes are in `qa/dev31/results.json.gz`.
Screenshots stay local and were visually reviewed at 800×480 and 320px. The
standalone example is `playground/examples/compact-navigation.html`; it uses the
shared factories and is not a production audio editor.

## Reproduce and limits

Use Node 22 with a compatible `PLAYWRIGHT_PATH` and, when needed,
`BILDPUNKT_WEBKIT_EXECUTABLE`:

```sh
npm run build && npm run build:site
npm run check && npm run check:site
node tests/browser-compact-navigation.mjs
node tests/browser-tab-overflow.mjs
node tests/browser-section-navigation.mjs
```

Physical Pi touch, device performance, audio and Logic AU hosting were not tested.
Browser touch simulation does not replace hardware testing. Forced colors was
emulated only in Chromium. Arbitrary custom counts/translations need host QA.
This is a local release candidate, not a registry publication, push, deployment
or automatic promotion of any consumer.
