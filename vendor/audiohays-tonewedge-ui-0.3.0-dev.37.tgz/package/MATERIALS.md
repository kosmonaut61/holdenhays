# Surface materials

Materials describe **what an existing surface looks like**, independently of its component, layout or application state. Choose `cast`, `steel` or `glass`, then tune that kind's properties. A project card and a native button can share the same settings without sharing behavior.

## Explicit opt-in

Pin or vendor a reviewed Bildpunkt package build in each consumer. Load `tokens.css`, `components.css`, `glass.css`, `treatments.css` and `materials.css` (materials last). Existing controls keep their current presentation until the consumer explicitly attaches a material. This does not automatically migrate Tonewedge, Logic or another application.

```js
import { createMaterial } from '@audiohays/tonewedge-ui/materials';

const options = { kind: 'cast', grain: 45, relief: 50 };
const cardMaterial = createMaterial(projectCard, options);
const buttonMaterial = createMaterial(saveButton, options);
const detachCard = appearance.attachMaterial(cardMaterial);
const detachButton = appearance.attachMaterial(buttonMaterial);

// The host still owns content, event handlers and disabled/application state.
saveButton.disabled = true;
buttonMaterial.update({ kind: 'steel', brushing: 55, direction: 90, sheen: 40 });

// On unmount:
detachCard();
detachButton();
cardMaterial.destroy();
buttonMaterial.destroy();
```

Use a normal non-void surface container or a supported native button. For inputs or selects, decorate a surrounding container instead. Materials do not make a noninteractive element into a control, supply accessible names, arrange content or implement selection/save actions. Existing semantic action faces remain responsible for button colors and text contrast.

## Kinds and properties

All numeric properties range from 0 to 100 except `direction`, which ranges from 0 to 360 degrees.

- **Cast:** defaults `{grain:45, relief:50}`. `grain` controls the surface texture; `relief` controls the impression of depth.
- **Steel:** defaults `{brushing:55, direction:90, sheen:40}`. `brushing` controls directional texture; `direction` rotates that texture; `sheen` controls the highlight.
- **Glass:** defaults `{finish:"frosted", refraction:62, grain:48, mix:68, drift:36, panes:true}`. `finish` is `clear`, `frosted` or `opaque`; `refraction`, `grain`, `mix` and `drift` control the optical field. `panes` enables pane geometry. The decorator includes a semantic backing for readable content by default. Refraction and finish act within enabled panes at nonzero mix; an opaque finish has no source refraction. The catalog disables controls that cannot affect the current composition. Flow speed only changes opt-in playback.

```js
const glass = createMaterial(surface, {
  kind: 'glass', finish: 'frosted', refraction: 62,
  grain: 48, mix: 68, drift: 36, panes: true
});
glass.setPlaying(true); // opt-in motion; paused by default
glass.setPlaying(false);
glass.destroy();
```

The controller exposes `.state`, `.update(patch)`, `.playing`, `.setPlaying(boolean)` and `.destroy()`. Changing `kind` resets kind-specific properties to that kind's defaults and preserves common appearance palette/tint/mode state. `MATERIAL_KINDS`, `MATERIAL_DEFAULTS` and `normalizeMaterial` are exported for property editors. Bind each material to `appearance.attachMaterial(controller)` to follow your shared palette, tint and mode. Keep the returned detach function for cleanup.

## Semantic colors and units

The general surface uses `--tw-material-surface` and `--tw-material-ink`, falling back to `--tw-glass` / `--tw-glass-ink` (then `--tw-plate` / `--tw-ink`). If overriding either, supply a readable foreground/background pair. Existing `.tw-card` hosts keep their `--tw-plate` / `--tw-ink` pair, including legacy tokens-only hardware palettes. Cast and Steel highlight strength is bounded on content cards. On buttons, decorative children blend away from the computed text color: darker for light labels, lighter for dark labels. Hover follows that same direction. The semantic action face and label remain exact, and the material never reads canvas pixels. Appearance, class/style and pressed/selected changes refresh this protection. Shared buttons retain their semantic `--tw-button-face`, `--tw-button-label`, `--tw-button-edge` and `--tw-button-base` roles. Use `createAppearance` to set these together, or supply a readable action-token pair. Legacy raw hardware theme tokens alone do not guarantee primary-button contrast; a material does not recolor an action to repair an unpaired host palette. Material selection does not redefine palettes or assign an action's meaning.

The API takes whole-scale numeric values such as `grain:45`, not `0.45`. Values are clamped to 0–100, while steel direction is clamped to 0–360 degrees. The decorator converts these to its internal CSS variables. `palette:null`, `tint:null` and `mode:null` are the initial common defaults; null mode follows the nearest appearance root. Appearance attachment supplies shared optical palette/tint/resolved-mode state for Glass. Explicit `mode:"light"` or `mode:"dark"` can also be passed to a material; switching kind retains it. Cast and Steel keep those common values when changing kind, but their colors always come from inherited semantic CSS roles. To change a whole surface theme, update its appearance scope, not just its material palette. Motion is off initially and honors reduced-motion, reduced-transparency, forced-colors and disabled conditions. The native first-legend exception in disabled fieldsets is preserved. One shared document observer maintains appearance inheritance and decoration when a host is reparented or a control replaces its label. Destroy unregisters the material and removes the observer when the last material is gone.

## Catalog and compatibility

The **Materials** section starts with one shared Cast/Steel/Glass study, showing a general-purpose project card and a working Save button. Its property controls change both samples, and Import and usage reflects their selected values. The disabled preview is host-owned and leaves the material choice intact.

Advanced frost and refraction studies retain `createFrostedSurface`, `createGlassPlate` and `createGlassField`. Those APIs remain available for lower-level composition and are not replaced by the higher-level decorator. A gradient fade remains a separate effect, and content cards/lists remain separate layout components. Existing `glass` section IDs and frost/refraction story links remain compatible; `#/glass` opens the main material study.

No palette definitions, protected Spectral/Cobalt Glass/Mono colors, dither-tab styling or image-toggle glow behavior change as a consequence of attaching a material.

### Night glass

Named dark appearance uses the shared authored night pigment tables, retaining each palette's secondary colors rather than putting a hue filter over a gray canvas. The raw default/light material tables remain unchanged. Night frost mixes with smoked stock and retains luminous refracted edges. Its general content backing is uniformly 88% across the surface, with no default edge aperture. Pixel color and refraction remain visible without imposing a padding or content-placement contract on the host. A host may explicitly customize `--tw-material-backing-mask` or `--tw-material-backing-opacity`, but then owns text contrast across its full content area, including edge text. Existing `.tw-card` semantic foreground/background pairing and explicit host overrides still take precedence.

Reduced transparency makes the backing solid and hides the optical field. Forced colors removes all decorative depth. No material starts moving automatically, and motion still follows the existing reduced-motion, visibility and disabled rules.

Generic dark Cast/Steel surfaces bound highlight, grain and edge strength so primary and muted text remain readable even at maximum property settings and zero host padding. Existing shared card/action decoration strength remains separate. Dark material depth uses its outer/base shadow and actual finish, without an extra bright inset rim beneath edge text. Light material rendering is unchanged.
