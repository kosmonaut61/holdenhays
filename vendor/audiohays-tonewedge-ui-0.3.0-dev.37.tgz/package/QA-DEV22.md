# Bildpunkt 0.3.0-dev.22

## Dark materials

Dark mode now uses eight authored surface families rather than deriving every
surface from one nearly black seed. Paper, raised plates and smoked glass have
distinct depth. Spectral and Cobalt Glass keep saturated cobalt actions and acid
signals; the five other color themes retain their existing vivid action ramps.
Monochrome stays neutral.

Shared glass, frost, section cards and motion fields now receive the resolved
appearance mode. Dark glass uses its own multicolor pigments and refraction
stock. Tactile caps and sheets use restrained rims and dark shadows instead of
white-ink halos. Foreground backing protects content over the decorative field.

The change is scoped to dark appearance. The original light semantic palettes,
material tables, renderer defaults, component geometry and mini-app logic remain
intact. Explicit light roots reset dark material roles, and disabled controls and
closed sections retain neutral states.

## Verification

See `qa/dev22/README.md` and `qa/dev22/release-results.json` for the final browser,
contrast, accessibility-fallback and light-preservation evidence. All 251 package tests and 2 site tests pass. The final browser review records
14,405 checks with no new failures, including 496 exact light-mode comparisons.
A separate generic-material audit passes 2,340 rendered contrast checks.
Desktop/mobile catalog interactions also pass. Production-file verification is
recorded separately after publication.

One pre-existing limitation remains: WebKit renders some catalog/standalone
native selects at roughly 19–21px high. Their light-mode geometry is unchanged;
the example-app selects meet the 44px target.

## Scope and limits

The material mode field is additive. Existing raw Glass/Frost callers default to
light unless they supply a mode; the appearance controller supplies its resolved
mode to attached materials. No product data, routing, model bindings or audio
behavior changes. No npm publication or installation into other applications is
performed. Automated Chrome/WebKit checks are not physical-device or manual
screen-reader certification.
