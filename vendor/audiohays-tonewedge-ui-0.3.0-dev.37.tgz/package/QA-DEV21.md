# Bildpunkt 0.3.0-dev.21

## Example iconography

The working app gallery now uses Bildpunkt's bundled Pixelarticons for decorative
navigation and action icons instead of font glyph substitutes. The gallery brand
matches the established catalog mark. The new catalog Examples link also uses the
shared icon adapter.

The three apps retain their real shared controls, accessible action names and
arithmetic text. Calculator operators remain mathematical labels. The audit does
not replace native form controls or redesign component skins.

## Verification

Final evidence is recorded in `qa/dev21/README.md` and
`qa/dev21/release-results.json`. Verification checks icon path identity against
the bundled definitions, decorative accessibility, real app interactions,
responsive layout, light/dark rendering and unchanged library/palette sources.
Build/package checks and the existing catalog smoke are rerun before publication.

## Scope and limits

Only the example and catalog host presentation is changed, plus release metadata.
No shared control, palette or application-state API is changed. Headless browser
checks do not constitute a physical-device or manual screen-reader certification.
Publication and public verification are recorded separately from the local review.
