# Dev34: bounded Flow raster preparation

Local candidate only. No registry publication, website deployment, Pi install or browser refresh is claimed.

## Change

Flow previously recomputed identical row and column trigonometric warps for every pixel and created a short-lived result object per sample. The candidate prepares those warps once per frame, keeps original float64 operation order, and reuses a renderer-owned result. Flow no longer creates the unused two-coordinate-per-pixel array or star descriptors. Other scene renderers are unchanged.

At a 320×204 logical raster, fixed scene-coordinate arrays fall from 522,240 bytes to 12,576 bytes, a 509,664-byte reduction per Flow surface. Scratch is O(width + height), allocated once. No resolution, frame-rate, palette, motion, audio response, canvas lifecycle, native sound or persistence settings are changed.

## Evidence

- 875 scalar samples compared exactly with original dev33 `sampleField`; its public return-object ownership remains unchanged.
- Node exact RGBA regression covers multiple raster sizes, palette/mode/tint combinations, times, energy values and nonfinite input sanitization. Interleaved sampler tests prove independent ownership. Allocation instrumentation verifies six fixed Float64 buffers and no new typed arrays per frame.
- Isolated Chrome 156 and WebKit each passed 504 exact original/candidate image comparisons across all seven scene IDs.
- Alternating, warmed local 320×204 Flow benchmark, eight runs of 80 frames each: Chrome median 455.7 → 361.4 ms (20.7% reduction); WebKit 332 → 254 ms (23.5%). These are local fixture timings, not Raspberry Pi measurements. A preceding version showed different absolute timing; only the final variant's paired runs are reported here.
- `npm run build`, `npm run build:site`, and all 313 library tests pass. The two site MCP tests also pass using the already installed dependencies whose lock matches this checkout. Full consumer integration is recorded separately when complete.

The original scalar implementation is retained under `tests/fixtures/flow-baseline/` solely as a test oracle. Existing dev28 scene hashes remain unchanged. Historical source-byte protection is extended with an exact two-file dev34 revision, without weakening protection for unrelated files.

## Limits

This is a measured CPU and fixed-buffer reduction, not proof that Flow caused or cures Tonewedge's Pi freeze. The real device currently runs older loaded code and has shown private renderer allocation growth. Long-lived Pi memory, audio continuity and physical display acceptance need coordinated testing after activation. No global memory-lock, swap, GPU, accessibility, browser-security or audio settings are changed.

Exact final browser evidence, versions and candidate module hashes are in `qa/dev34/flow/results.json`; reproduce with `tests/browser-flow-raster.mjs` and the documented Playwright/Chrome/WebKit environment selectors.
