# Bildpunkt typography · dev.6

Two intended font families, with one canonical definition in `tokens/glass.json`:

- Display: **Redaction 50**. Wordmark, expressive headings and tactile actions keep the existing font asset and sizes.
- UI: the existing **Arial** sans. Helvetica and generic sans-serif are platform fallbacks, not separately loaded design families. Body copy, metadata, utility labels, readouts, pedal print codes and code examples use this role.

The display stack now falls back to that same sans stack if Redaction is unavailable. There is no Courier, UI monospace or Georgia display fallback. Only the existing Redaction font is bundled; no new font is downloaded or embedded.

## Shared contract

`glassTokens.typography.display` and `.ui`, exported in `glass-tokens.mjs` and `glass-tokens.json`, generate `--tw-glass-font-display` and `--tw-glass-font-ui` in `tokens.css`. Shared component, glass, treatment and catalog styles consume these roles rather than selecting their own sans font.

For compatibility, generated `glassTokens.typography.mono` equals `.ui`. The existing `--tw-glass-font-mono` name is retained as `var(--tw-glass-font-ui)`, so an intentional UI-role override also reaches older utility consumers. It does not select a monospace font.

Within owned `.tw-scope`, dialog, card, asset-card and glass-panel content, `pre`, `code`, `kbd` and `samp` explicitly use the sans role. `.tw-code` is available for an independently placed code sample. Existing whitespace and wrapping behavior remain unchanged. Numeric readouts and metadata use `font-variant-numeric: tabular-nums` where alignment is useful; this is a font feature, not another family.

Native C++ `tokens.hpp` continues to export colors, spacing and touch sizes only. It contains no typography selection and is unchanged. Host applications must explicitly upgrade the pinned package or generated CSS/tokens. This revision does not change Tonewedge/Pi, their font setup, control semantics, palette, assets or geometry automatically.

## Verification

The live dev.5 catalog was inspected before changes: 35 rendered metadata/label nodes selected Courier New and an open nested usage-code sample selected browser-default monospace. Local dev.6 coverage opens every component and usage example, checks real visible text and native controls, pedal print and explicit `pre/code/kbd/samp` probes, then verifies the same two stacks in the catalog and embedded standalone on Chromium and WebKit at desktop, mobile and 800×480.
