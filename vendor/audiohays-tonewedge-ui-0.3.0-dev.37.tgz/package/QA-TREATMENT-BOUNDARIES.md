# Treatment boundaries and host layout

## Source-verified changes

Glass host and treatment decoration positioning defaults now use zero-specificity `:where(...)`. Consumer classes specifying fixed, absolute, or sticky positioning can override these defaults even when loaded before the library. Reusable material hosts already used this pattern and remain unchanged.

`node --test tests/material-host-layout.test.mjs` passes two source-contract tests. These tests inspect CSS declarations; they do not prove browser rendering.

## Remaining nested treatment issue

`tests/fixtures/treatment-boundaries.html` is a diagnostic fixture using source stylesheets and existing generated palette tokens. Serve the repository root and open the fixture in supported browsers when browser QA is available.

The current Minimal descendant rule in `src/treatments.css` matches a Hardware card inside a Minimal parent and sets `background-color:transparent`. The Hardware rules restore borders/radius/shadow but do not restore the background. Thus the nested Hardware card receives a different background from its standalone counterpart. The same broad ancestor-selector pattern appears in `src/glass.css` and affects other treatment properties.

The fixture compares standalone and nested Hardware cards, and includes Minimal > Hardware > Minimal to catch over-broad nested-root exclusions. It also reports computed positioning for glass/material/treatment hosts. Browser results have not been collected during this change because the authorized browser runtime was unavailable.

## Proposed follow-up

Use inherited treatment custom-property roles, resetting every treatment-specific role at each explicit treatment root and consuming those values in component declarations. This supports arbitrary nesting without requiring newer `@scope` support. Include baseline geometry, backgrounds, typography, canvas opacity, hover behavior, and explicitly opted-in material hosts in the matrix. Preserve legacy glass behavior at its own root boundaries. Validate supported Pi Chromium and Logic WebKit before migrating all treatment selectors.

Simple ancestor exclusions are insufficient: they can exclude the innermost Minimal scope in Minimal > Hardware > Minimal. `@scope` would express the boundary naturally, but should not become the only implementation until supported browser versions are verified.
