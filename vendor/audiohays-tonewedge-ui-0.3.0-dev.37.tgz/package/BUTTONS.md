# Approved Glass Pixel buttons · dev.5

Primary reference: https://bildpunkt-glass-pixel.k05m0naut.chatgpt.site. Both live Spectral/Cobalt modes were inspected and their computed CSS was checked against the transferred source kit's tokens.css, tokens.json and controls.css. Signal Atlas and live dev.4 were also inspected for the before/after comparison.

## Exact source color roles

- Primary: #293dc2, edge #1c2b91, label #faf8f0.
- Signal: #d7fa48, edge #9ebc32, label #232322.
- Neutral: #eeeddf, edge #aaa99c, label #232322.
- Mechanical base: #484a4b. The optional dark variant uses this source base color with the same light label.
- Original sheen: linear-gradient(135deg,#ffffff24,transparent 52%).

The approved prototype keeps these button roles identical in its Spectral and Cobalt modes. It changes its dither field, glass and knob colors. Bildpunkt's existing exact eight-color spectral/cobalt raster ramps are unchanged. Its button roles now use the approved source values rather than dev.4's invented yellow cast face.

The roles are exported in glass-tokens.json / glass-tokens.mjs under button and as --tw-button-* custom properties in tokens.css. Each shared button uses --tw-button-face, --tw-button-edge and --tw-button-label internally. Monochrome neutralizes the roles; explicit tint and other selected application palettes map actual semantic colors without a color filter. Industrial, legacy Cobalt, Ember, Pine and Plum now separate saturated action fill from readable accent text. Their primary maps `accentFill` / `accentEdge` / `onAccentFill`; their signal maps `accentLight` / `accentEdge` / `onSignal`. See APPEARANCE.md for the optional roles and tint fallback. Treatment never changes the palette or tint selection.

## Shared material and behavior

- tw-button, tw-tab, compatibility tw-glass-button and the previous/next rocker share the source-grounded material. The cast/steel skin selects sparse edge texture, not a different invented color palette.
- Rounded 8px corners, a single shallow edge and a clean center retain the requested geometry cleanup. Fixed-size one-pixel corner texture is separate from color. There is no stacked offset backplate or inset bevel.
- Redaction 50 remains 16px on shared actions, with semantic padding and a 44px minimum target. The wordmark remains Redaction 50.
- Blue primary actions keep tw-button--accent / tw-glass-button--primary. The additive opt-in tw-button--signal / tw-glass-button--signal supplies the approved lime role. Color does not automatically assign application state.
- The catalog's Hold signal example uses the actual shared native toggle factory. Its aria-pressed state toggles on click; no product or audio action is attached. Applications can instead retain controlled state and their own callback.
- Hover uses the source 6% lift; active/pressed controls move down 1px. Disabled controls use the source 0.43 opacity. Dark/light keyboard focus and system forced-color rendering remain intact.
- data-tw-cap="previous" retains its explicit historical rendering, with unclipped focus and readable semantic labels.

Original PNG assets and the retained dev.4 colored SVG caps remain bundled unchanged; the new default uses button-edge-cast.svg / button-edge-steel.svg plus semantic color variables. Applications must explicitly upgrade the complete generated package. No existing JavaScript factory signature, native event contract, audio mapping or host state API changes.

## Custom-tint action contrast

Explicit custom tints retain their existing semantic face/label pair. The cap's
label-area sheen and hover shade move away from the label color: darker behind
light ink and lighter behind dark ink. Cast and Steel keep the original corner
artwork, border, geometry, 44px target, focus ring and pressed displacement.
Named palettes retain their original sheen and hover rendering, including named
scopes nested inside a tinted parent. Disabled caps retain their monochrome skin.

This is shared CSS behavior for `.tw-button` and `.tw-glass-button`, including
primary, signal, dark, pressed and selected carousel roles. It does not require
`createMaterial` or a button factory. Quiet actions remain transparent/recess
surfaces. A custom-tint scope can be an ancestor or the action itself; it can use
an explicit mode or inherit a mode root. For CSS-only use, supply the existing
`--tw-appearance-*` values from `appearanceColors` for that resolved mode and
update them when the tint or mode changes. The hex attribute alone does not
compute a palette. No new JavaScript state, observer or API is introduced.
