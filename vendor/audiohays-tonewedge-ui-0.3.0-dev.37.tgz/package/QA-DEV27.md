# Bildpunkt 0.3.0-dev.27

## Cooler neutral Spectral Cream

Spectral Cream's dark stock now uses low-saturation, slightly cool charcoal and
grey instead of the rejected green-brown cream stock. Cream ink, bright blue
and lime actions, and all five multicolor pigments remain unchanged. Original
teal Spectral is retained as a separate option. Spectral Cream's ID, display
name, light appearance, explicit custom tints and selection behavior stay intact.

The optical background now matches the semantic glass sheet (#3e4042), avoiding
a separate dark rectangle beneath faded dither corners. Case is #191a1b, plate
#2c2e30 and glass highlight #787b7e. No application or consumer is migrated by
this library change; no audio, product state, defaults or persistence changes.

## Verification

- Chrome/WebKit UI: 34 suites and 216 appearance combinations passed, with
  all 30 shared stories per surface, three gallery apps and 320/393/1440px
  widths checked. No unexpected browser errors.
- Package check: 294 tests passed. Site build/check and both MCP tests passed.
- Frozen dev26 checks preserve 340 semantic/raster cases and 119 visualizer
  scenes, in addition to the existing pre-Cream compatibility tests.
- Chrome and WebKit painted controls: 2,593 checks, 1,680 text samples, no
  failures or browser errors. Minimum painted text contrast: 4.687:1.
- Exact-dev26 material comparison: no regressions. All 432 new Cream-dark
  samples pass, including zero padding, maximum intensity and steel brush
  directions; minimum 4.865:1. The 32 below-threshold light-mode observations
  match the baseline exactly and remain documented limitations, not passes.

Full browser navigation/appearance results and reproduction instructions are in
qa/dev27/README.md. This is focused desktop-browser component QA, not physical
Pi, Logic AU, touch-device or site-wide accessibility certification.
