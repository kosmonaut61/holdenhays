# Bildpunkt 0.3.0-dev.13

## Requested refinements
- Raised the selected tab's dither toward its label, with a protective fade behind the text. Added a muted continuous baseline to horizontal tab lists, including the explorer pickers. Vertical tabs, numbered carousel controls and alternate gallery directions keep their own treatments.
- Replaced the radial menu's rectangular selected plate with a palette-colored annular dither wedge. Icons have a quiet backing, committed selection retains an outer arc, and keyboard focus follows the wedge shape.
- Added the shared cast-button texture and light to switch thumbs, plus restrained track grain. Off remains usable; disabled states remain neutral and noninteractive.
- Added opt-in shared card headers to native dialogs. Both catalog examples compose the existing frost and paper fade on one continuous sheet. Semantic headings, input values, native focus containment, Escape, form submission and focus return are preserved.

## Verification
- 160 package/unit/build checks and 2 independent site/MCP checks pass on the final build.
- The final scoped matrix passes 12 browser/artifact/viewport contexts, 2,304 appearance states and 53,606 assertions with no failures. It covers both engines, catalog and standalone, all eight palettes, three treatments and two modes at 1440/390/320px.
- Supplemental disabled-tab and tinted-dialog checks pass 139 assertions. Lowest disabled text contrast is 5.557:1. Main-matrix minima are 5.512:1 tab text, 8.494:1 text over the protective tab fade, 9.707:1 radial icons, 3.151:1 thumb/track including cast shading, 4.883:1 focus, and 8.167:1 dialog title over its actual textured backing. Tested targets are at least 44 × 44px.
- Three retained stack-motion cases pass at 1440, 390 and 320px: physical overlap, easing, interrupted reversals, rapid selection, filtered layout, reduced motion and no overflow/errors.
- Desktop/mobile smoke passes locally, covering the new refinements and retained numbered-carousel behavior. The same script is used against the public deployment.
- Full final-build Chromium/WebKit matrix results are recorded in `qa/dev13/chromium/` and `qa/dev13/webkit/`. A compact summary accompanies gzip-compressed detail. Exact source/build hashes are checked before and after each run.
- The review board uses actual shared components, not a separate visual mockup. Native modal behavior is tested separately on the real catalog.

## Scope and limitations
This updates the existing Bildpunkt site and private package artifact. It does not publish an npm release or upgrade Tonewedge/Pi consumers. Physical Pi hardware, physical touchscreens and Logic AU integration are outside this change. Forced-colors emulation was exercised only in Chromium in this pass. Arbitrary radial item counts are API/geometry checks, not a promise that labels or hit targets will remain separated above the standard six destinations.

The newly requested arbitrary-image toggle is being prepared separately and is not included in this release.
