# Bildpunkt 0.3.0-dev.23

## Image-toggle dither

Pressed image toggles use the same clustered 2px texture and color progression as
the shared tabs. Two offset texture layers follow the original image silhouette,
including curves and transparent cutouts. The compact 5px falloff replaces the
broad uniform dot field. The focus ring remains a separate accessible indicator.

Light-mode lift shadows are unchanged. Dark-mode lift uses a neutral dark shadow
rather than pale ink. Explicit nested light scopes reset that choice. Off,
pressed, disabled, controlled and legacy pedal/footswitch behavior is unchanged.
There are no new image assets or API changes.

## Spectral dark stock

Only Spectral's four authored dark surface tokens change: case, plate, glass and
glassLight now form a smoky teal-neutral family rather than navy. Bright blue
actions, acid signals, cream ink and multicolor pigments remain unchanged. All
light semantic palettes and the other seven dark semantic palettes stay exact.
See `QA-SPECTRAL-NIGHT-SURFACE.md` for the token values and contrast review.

## Verification

All 254 package tests and 2 site tests pass. Final focused browser verification,
source preservation and contrast evidence is recorded in `qa/dev23/README.md`
and `qa/dev23/release-results.json`. The existing catalog interaction suite passed at desktop and mobile widths.
The generic-material edge audit passed 2,340 checks with a 4.644:1 minimum
text contrast. The focused review passed 1,400 checks with zero failures,
including 208 rendered Spectral material samples (minimum 4.837:1).

The unchanged WebKit catalog/standalone native-select height limitation recorded
in dev.22 remains. This release changes neither control geometry nor application
state. Automated browser checks are not physical-device or manual screen-reader
certification. No npm publication or installation into other applications is
performed by this release.
