# Bildpunkt 0.3.0-dev.2 validation

Local frost/fade extraction. No deployment, push, device installation or host audio change.

- 53 package/native tests passed, including 16 new surface/effect tests and offline packed-consumer imports.
- 2 read-only site/MCP tests passed.
- 6 focused Chromium/WebKit flows passed at 1440×1000, 390×844 and 800×480. They exercise independent frost/fade toggles, title stop measurement, live native buttons, global appearance, forced colors, teardown, no overflow and no external requests.
- Both engines render exactly the same frost raster bytes and screenshot pixels as the approved host's grain-72, 3px lattice and #e7e5d7f7 → transparent title gradient. The host keeps its own measured stop positions and screen highlights.
- Standalone HTML worked offline in both engines. Catalog regression results are recorded alongside the focused results under qa/dev2.

Run `npm run check`, `npm test --prefix site`, `node tests/browser-surfaces.mjs` and `node tests/browser-catalog.mjs` with the same optional Playwright environment variables documented in QA-DEV1.md. Tests contain no machine-specific paths. Source docs are FROSTED-SURFACE.md and GRADIENT-FADE.md.

This release does not certify complete host-control adoption. Broader native/composite extraction is separate work. Actual Pi Chromium, Logic AU WebKit, physical inputs and audio integration still require host/device verification.
