# Bildpunkt 0.3.0-dev.12

## Requested changes
- Promoted the selected Pixel underline tab direction into the shared default. The selected line has a palette-colored field of pixels rising above it, with clear labels and a short eased selection transition.
- Promoted Numbered steps into the shared carousel default. Steps compose the real cast button primitive, including its existing edge texture, palette roles, pressed behavior and target size.
- Applied the defaults to explorer tabs, component examples and the catalog carousel. The comparison gallery retains the other directions and identifies the selected defaults.
- Unified each expanded card's paper surface with the background behind its header, preserving the existing theme and dither.

## Verification
- 146 package/unit/build checks and 2 independent site/MCP checks pass on the final build.
- Exhaustive navigation matrix: Chromium and WebKit, 1440/390/320 widths, catalog and zero-request standalone, all 8 palettes, 3 treatments and 2 modes. All 1,152 appearance states, 37,362 assertions and 8,064 control-text contrast measurements passed.
- Lowest measured navigation text contrast: 5.512:1; disabled text: 5.557:1; selected underline: 6.870:1; tested focus rings: 5.825:1. Minimum targets are 44 × 44px.
- Final unified-card rerun: all 17 cards across both engines, three widths, Spectral/Glass and Industrial/Minimal, light/dark. All 408 states and 24 initial screenshot pixel checks passed. Header/body text, alignment, colored dither and overflow checks passed.
- Six retained-catalog regression cases pass: all 29 examples, search, history, state retention, keyboard, dialogs, forced colors, reduced motion and standalone.
- Three final stack-motion cases pass: physical overlap, eased motion, interrupted reversals, closed-card cleanup and reduced motion.
- Final navigation regression after the surface refinement passes all 12 catalog/standalone browser contexts, 288 states, 10,849 assertions and 2,016 additional text-contrast readings. Source/build hashes stayed unchanged throughout.
- Final desktop/mobile smoke passes locally. Post-publication verification is recorded separately.
- Detailed evidence and final navigation regression are in `qa/dev12/`. The exhaustive navigation matrix preceded the final transparent-panel refinement; affected surfaces and navigation flows were rerun afterward. Forced-colors emulation is covered by Chromium; WebKit does not support that test emulation.

## Shared surface implementation
The parent glass sheet paints the background once. Its content panel is transparent, with matching glass text roles. This avoids a second fill and WebKit's stale computed-style snapshot of inherited panel colors. No lifecycle delay, forced repaint or palette change was added.

## Scope
This updates the existing Bildpunkt site and private package artifact. It does not publish an npm release or upgrade Tonewedge/Pi consumers. Real Pi hardware and Logic AU integration are outside this change.
