# Bildpunkt asset terms checkpoint — 2026-11-06

Official Sprite Fusion terms: https://www.spritefusion.com/terms (reviewed 2026-11-06). The API Access section permits including generated Outputs in a distributed personal or commercial project. The Outputs section says Sprite Fusion does not claim ownership of user Outputs, while placing responsibility for third-party input rights on the user. The terms do not make Bildpunkt open source or convey rights to unrelated input artwork. No purchase/download license or separate source grant is recorded in the original provenance JSONs. No Sprite Fusion API, key, credential, or generation service is included.

The source provenance explicitly identifies these shipped PNG outputs as SpriteFusion-derived:

- Cast/steel caps: `cast-{rest,on,selected,disabled}.png`, `steel-{rest,on,selected,disabled}.png`, plus `fader-{cast,steel}.png`, derived from `spritefusion/plate/option-00.png` and `option-03.png` (see `button-provenance.json`; the fader CSS documents thumb reuse).
- Detailed knobs: `knob-detail-{a,b,c,d,e,f,guide}.png` and `knob-detail-14-{brushed,dither,radial,ribbed,guide}.png` (see `detailed-provenance.json`, `frontal-provenance.json`, `solid-provenance.json`, `solid-14-provenance.json`).
- Earlier angled knobs: `knob-05-clean.png`, `knob-05-short.png`, `knob-05-flatter.png`, `knob-straight-01.png` (see `provenance.json`, `foreshortening-provenance.json`, `flatter-provenance.json`, `straight-provenance.json`). `knob-05-original.png` is retained from the same Workshop material folder, but the copied provenance does not independently identify that filename.

`sf-plate-nw.png`, `sf-plate-se.png`, `pedal.png`, and `amp.png` are present in the existing Audio Hays Workshop material directory, but the copied records do not establish their exact generation/input lineage. They are used in the site's surface/navigation/footswitch display. Source PDF/SVG artwork and the Redaction font have separate provenance; Redaction carries its bundled SIL OFL 1.1 notice.

The current release is a private, version-pinned project package plus a built public site preview. It is not a generic asset marketplace, an open-source font/art grant, or an API proxy. Confirm source ownership or third-party input rights before broad public redistribution of the standalone PNG library. Display as part of the built project is directly addressed by Sprite Fusion's published Output terms, subject to that input-rights condition.
