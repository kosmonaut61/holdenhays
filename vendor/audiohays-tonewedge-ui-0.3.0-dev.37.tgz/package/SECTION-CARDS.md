# Bildpunkt section navigation

`createSectionCard` composes the shared native `createButton`, the real Bayer-dither `createFrostedSurface`, and an independent `createGradientFade`. It is navigation presentation, not a section router, accordion, or detail-panel owner. A card uses no artwork stand-ins, blur, hard framing or additional font family. Soft contact shadows and a one-pixel inset light edge give the shared sheets depth without an extruded button cap.

This belongs under **Navigation**. For a content/status container, use `.tw-card` or `createAssetCard` under **Cards**. The shared frosted layer is documented separately under **Glass**; the word “card” does not make these APIs interchangeable.

Load `tokens.css`, `components.css`, `controls.css`, `glass.css`, `treatments.css`, `effects.css`, then `section-cards.css`. The last stylesheet deliberately replaces the shared button's physical cap with its rounded frosted surface. All colors inherit existing semantic palette/tint roles. The label uses Redaction 50; captions and descriptions use the existing Arial UI role. Cards remain rounded in every treatment; the minimal treatment still quiets the shared raster.

## Controlled host integration

```js
import {createSectionCard} from '@audiohays/tonewedge-ui/section-cards';

const card = createSectionCard({
  id: 'materials-card',
  label: 'Materials',
  caption: 'Glass, frost and fade',
  description: 'Show reusable material controls and examples.',
  controls: 'section-details',
  selected: true,
  onSelect(event) {
    // Host routing and rendering are deliberately outside this primitive.
    selectSection('materials');
  },
});
card.element.dataset.story = 'materials';
sectionNavigation.append(card.element);
const detach = appearance.attachMaterial(card.material);

// On any host route change, synchronize all cards without firing onSelect.
card.setSelected(activeSection === 'materials');
// The host updates the associated panel's content, visibility and aria-labelledby.
details.setAttribute('aria-labelledby', activeCard.element.id);

// On teardown, detach before removing the component.
detach();
card.destroy();
```

`data-story` and other host-owned data attributes remain untouched by updates. The card is a real `type="button"` with the normal native Enter/Space, focus, disabled and form behavior. This is not a tablist: use an ordinary labeled `nav` or section container and keep each card in native tab order. Keep one selected card when showing one detail section. The selected button exposes `aria-current="page"`; when `controls` is provided, its `aria-expanded` reflects selection and its `aria-controls` identifies the host panel. Selection is controlled: repeated activation requests the same section and does not toggle or dismiss details automatically.

## Options and controller

`createSectionCard(options = {})` accepts:

- `label`: nonempty accessible/display label, default `Section`. Text is inserted safely, never parsed as HTML.
- `caption`: optional visible sans-serif metadata above the label.
- `description`: optional visually hidden assistive description, linked through `aria-describedby`. Keep longer section content in the host's detail panel.
- `selected`: boolean, default `false`.
- `controls`: one host detail-panel element ID, or `null` to remove the relationship. The host creates that panel.
- `disclosureIndicator`: boolean, default `false`. With `controls`, opt in to a visible decorative chevron that rotates with `expanded` (or `selected`). Does not toggle the panel, change callback behavior or add a focus target. Outward-arrow cards without `controls` retain their arrow regardless of this option.
- `density`: `comfortable` (default), `compact`, or `compact-landscape`. See the explicit density contract below.
- `disabled`: boolean, default `false`. Native disabled fieldsets are also respected.
- `onSelect(event)`: called once for an uncancelled native activation, with `this` set to the button. Construction, `update` and `setSelected` never call it. Disabled, inert and cancelled activations are ignored. No custom keyboard handlers duplicate native clicks.
- `state`: optional glass-state patch. Requested material palette defaults to `cobalt`; unselected/closed and disabled cards display a `monochrome` optical field with no tint, while their surface, fade, label and caption retain the host theme. Selection restores the latest requested palette/tint without changing host state. The factory never changes host-owned `data-tw-theme`. Grain is 72, panes are off, and the pixel lattice is 3 CSS pixels. Attach `material` to the host appearance controller for palette/tint updates. No appearance settings are stored in the host's product state.
- `time`: deterministic source-field time, default 7. Cards never start animation or schedule an animation loop.
- `id`: optional button ID; otherwise generated. Supply IDs when stable host routing or panel labeling needs them. `id` and `controls` reject empty/whitespace-containing IDs.
- `document`: optional DOM Document for frames/tests. No global Document is needed when it is supplied.

The result exposes `element`, `material`, `fade`, `update(patch)`, `setSelected(boolean)` and idempotent `destroy()`. Both update methods return the controller. `update` accepts the options above except replacing the Document. A card always creates its own button; it does not adopt arbitrary markup or destroy an existing native controller. `destroy` removes its button and releases the material's observers/listeners and the native button's listeners. Later updates are inert.

The exposed `material` preserves the frosted-surface API through a selection-aware adapter. Its `state` reports the actual displayed material. `material.update` remembers the host’s latest requested color while closed or disabled, restoring it on selection. The exposed `fade` is the separate effect instance; changing it never alters raster state. Its default inherited paper color stays opaque through 58% of the card and fades to transparent at 100%. For a deliberately different layout, `card.fade.update({start:'50%', end:'95%'})` uses the normal independent fade contract. Attach only `material`, never `fade`, to appearance. Keep source playback paused for section navigation.

## Layout and accessibility

The primitive fills its host's allocated width and has a 112px minimum height (104px on small viewports), rounded 24px corners, wrapping labels, and no fixed maximum height. The host owns card grids, overlap, ordering and selected-detail placement. Do not clip the external keyboard focus outline in the host layout. Avoid placing other interactive elements inside the button.

A linked card keeps its indicator hidden by default. With `disclosureIndicator:true`, it has a drawn chevron in a subtle glass well, rotating 180 degrees with `expanded` (or `selected` when no separate expanded state is supplied). It never depends on a font plus/minus glyph. Cards without `controls` show an outward arrow. With the visible indicator enabled, expanded state has both chevron direction and ARIA state; it is not conveyed solely by color. Labels stay above both decorative layers. Forced-colors mode hides the canvas/fade through their shared styles and uses system colors, a thin system boundary and the existing visible focus outline. Reduced-transparency uses the opaque semantic surface. Reduced-motion removes hover and chevron transitions. The material itself remains static with no playback loop. Respect the normal `[hidden]` attribute on cards and captions.

`expanded` optionally separates linked-panel visibility from current selection. When omitted/null it follows `selected`. For an all-details view, update every card with `{selected:false, expanded:true}`; `aria-current` remains absent while `aria-expanded` describes the visible panels.

## Expandable catalog composition

The dev.10 catalog has a permanent top Theme section and seventeen focused, overlapping component sections. Each following sheet covers the preceding sheet's 28–30px foot. Text and the chevron remain exposed. One panel opens at a time; repeated activation, Escape and the shared Close button close it. Back/Forward restore the selected story. Multi-example sections use the shared `createTabs` controller with roving Arrow/Home/End keyboard focus. Single-example sections omit redundant tabs. All original component instances remain mounted so settings survive close/reopen.

Every sheet receives the top Theme palette, treatment, optional tint and color overrides. Closed-sheet dither alone is monochrome. The open sheet keeps its colored optical field and a subtle edge. Local appearance roots isolate the themed sheets from the neutral page shell. Search filters cards and tab choices, preserving the active example when it still matches. The lazy Icons example adds the free Pixelarticons browser without loading icon names or art until it opens.

Settings and import code use native `details` with shared quiet disclosure styling. There is no separate appearance modal, hidden legacy sidebar or Show all mode. Generated group IDs use `catalog-section-` so they cannot collide with retained example IDs and deep links.


## Shared stack motion

`createSectionStack({element})` adds an interruptible layout controller, exported from the same `section-cards` module. Put `tw-section-stack` on the host, `data-stack-card` on its direct child sheets, and `data-stack-panel` on each controlled detail panel. Each sheet owns a heading with its `createSectionCard` button followed by the panel. The host still owns routing, selection, search, panel visibility and focus. This helper never creates controls or changes application data.

A direct child `data-stack-panel` is transparent so its parent sheet paints one continuous glass background behind the header and details in every palette and light/dark mode. Its body and muted text use the matching glass ink roles. Keep the panel transparent rather than painting a duplicate surface or a separate case color; the header's dither and label fade remain unchanged. When checking the panel's effective color, include its opaque parent sheet.

Call `stack.transition(() => { /* synchronous host state/DOM update */ })` to capture the currently displayed heights, apply the update, measure final natural heights, and animate actual sheet heights for 560ms with `cubic-bezier(.22,1,.36,1)`. Following sheets stay physically attached with the same overlap throughout the movement. Newly shown panel content rises 12px and fades in over 420ms. Hidden panels leave keyboard and accessibility navigation immediately. Example contents stay mounted and preserve their state.

Repeated activation cancels the old movement only after measuring its current presentation, then continues from that height. Completion restores intrinsic layout. Resize and live changes to reduced-motion cancel animations and reveal the correct final state immediately. `{motion:false}` applies layout synchronously, including correcting the first visible sheet after filtering. No timers or perpetual animation loops run.

`stack.reveal(sheet)` gently brings a selected header toward the viewport top using its measured final position; reduced motion uses an instant scroll. `stack.destroy()` cancels owned animations and removes resize/media listeners without deleting host DOM. Call it before removing the deck. Standalone exports include the same controller, not a site-only substitute.

Keep adequate bottom padding in each panel to protect controls from the overlap, and leave the host overflow visible. A sheet clips its content only during its size transition; settled menus, focus indicators and controls retain normal layout. Shared focus outlines are inset so the next sheet cannot cover them. The pixel field and label fade remain separate shared material primitives.

## Shared scene motion

Motion is opt-in for library consumers. Pass `motion`, `scene` and `motionPalette` to `createSectionCard` or `update`. The host can derive the seven-role palette with `visualizerPaletteForMaterial(materialStateForAppearance(appearance.state), {mode:appearance.resolvedMode})`. The same scene renders in the existing frost canvas at 18% speed and zero energy, behind the shared text-protecting fade.

Only selected, expanded, enabled cards animate. Closed cards restore their original monochrome frost and have no scheduled frames. Native disabled controls and disabled fieldsets (respecting the first legend exception), ARIA-disabled cards, and inert ancestors also neutralize the optical field and stop playback. One shared document observer follows those availability changes and reparenting, and disconnects when its last card is destroyed. Visibility, reduced motion, page lifecycle and destruction pause or dispose the renderer. Provide a visible pause control for continuous motion. Disclosure cards retain native button and `aria-expanded` semantics, with a chevron only when `disclosureIndicator:true`. Outward-link cards retain their navigation marker.


## Explicit compact density

`density:'compact'` reduces a card's minimum header height to 76px, label to
22px, caption to 10px, gap to 4px, padding to 12px by 16px, and standalone
radius to 22px. Labels still wrap and may increase height. No control target is
shrunk below 44px. The existing dither, typography families, semantic materials,
fade, focus treatment and motion remain. Default `comfortable` geometry stays
112px (104px at widths up to 480px).

`density:'compact-landscape'` applies the same treatment only when the viewport
is landscape and at most 600px tall. It is an explicit opt-in, never a global
small-screen rule. CSS reevaluates it on resize/orientation changes. Use
`compact` when a constrained region needs it regardless of viewport.

For an overlapping deck, use `createSectionStack({element, density})`. It sets
`data-section-density` on that host and gives contained cards the matching
geometry, a 16px overlap and 22px sheet radius. The 76px header leaves a 60px
exposed strip, keeping its caption, title and chevron above the next sheet. The
host still supplies panel padding and scrolling. The stack does not remove
headings, hide application chrome or resize editor content.

`stack.setDensity(value)` validates and applies a new density without callbacks,
settling any active stack transition. `destroy()` restores the host's original
density attribute. An omitted stack density leaves the host attribute untouched.
A stack density applies to its contained section cards; use a separate deck for
mixed-density groups. Standalone cards use `card.update({density})`.

```js
const stack = createSectionStack({element: deck, density: 'compact-landscape'});
const card = createSectionCard({
  label: 'Tuner', controls: 'tuner-panel', selected: true,
  disclosureIndicator: true, density: 'compact-landscape',
  onSelect: () => toggleHostPanel(),
});
// The host owns panel visibility and mirrors it back after navigation.
card.update({selected: true, expanded: true});
```

The [compact navigation example](playground/examples/compact-navigation.html)
exercises all options without changing the existing catalog's defaults.

## Shared card states (dev.32)

- Inactive is still an enabled native button. Its paper, fade, label and caption keep the chosen theme; only its dither is monochrome.
- Active follows `expanded ?? selected` and availability. Its dither uses the requested palette/tint and a one-pixel inset edge follows the paired glass ink. `--tw-section-active-edge` is an optional host override. The edge never shifts layout or replaces the keyboard focus outline.
- Disabled remains natively unavailable, with no callbacks. It keeps the same theme surface and monochrome dither, without an active edge or moving field. ARIA-disabled cards retain native focusability; hosts still own that choice.
- Dark mode, custom tint, reduced transparency and forced colors follow existing semantic roles. All authored palette tables, typography and material pixels are unchanged. Reduced motion remains static.

Consumers upgrading the complete package get the shared behavior automatically. Hosts that previously assigned a separate monochrome appearance to closed sheet wrappers should remove that override and pass their current appearance to every wrapper. Do not implement selection by changing the host palette.

## Expanded sheet outline · dev33

Inside a shared section stack, an open sheet paints its active one-pixel edge
around the entire header and detail body. Its header no longer draws a second
edge across the seam. Direct headers and headers inside a heading wrapper are
supported; detail content belongs in the direct `data-stack-panel` child.
Standalone and nested example cards retain their own active edge. The overlay
does not affect layout or pointer input, and keyboard focus remains on the
header. Closed or unavailable sheets have no active outline.
