# Rotary lifecycle contract

This additive, host-neutral API is implemented by `src/rotary.mjs` and passed
through unchanged by `createRange({kind:'rotary'})` and `createKnob`. It is a
feature introduced in 0.3.0-dev.25. It does not select an audio model, send values to
a device, own an editing flag, save presets, flush a host queue, or change artwork.

## Options and unchanged defaults

```js
const dispose = bindRotary(input, hostReset, {
  onGesture: handleGesture,      // optional function; absent means no observation
  wheelCommitDelayMs: 250,       // optional finite nonnegative ms; default 0
  cancelOnEscape: false,         // optional boolean; default false
  cancelBehavior: 'retain',      // existing option; default 'rollback'
  emitChange: false              // existing option; default true
});
```

The factory accepts these same options at the top level. Faders do not acquire
rotary lifecycle behavior. Existing listeners and `oninput`/`onchange`/`onkeydown`
properties are never replaced. Factory remounting remains additive and idempotent.

Without new options, wheel still emits an immediate `input` and `change` for each
accepted nonzero delta, pointer dragging still emits `input` and a final `change`
when moved, no-motion pointer release does not emit `change`, and cancellation
rolls back with `input` but no `change`. Triple-tap reset, native range keys,
quantization, Shift-fine wheel, and the 480 ms hold threshold remain intact.

`wheelCommitDelayMs:250` means a quiet interval after the **last** wheel event,
not a throttle. Each event still writes/dispatches input immediately. One end and
at most one synthetic change conclude the burst. Default 0 finishes each event
synchronously. A wheel event clamped at a limit still dispatches input and counts
as activity, preserving the old wheel behavior. This option works without a hook.

`cancelOnEscape:true` consumes Escape only when there is an active gesture. It
cancels active sessions using their normal cancellation rules. With the default
false, Escape is untouched and does not cancel a rotary gesture. A host listener
that already prevented the key wins.

`emitChange:false` suppresses only the binding's synthetic changes. It cannot and
does not suppress native keyboard `input` or `change` events.

### Legacy synchronous compatibility boundary

When `onGesture` is absent, `wheelCommitDelayMs` is 0, and `cancelOnEscape` is
false, wheel uses its original direct synchronous input/change path. A blur
inside its input handler does not roll back that wheel value, nested wheels keep
their original input/change counts, and a wheel dispatched inside pointer
change/reset callbacks remains accepted. Even if a host disables or destroys the
control inside that input handler, the **already-in-flight wheel handler** still
emits its final change unless `emitChange:false`. Destroy itself emits nothing.
This narrow compatibility exception preserves pre-existing hosts that commit
when removing their UI. Any of the new options opting into lifecycle behavior
uses the stronger cancellation/disposal guards below instead. Likewise, legacy
pointer input handlers can temporarily disable and then re-enable a control
before pointerup without losing the existing gesture; opted-in lifecycle mode
cancels as soon as disabled state is observed after a callback/input.

### Validation

`onGesture` accepts a function, null, or omission. The delay accepts a finite,
nonnegative number, null (default), or omission; numeric strings, NaN, infinity,
and negatives are rejected. Escape accepts a boolean, null (default), or omission.
Invalid initial `bindRotary` options register no listeners. The factories reject
invalid new-option updates before changing state/native value or replacing the
current binding, including any pending wheel timer. These guarantees concern
these new options, not a broader change to validation of unrelated options.

## Payload

`onGesture(payload)` receives a fresh, shallow-frozen snapshot with exactly these
fields. Values are read from the native input when the callback is invoked.

| Field | Meaning |
| --- | --- |
| `phase` | `begin`, `move`, `fine`, `end`, or `cancel` |
| `source` | `pointer`, `wheel`, or `keyboard` |
| `originalEvent` | The event that produced this phase; null only for hold-timer fine notification |
| `pointerId` | Accepted pointer ID for pointer sessions; otherwise null |
| `clientX`, `clientY` | Latest available client coordinates for this source; null for keyboard or when none were supplied |
| `startValue` | Numeric native value when this source session began |
| `value` | Current numeric native value, including synchronous controlled clamping |
| `moved` | Whether pointer movement crossed 3 px, a wheel delta was accepted, or a native keyboard input was observed |
| `fine` | Current fine-mode/modifier state; see below |
| `cancelled` | True exactly when phase is `cancel` |
| `cancelReason` | `pointercancel`, `lostpointercapture`, `blur`, `escape`, or null; null on non-cancel phases and on disabled interruption |

`moved` describes activity, not net value difference. It can be true at a limit,
after a host clamp, or after rollback returns the value to `startValue`. A pointer
session can end with `moved:false`; its end callback is still required and emitted.

Timer-ended wheel bursts retain their last wheel event as `originalEvent`.
Pointer hold fine has null `originalEvent` but retains the most recent pointer
coordinates, including subthreshold movement. Blur/keyboard events do not erase
pointer coordinates. A terminal pointer event with coordinates updates them.

## Event ordering

Pointer start:

1. Reject non-primary-button, prevented, already-active, or disabled starts.
2. Finish any pending wheel burst, focus the range, and request pointer capture.
3. Record the pointer session and schedule hold fine.
4. Call `begin`, before any gesture-generated input. Real active pointers are
   captured at this point. Capture failure for synthetic events or detached
   targets remains tolerated, as before.

Pointer movement:

1. Update coordinates, movement threshold, and fine state.
2. Write the quantized value and synchronously dispatch `input` if moved.
3. Recheck whether controlled input handlers disposed, cancelled, or disabled it.
4. If fine changed, emit `fine`; then emit `move` if moved and still active.

No input is emitted merely for a hold/Shift fine-state transition. Hold latches
fine mode for the remaining gesture. Shift held at pointerdown also remains
latched for compatibility with the original implementation. Shift pressed after
pointerdown is temporary; release returns to coarse mode unless hold has latched.
Shift changes arriving through pointer events update the state before input; the
`fine` notification follows that input. A focused Shift key event can notify fine
immediately. Drag values remain relative to the original start, as before.

Normal pointer end:

1. Clear the pointer session and hold timer before any host callback.
2. For a moved gesture, dispatch `change` unless disabled or `emitChange:false`.
   For no motion, perform the existing triple-tap/reset bookkeeping instead.
3. Call `end`, even without movement. Its value includes synchronous change/reset
   handlers' updates.
4. Release pointer capture in a `finally` block. The resulting nested
   `lostpointercapture` cannot produce a second terminal callback.

Cancellation:

1. Detach the affected session and clear its timers before callbacks.
2. If enabled and `cancelBehavior:'rollback'`, pointer/wheel restore `startValue`
   with an `input` only when different. `retain` leaves the latest value intact.
3. Call `cancel` with the final native value and the reason. No change is emitted.
4. Release pointer capture in `finally`, exactly as for normal end.

Wheel ordering is `begin`, input, optional `fine`, `move`, then change/end at the
configured quiet interval. With delay 0 this all occurs within the wheel handler.
Changing Shift during a burst emits fine after that event's input. A nonzero wheel
has `moved:true`, even when its value is clamped.

## Native keyboard observation

Keyboard lifecycle is optional with `onGesture`. Arrow, Home/End and PageUp/Down
start an observation session at unprevented keydown; multiple held keys/repeat
share that session. Matching keyups end it when no relevant key remains held.
A key that produces no native input still gets begin/end with `moved:false`.
Unsupported shortcuts and Ctrl/Alt/Meta combinations are not claimed.

The binding **never writes keyboard values**, invents key steps, prevents enabled
range navigation, or manufactures keyboard input/change. Native browser support
for a particular key or `step='any'` remains native. Shift in a keyboard payload
reflects the modifier, not a promise that the browser implements fine stepping.

After native input, move observation is queued as a task and flushed before
keyup/blur termination if needed. A microtask is insufficient: native dispatch
can checkpoint microtasks between separate event listeners. The task/keyup flush
allows later registered controlled input listeners to clamp before observation.
Native change can precede or follow move depending on the browser; the binding
never reorders it. Each observed input queues one move. If several input events
are dispatched synchronously before the flush, they observe the then-current
settled value rather than an intermediate historical snapshot.

Keyboard blur/Escape reports cancellation but **retains** the browser's value,
including when `cancelBehavior:'rollback'`. Rollback belongs only to pointer/wheel
values written by this binding. Synthetic input events while a keyboard key is
held are observable too; input generated by this binding's pointer/wheel commits
is excluded. Native pointer/wheel and keyboard sessions can coexist.

## Simultaneous sources and host integration

Pointer and wheel remain independent. Existing behavior allows wheel changes
while a pointer is held, then computes the next drag movement from the original
pointer start. Do not clear pointer editing just because a wheel end arrived.
A pending wheel burst is completed before a new pointer or keyboard session
begins. Blur/Escape cancel each active source separately. For overlapping rollback
sessions, each cancellation restores its own start snapshot in pointer, wheel,
keyboard order; live hosts should normally select `retain`.

The payload's `source` identifies the three possible concurrent sessions. Track
active sources on the host (for example a `Set`); there is at most one active
session per source. No interaction ID is needed to pair synchronous begin/end.
Use a host-owned generation/version counter for asynchronous completion so a late
response from an older edit cannot clear a newer edit's HUD or editing marker.

Suggested host responsibilities:

- `begin`: mark this source editing and advance the host commit generation.
- `move`/`fine`: update the host HUD with the reported coordinates/value/fine mode.
- `input`: enqueue the host's ordinary live update with its existing cadence.
- `end`: conclude this source, then let the host choose its flush/save behavior.
- `cancel`: inspect cancellation policy/reason and final value; retain mode can
  flush a moved live value, rollback mode can synchronize rollback without
  treating it as a new committed edit.
- Clear the host editing marker only after the relevant async flush settles and
  no newer generation/source owns it. No-motion end still clears source state.

Choose one commit path. A host committing from end/cancel should normally use
`emitChange:false` and avoid separately treating native change as another commit.
The library cannot deduplicate application requests. Full Tonewedge keeps
`cancelOnEscape:false` and can opt into its existing 250 ms wheel commit cadence;
its live-update cadence stays entirely host-owned.

## Disable, dispose, reentrancy, and updates

Native `disabled`, inherited disabled fieldsets, and `aria-disabled='true'` reject
new starts, wheel input, and value-changing keyboard/reset keys. During a session,
disabled state is checked at its next event/timer and immediately after callbacks
or synthetic input. It cancels with `cancelReason:null`, without value rollback,
change, or reset. This is observable cleanup, not a commit request. There is no
MutationObserver, so setting disabled outside an event does not synchronously
invoke a hook. Hosts should clear their own transient UI immediately when they
intentionally disable a control.

Destroy is idempotent and silent: it emits no end/cancel, input, change, reset,
rollback, or host commit. The already-in-flight legacy wheel exception above
remains only when no new option is enabled. It removes only this binding's
listeners, clears hold/wheel/keyboard
timers, releases capture, and leaves current values and host handlers untouched.
Factory configuration changes that replace a binding also silently dispose it.
Hosts own their transient editing cleanup before destroy/reconfiguration.

The factory silently rebinds when `onGesture`, `wheelCommitDelayMs`,
`cancelOnEscape`, or its existing structural/gesture options change. Use a stable
hook and host closures during active editing. Plain `update({value})` or
`refresh()` does not rebind and is safe in synchronous controlled input handlers.

Callbacks may synchronously clamp values, update a control, disable it, dispose,
or dispatch cancellation. In lifecycle mode, active-session identity is checked
after each callback
or input so no stale move, timer end, rollback, or change follows disposal or a
completed cancellation. Terminal state is removed before rollback input/change/
reset callbacks; repeated blur/lost capture cannot finish it again. In lifecycle
mode, synthetic
start events dispatched synchronously inside terminal callbacks are ignored until
that terminal operation releases capture. Existing independent sessions still
retain their own state.

Hooks should not throw. If a hook does throw, the affected session is silently
abandoned: its timers are cancelled, its pointer capture is released, and no
rollback, change, or further lifecycle callback is synthesized. The original
error is rethrown for normal listener error reporting. A subsequent event can
start a fresh session. Other sources are not abandoned merely because a hook
failed. Blur/Escape still
visits every session active when that cancellation began even if one hook throws;
then it rethrows the first failure. The hook must catch its own errors and clear host editing UI when it cannot continue; there is no second
callback into a failing hook and no invented successful commit. Terminal cleanup
also releases capture in `finally` if a terminal/change/reset callback throws.
A directly invoked triple-tap reset callback that throws leaves its pointer
session detached, tap history cleared, and capture released; no end/commit is
synthesized after that failure. As with other host callbacks, reset owns its
transient error UI. Browser-dispatched event-listener errors follow the browser's
usual reporting semantics and are not intercepted by this binding.

## Verification and scope

See `QA-ROTARY-LIFECYCLE.md` and `QA-DEV25.md`. This API changes no source
artwork, styles or semantic palette tokens. It does not migrate application or
device controllers. Generated distributions are rebuilt and checked for each
package release; consumers must pin and verify their own host integration.
