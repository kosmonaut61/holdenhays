# Bildpunkt 0.3.0-dev.8 review

Local candidate only. No push, production staging, deployment, Tonewedge/Pi changes or service restarts. Rollback is preserved at `rollback/bildpunkt-dev7-536968e` (`536968e8bec50485406652fd02e5db70234d37b7`).

## Structural change

Six broad glass-pixel cards are now the primary page. The compact brand, search and optional Appearance action are the only top-level controls. The previous hero, edition strip, persistent sidebar, category selector, duplicate navigation and Show all mode are removed from source rather than hidden. All six collapsed labels fit within the 390×844 phone viewport.

A card opens its own inline panel, containing one native example selector and one real live example. Other cards remain closed. Settings and import code are secondary native disclosures. All 26 previous component stories are retained; the old standalone material workbench is integrated as the 27th example. Search covers the examples and opens the correct owning card. Local changes and the last selected example survive close/reopen. Native Enter/Space, Arrow/Home/End card focus, Escape, Close and browser Back/Forward are exercised. Nested dialog/menu and rotary keyboard handling remain independent.

The original three Pinterest card-stack images, the prior UI screenshot, and the new user screenshot were inspected as actual local pixels. The linked Pinterest video was directly opened and inspected at https://www.pinterest.com/pin/932315560381039930/. Its colors were not adopted.

## Shared ownership

- Primary cards use `createSectionCard`, which composes the shared native button, ordered-dither frost and independent label fade. The shared decorative marker now reflects plus/minus expansion rather than a color-only accent.
- New Appearance, Close and Clear actions use `createButton`; the example selector uses `createSelect`; Appearance uses `createDialog` with explicit return focus. Existing palette swatches, presets and export/reset actions also use the shared native factory.
- Optional native `details` use the shared `tw-disclosure--quiet` style. A disclosure summary is not disguised as an action button. This variant does not replace nested control styling.
- The brand is the page h1, group cards are h2 and example headings are h3. Visible tiny counts were removed; descriptive counts remain accessible.
- Host spacing consumes existing semantic roles. Palette tokens, raster ramps, authored assets, C++ token exports and the Redaction 50 / Arial families are unchanged, apart from the candidate version field.

## Verification

Passed 101 package/unit/parity checks, 2 site/MCP checks and 62 browser flows: 56 retained regressions plus 6 new navigation combinations. The retained typography audit covers 22,116 text/form observations and 2,352 code samples with zero unexpected families. The six new Chrome/WebKit navigation combinations cover desktop, phone and 800×480 compact layouts. Each combination visits all 27 live examples and the offline standalone page. Checks cover clean default hierarchy, one-card expansion, state persistence, search/empty/clear, history and focus, native controls, optional settings, modal focus return, exact approved button colors, shared factory ownership, reduced motion, forced colors, no horizontal overflow, and zero browser errors or unexpected external requests.

Retained browser suites were updated to use the actual new navigation and disclosures without preserving obsolete sidebar selectors or hidden Show all UI. Final retained counts, source hashes and typography observations are recorded in `qa/dev8/summary.json` and `qa/dev8/retained-regression-summary.json`.

An initial retained-site WebKit Back test encountered a build changing during its run. It passed all three WebKit viewports on a consistent build, and every retained suite was then rerun against the final stable generated output. No product-side workaround was added.

## Visual evidence

In `qa/dev8/`:
- `default-desktop.png`, `default-mobile.png`, `default-compact.png`: clean six-card default view.
- `expanded-desktop.png`, `expanded-mobile.png`, `expanded-compact.png`: inline live Buttons example.
- `expanded-card-*.png`: full open card.
- `knob-*.png`: retained tactile dial inside an open card.
- `keyboard-focused-*.png`: deliberate accessible focus ring, separate from the presentation screenshots.

Final screenshots were visually inspected on the Mac. Reduced-motion disables the brief panel reveal. Card raster itself remains static.

## Limits

Browser QA uses installed Chrome and matched Playwright 1.62.1 / WebKit 2336. Physical iPhone, Pi hardware and the Logic AU host were not tested. Production is unchanged. Existing consumers must explicitly upgrade the pinned package.
