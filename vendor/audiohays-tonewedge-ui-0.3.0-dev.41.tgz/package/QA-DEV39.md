# Dev39: authored palette families and segmented ring previews

- Adds Ochre, Lagoon, Rose, Iris and Olive in light/dark, including semantic surfaces, interaction ramps, eight-stop glass and all visualizer scenes.
- Shared inert SVG preview API in appearance.mjs and components.css. Named catalog controls retain native button keyboard/touch behavior.
- Exact predecessor: bcad5cb08f1ac8aedd5dfa2c02d307bcfe78e272 (dev38). New invariant projects out only the five added IDs and deep-compares every existing token/material record with the predecessor fixture. Spectral glass remains #303941 dark / #dfe4e8 light. Historical fixtures are retained; byte revisions are explicitly pinned.
- `npm run check`: 336 tests pass. `npm run check:site`: 2 tests pass, generated catalog parity passes. Packed-consumer import included.
- WCAG checks cover 4.5:1 ordinary ink/action labels and 3:1 focus/control edges across every palette, mode and treatment; selected fills also tested under 14% sheen + 6% hover brightness. New light fill colors were tuned against these tests.
- Real connected Chrome: all five themes in both modes, 13 rings with all eight pigments, exactly one selected control, mode-sensitive previews, zero horizontal overflow, keyboard Enter, 390×844 mobile wrapping and >44px touch targets. No console errors. Ten desktop and two mobile screenshots recorded with the release evidence.
- Browser preference behavior is unchanged; no migration or reset of existing saved appearance fields. This package does not install or reload an app. Consumer host/native/AU verification is recorded separately by each consumer.
