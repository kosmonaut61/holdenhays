# Dev41: complete two-row palette board

Adds Copper, Glacier, Orchid, Sand and Midnight, bringing the shared palette list to 18. Every theme has separately authored light/dark semantic surfaces, interaction colors and eight-stop optical pigments. Existing 13 themes, saved IDs, default Spectral glass, explicit tints and dither previews remain unchanged.

The catalog uses nine columns on desktop (two complete rows) and its existing responsive wrapping on smaller screens. The screenshot supplied by Holden showed nine available columns, with five empty positions in the second row.

Validation:
- 342 library tests pass, including exact dev40 source/material preservation, contrast across every treatment and mode, material/visualizer rendering, native output and offline packed-consumer imports.
- Two site/API tests and generated site parity pass.
- 112 Chrome/WebKit palette-selection states at desktop, 868px, phone and 800px sizes pass. All 18 rings contain eight dithered pigments; exactly one selection; keyboard, repeated disclosure and standalone offline rendering pass. Desktop rows are 9 + 9, without overflow.
- Independent review passed source changes and visual checks at 390–1440px.
- The older broad `browser-catalog.mjs` stops at its stale expectation that component cards initially use Monochrome. Current and previous source initialize cards to Spectral while only the page shell is Monochrome. No product behavior was changed to satisfy that outdated expectation.

This package does not itself install or reload consumer apps. Consumer updates require their normal complete-version upgrade flow.
