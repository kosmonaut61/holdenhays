# Palette preview dither (dev40)

The shared palette rings use the radial dial's fixed 2px Bayer lattice and inward dissolve. A thin pigment rim and low-opacity wash preserve all eight color stops. The center check, native button semantics, palette records and host selection remain unchanged.

## Verified

- 339 library tests and two site/API tests pass, including the offline packed-consumer import.
- Geometry tests verify whole axis-aligned two-pixel squares remain inside each pigment sector, every segment is populated, colors match the authored renderer stops, and the radial threshold is unchanged.
- Real Chrome and WebKit at 1280x800, 390x844 and 800x480 passed 84 palette-selection/light-dark combinations. All 13 previews render eight dither sectors; exactly one selection/check remains. Keyboard Enter, repeated disclosure open/close and horizontal overflow are checked.
- Both engines at every size execute the self-contained offline catalog without page errors. The shared threshold is included once before its consumers.
- Screenshots visually reviewed in light/dark. Selected check is clear; palette swatches stay distinct.
- Independent source/visual review found no remaining blocker after the offline helper was added.

No semantic color values, settings, storage, audio, interaction handlers, or dependency versions changed. The new helper is part of the complete distribution and offline bundle. Consumer installation/activation is recorded separately; these package checks do not assert physical Pi or Logic acceptance.
