# Bildpunkt appearance

One versioned, framework-free library powers the browsable component catalog. The catalog imports its real controls, material renderer, appearance controller, spacing exports and catalog definitions from the same generated build. It is not a separate mockup implementation.

## Independent choices

- **Mode:** `system` (default), `light` or `dark`. Mode is independent of palette and treatment. System follows `prefers-color-scheme`, including changes while the page is open. Each controller resolves its own root to a light or dark surface/ink family.

- **Treatment:** `minimal`, `glass` or `hardware`. Treatment changes framing, surface depth and styling; it never changes palette or product state.
- **Palette:** any choice in `APPEARANCE_PALETTES`, including `spectral`, `cobaltGlass` and neutral `monochrome`.
- **Tint:** `null` or a six-digit hex color. The tint derives a readable light/dark semantic ramp and an eight-tone material palette. It does not put a hue overlay over a monochrome picture. Ordered Bayer dithering and scene topology remain intact.
- **Corner texture:** `none` or `dither`. Dither uses the original Tonewedge corner sprites at their calibrated size. A component's data attribute can override an inherited root setting.

Minimal + monochrome + dither is a convenient preset, not a coupling. Minimal + spectral, minimal + custom tint and hardware + monochrome are also valid. Physical knobs and textured button caps remain tactile at the minimal end. Minimal treatment quiets the decorative material canvas without changing its renderer settings; glass and hardware restore its full pixel field. Product images and guitar/pedal finishes are not globally recolored.

## Selectable palettes and retired preferences

Use `APPEARANCE_PALETTES` for selectors. It is a frozen ordered array of frozen `{id,name,description}` records, also exposed as `catalog.appearance.palettes`. Use `APPEARANCE_PALETTES.map(({id,name})=>({value:id,label:name}))` with `createSelect`; derive swatches with `appearanceColors({palette:id}, resolvedMode)`.

Spectral Cream is retired as of dev.29. It is no longer offered in selectors, swatches, examples or a comparison. Regular `spectral` remains the default. As of dev.38 its TW Glass stock is neutral slate #303941 at night and cool gray #dfe4e8 by day. The page/plate hierarchy, blue/lime action family and other palettes remain unchanged.

`normalizeAppearance`, `createAppearance`, `appearanceColors` and `materialStateForAppearance` accept a previous `spectralCream` ID and resolve it to `spectral`. Only the palette changes: mode (including system), treatment, tint and corner texture are preserved. Controller `state` and `onChange` return the normalized ID, so a host's existing preference persistence can save the migration. Hosts that read preferences without creating a controller can call `normalizeAppearance(stored)` before rendering or saving.

Catalog persistence remains mode-only; the examples still persist palette and mode. Their existing save callbacks write the normalized palette without touching app data.

For backwards compatibility, raw token maps, CSS-only `data-tw-theme="spectralCream"`, native constants and direct material/visualizer tables retain the old Cream values. These are compatibility data, not selectable choices. Do not populate selectors from `Object.keys(palettes)` or raw material maps; use `APPEARANCE_PALETTES` instead. Hosts that intentionally use those low-level APIs must normalize saved appearance preferences explicitly when adopting this release.

## Host integration

Load `tokens.css`, `components.css`, `glass.css` and `treatments.css`, in that order. Apply a treatment to a host scope, not to unrelated application content.

```js
import { createAppearance } from '@audiohays/tonewedge-ui/appearance';
import { createGlassPlate } from '@audiohays/tonewedge-ui/glass';
const plate = createGlassPlate(header);
const appearance = createAppearance(root, {
  state: { palette: 'spectral', treatment: 'minimal', tint: null, cornerTexture: 'none', mode: 'system' },
  materials: [plate],
});
appearance.update({ tint: '#3157bd' });
appearance.update({ treatment: 'hardware' }); // palette/tint/mode are unchanged
appearance.update({ mode: 'dark' }); // palette, texture and component state are unchanged
console.log(appearance.resolvedMode); // 'light' or 'dark', also when state.mode is 'system'
const detach = appearance.attachMaterial(anotherGlassField);
detach();                  // does not destroy that material
appearance.destroy();     // restores owned root attributes and CSS properties
plate.destroy();          // the host still owns each material's lifecycle
```

The controller exposes `state`, `resolvedMode`, `update`, `attachMaterial` and idempotent `destroy`. It stores only appearance preferences. Controls, callbacks, routing, audio, model bindings and product data remain host-owned. It never replaces the host's DOM or changes inline product colors. `normalizeAppearance`, `appearanceColors`, `materialStateForAppearance`, `TREATMENTS`, `APPEARANCE_PALETTES`, `APPEARANCE_MODES`, `resolveAppearanceMode` and `APPEARANCE_DEFAULTS` are pure metadata/helpers available from the same entrypoint.

CSS-only hosts can use `data-tw-theme`, `data-tw-treatment`, `data-tw-corner-texture` and an explicit `data-tw-mode="light"` or `data-tw-mode="dark"` on the same root. Without an explicit mode, legacy palette behavior is preserved. The controller sets `data-tw-mode-preference` to the requested mode and `data-tw-mode` to the resolved mode. `color-scheme` follows that resolved value for native form popups and scrollbars. Canvas material colors need `update` calls; the appearance controller supplies that synchronization when materials are attached. All named themes have authored multicolor material tables, except strictly neutral Monochrome. Industrial uses steel, patina and copper; older Cobalt uses blue, teal and amber; Ember uses soot-violet, terracotta and gold; Pine uses evergreen, cool teal, bark and lichen; Plum uses violet, berry, rose-copper and muted gold. These decorative colors are independent of semantic paper and action fills. The existing raw `cobalt` table still belongs to protected Cobalt Glass; older Cobalt maps to the new `cobaltLegacy` table. Spectral and Cobalt Glass retain their exact default/light tables and raster output. Explicit dark mode uses a separate authored night table for every named palette, with colored pigments over smoked stock. Explicit custom tints preserve their original single-hue mapping and source topology.

The existing `data-tw-material="glass"` and glass module APIs remain compatible. New explicit treatments do not inherit the old glass palette override. Glass fields additionally accept `tint:null|'#rrggbb'` and `palette:'monochrome'`. `createTintPalette` exposes the pure eight-tone mapping. No automatic animation is introduced.

## Semantic surface and ink pairs

A mode makes `case`, `plate`, `recess`, `glass` and `rackSurface` consistent rather than mixing a light glass foreground with a dark hardware background. `ink`/`muted` and `glassInk`/`glassMuted` meet 4.5:1 on those surfaces, including transparent Minimal specimens. Focus and native input edges use `focus` and `controlEdge` (at least 3:1). Use `onAccent` over `accent`, `onSignal` over `accentLight`, and `windowInk` over `windowSurface`; these are also exported as `--tw-*` properties. The original semantic accent seeds remain unchanged. Named materials use separate decorative tables rather than deriving their colors from those seeds. Pine uses the approved quieter green-gray paper (`glass: #dce5da`, `glassLight: #f1f5ed`); other raw palette values remain unchanged. Light surface values are derived from those palettes. Dark stock is separately authored, not filter inversion or replacement artwork.

### Interaction colors

Industrial, legacy Cobalt, Ember, Pine and Plum have authored interaction ramps under `tokens.interactionPalettes`. Each contains independent light/dark `fill`, `foreground` and `signal` colors. Spectral, Cobalt Glass and Monochrome retain their existing light values and computed control colors. Dark mode uses `tokens.darkPalettes`: deep paper, raised plate, smoked glass, a restrained rim, warm ink and a separate filled-action pair. Spectral and Cobalt Glass keep a saturated cobalt action and acid signal; the other five colored palettes retain their existing authored dark action ramps. Monochrome remains neutral throughout.

The resolved `accent` remains the readable foreground/focus color. Saturated filled controls use `accentFill` with `onAccentFill`; `accentEdge` identifies their boundary, and `accentIndicator` supplies a readable selected line. These optional roles are exported as `--tw-accent-fill`, `--tw-on-accent-fill`, `--tw-accent-edge` and `--tw-accent-indicator`. Shared buttons consume them through the existing `--tw-button-primary`, `--tw-button-primary-edge` and `--tw-button-on-primary` roles, so control factories do not need palette-specific code. Custom tints bypass the authored interaction ramp. Nested palettes and disabled controls reset the optional roles rather than inheriting another palette's fill.

Action labels meet 4.5:1, including the existing cap sheen and hover lift. Focus, selected lines and action boundaries meet 3:1 against normal surfaces. Brighter fills need not themselves provide text-on-paper contrast; their paired label and boundary carry those separate requirements. Paper, art and material field colors are not derived from the brighter fill.

The advanced color editor and `setColor` accept the four new role names. Editing `accent` changes the foreground; editing `accentFill` changes a filled action. The catalog's revised-palette swatches show the authored light-mode fill rather than an unrelated material seed. Manual overrides remain host-owned; the catalog reports primary label contrast alongside normal text contrast.

`appearanceColors(state, resolvedMode)` is pure: pass the controller's `resolvedMode` when inspecting system colors. Without the optional second argument, system resolves to light for deterministic server rendering. A host without `matchMedia` also resolves system to light. The optional controller `matchMedia` injection is useful for tests. Each controller owns one preference listener and removes it on `destroy`; original attributes and owned CSS properties are restored. The host remains responsible for persistence and for propagating an explicit preference to multiple controllers.

Disabled controls use a separate monochrome family for the current mode, including fieldsets and visible labels. A nested light scope resets those inherited disabled roles even inside a dark shell. Selected-only color can therefore remain host-owned: give unselected sections the monochrome palette and the same mode preference. Native switches preserve the real checkbox, a 44px input hit target, focus, label activation and reduced-motion behavior; color and thumb position both communicate state.

Material fields keep their palette identity, tint, scene, dither geometry and optical settings when mode changes. `materialStateForAppearance(state, resolvedMode)` returns `{palette, tint, mode}`; the controller supplies its resolved system mode. A standalone raw field defaults to `mode:"light"` and retains its original pixels. Dark fields use the corresponding night pigment table, dark ground and smoked rather than cream pane stock. Explicit tints retain their single-hue ramp. Changing back to light restores the original raster exactly. Text needs an opaque semantic plate or a host-owned fade to the current `glass` surface; a colorful canvas by itself is not an accessible text background. The content-card and readout examples compose the existing independent fade across their full text area with `tw-surface-content` foregrounds; see [Readable content](GLASS-PIXEL.md#readable-content-in-light-and-dark-modes). Dark mode does not recolor product artwork or change control values.

## Spacing and browsing

See SPACING.md for semantic aliases and CSS/JS/C++ exports. The catalog's Spacing story changes actual component padding and gap, and displays computed values. Palette/treatment changes do not reset spacing. Pixel-specific bevels, indicator offsets, sprite geometry and touch targets are outside layout spacing migration.

The catalog has searchable categories, individual stories, an all-components view, import examples, visual controls and URL/history state. `@audiohays/tonewedge-ui/catalog` is the same metadata served by the site and read-only MCP endpoint.

## Version and adoption boundary

Consumers pin an exact package version, use a local file dependency, or vendor a reviewed generated build. They receive explicit upgrades. Editing this repository does not silently update every application. Existing Tonewedge UI still has host-owned layout and controls; this release must not be described as a completed migration of every control into the library. Hosts choose their adoption boundary and retain their existing state/audio APIs.

No deployment, device installation or automatic application upgrade is performed by these modules. Publication and adoption are separate, explicit host decisions.

## Dark material depth

Night appearance is shared by the catalog and consuming apps. Cast caps have a restrained light-catching top rim and dark base; section sheets cast dark shadows rather than using their pale text color as a glow. Inherited depth roles reset at an explicit light root, so nested examples keep their own appearance. Closed section cards and disabled controls use the same monochrome night stock.

The optional Glass material uses a uniform 88% semantic backing. Colored pixels and optical depth remain visible through the body while text stays protected without assuming host padding. No edge aperture is enabled by default. Button material backing is unchanged, preserving its semantic label pair. Reduced transparency restores solid backing; forced colors removes decorative layers and depth. No new animation, layout, interaction or application state is introduced.

The read-only catalog also exposes this ordered metadata as `catalog.appearance.palettes`.

## Five authored families and palette rings (dev.39)

The shared selectable list adds Ochre (saffron, indigo and sage), Lagoon (sea-glass teal, coral and salt-blue), Rose (dusty rose, eucalyptus and porcelain), Iris (periwinkle, cyan and pale citrus), and Olive (olive leaf, apricot and linen). Every family has independently authored light and dark semantic surfaces, readable interaction ramps, and eight-stop optical material tables. Existing themes, custom tints, stored preference fields and Spectral's #303941 night glass are unchanged.

`createPalettePreview(paletteId, {mode, selected, document})` from `@audiohays/tonewedge-ui/appearance` returns `{element, update, destroy}`. Append `element` inside a host-owned button, or beside a native select. Load `components.css`. Pass the **resolved** light/dark mode; update with `{palette, mode, selected}`. The inert, aria-hidden SVG shows every authored material pigment in renderer order, with the semantic glass in its center and an optional checked mark. It adds no listeners, focus stops, storage, timers, canvas, or external assets. The host must supply an accessible name, visible label, keyboard handling and at least a 44px target. `palettePreviewColors(id, mode)` returns a fresh eight-color array for other renderers. Previews describe the named palette; an explicit custom tint is a separate preference.

The catalog replaces its three strips with named ring buttons. These are original SVG geometry, not game artwork. Pigment segments are equal-sized preview swatches, not quantitative percentages. Selection is represented by a checkmark, outline, pressed state and weight, not color alone. The standalone catalog embeds the same API and token tables.

## Dithered palette previews (dev40)

`createPalettePreview` carries the radial navigation dial’s two-pixel, axis-aligned Bayer dither into every palette chip. Each of the eight pigment sectors fades inward from a thin crisp rim; its low-opacity wash keeps the color family readable. The opaque center and selected check stay clear. The same inert SVG factory serves catalog and host choices, with no extra listeners, timers, settings or dependencies.

## Expanded palette board (dev.41)

Copper (clay and turquoise), Glacier (ice blue and peach), Orchid (magenta and chartreuse), Sand (linen and desert blue), and Midnight (navy and citron) join the existing thirteen themes. Each has authored light and dark modes, full material colors, and the same dithered ring preview. The catalog uses two rows of nine on desktop and responsive wrapping below 860px. Stored palette IDs and prior theme colors are unchanged.
