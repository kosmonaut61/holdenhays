# Explicit shared-system updates

Bildpunkt is one versioned source library. The catalog imports its generated modules. Tonewedge currently vendors an exact reviewed distribution; it does not subscribe to live changes. A package or catalog edit alone does not update an installed application.

## Make a shared change

1. Edit semantic colors/spacing in `tokens/source.json`, material tokens in `tokens/glass.json`, or the relevant component under `src/`. Keep product state, audio, recall, navigation destinations and application layout in the host.
2. Assign a new package version; keep `tokens/glass.json` and site package metadata aligned. The catalog derives its preview version from generated material metadata.
3. Run `npm run build` and `npm run build:site`.
4. Run `npm run check` and `npm run check:site`, then the relevant browser tests. The site check verifies generated public files against the same source build without writing.
5. Review both the component story and a real consumer. `npm pack` has a prepack stale-build check; a normal pack will fail rather than silently package an outdated dist. The packed-consumer regression installs a local tarball fully offline and checks its public exports/version.

The generator produces `dist/` and `site-attachment/design-system/`. The independent site build produces `site/public/` plus catalog JSON. No part of these commands publishes to npm, updates a device, or deploys a website.

## Upgrade a consumer

A consumer must explicitly select the tested version/commit, verify its currently pinned file hashes, copy/install the complete new distribution, and record new hashes. Rebuild that application's offline/bundled output and verify that exact candidate. The host's upgrade script is the owner of this handoff; no library code updates files across repositories at runtime.

A useful propagation proof changes a semantic gutter from 32px to 24px in an isolated source candidate, builds it, upgrades an isolated consumer, and asserts the rendered host gutter changed while native values, callback counts and hardware mappings remain unchanged. Keep this experiment out of the final source release. A CSS-only marker is not proof of adoption: test the rendered style and shared interaction behavior.

## Release and rollback boundaries

Publish/deploy only the exact approved candidate through the separately authorized release flow. A frozen older stage is not an input for a newer release. Reverting a consumer means restoring its previous complete version and hash pin, then rebuilding its bundled output. Do not mix individual files from different versions.

Catalog controls change browser-local preview state. JSON export is a proposal, not a write into canonical tokens. Host controls can use package factories to create native elements or safely adopt existing native elements without cloning them. The host still owns audio, product decisions, persistent data and its chosen layout. Actual Pi Chromium, Logic AU WebKit, physical inputs and real audio paths require target verification beyond desktop browser proxies.
