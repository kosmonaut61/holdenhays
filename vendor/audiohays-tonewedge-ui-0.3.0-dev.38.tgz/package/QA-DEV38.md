# dev.38: Neutral TW Glass

Holden requested the default Spectral TW Glass background be exactly #303941 instead of green #30413e, with a matching light hue and explicit consumer cascade.

- Dark glass: #303941. Light glass: #dfe4e8 (pale cool gray, same hue family). Light-catching tones: #697076 dark, #f3f5f7 light.
- Page and plate stock remain unchanged. The raised dev.37 content-card role is retained. Saturated blue/lime actions and colored optical pigments remain unchanged; only Spectral optical neutral stock follows the corrected glass hue.
- The retired Spectral Cream light alias remains in parity. Its hidden legacy dark stock is unchanged.
- Other palettes and every explicit custom tint remain exact. Default palette/treatment/system-mode and persisted preference schema are unchanged.
- Generated CSS, ESM, native token header, offline catalog and public catalog derive from the same source. Consumers require complete pinned upgrades; installed apps do not auto-update.

Validation at candidate creation: 331 library tests, 2 site/MCP tests, generated-output parity and diff whitespace checks pass. New tests pin exact targets, all unrelated raw roles, custom tint equivalence, optical pigments, text contrast >=4.5:1 and focus/control edges >=3:1. Historical fixtures remain unchanged; intentional revised bytes are separately pinned in the dev.38 fixture. Actual-browser and consumer verification are recorded separately after this immutable package candidate.

Publication is not included. Remote GitHub main verification was blocked by execution network policy. No push, registry publication, deployment, device install or service restart was attempted by this shared-source change.
